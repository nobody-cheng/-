# -*- coding: utf-8 -*-

# Define your item pipelines here
#
# Don't forget to add your pipeline to the ITEM_PIPELINES setting
# See: http://doc.scrapy.org/en/latest/topics/item-pipeline.html

import json
from scrapy.exceptions import DropItem
from crawler.items import Crawler0181Item,Crawler016Item,Crawler017Item,Crawler015Item,Crawler013Item,crawler114,crawler114_out,crawler116
import redis

redis_db = redis.Redis(host='localhost', port=6379, db=0, password=None)
redis_data_dict = "scrapy_test"


class DuplicatePipeline(object):
    def process_item(self, item, spider):
        if item['spider_name'] in[ 'crawler013','crawler015_1','crawler015','crawler016_2','crawler016','crawler018','crawler018_2','crawler017_2',
                                   'crawler017','crawler114_18','crawler114_o_18','crawler114_19','crawler114_o_19','crawler114_20','crawler114_o_20',
                                   'crawler114_21','crawler114_o_21','crawler114_23','crawler114_o_23','crawler114_24','crawler114_o_24','']:
            if redis_db.hexists(redis_data_dict, hash(item['source_url'])):
                print('already exist!')
                raise DropItem("Duplicate item found:%s" % item)
            else:
                redis_db.hset(redis_data_dict, hash(item['source_url']), item['spider_name'])
        elif item['spider_name'] == 'crawler114_22':
            if redis_db.hexists(redis_data_dict, hash(item['data_id'])):
                print('already exist!')
                raise DropItem("Duplicate item found:%s" % item)
            else:
                redis_db.hset(redis_data_dict, hash(item['data_id']), item['spider_name'])
        elif item['spider_name'] in['crawler116_13','crawler116_15'] :
            if redis_db.hexists(redis_data_dict, hash(item['case_no']+item['source_page'])):
                print('already exist!')
                raise DropItem("Duplicate item found:%s" % item)
            else:
                redis_db.hset(redis_data_dict, hash(item['case_no']+item['source_page']), item['spider_name'])
        elif item['spider_name'] =='crawler116_16':
            if redis_db.hexists(redis_data_dict, hash(item['case_no']+ item['notice_id'])):
                print('already exist!')
                raise DropItem("Duplicate item found:%s" % item)
            else:
                redis_db.hset(redis_data_dict, hash(item['case_no']+item['notice_id']), item['spider_name'])
        elif item['spider_name'] == 'crawler116_17':
            if redis_db.hexists(redis_data_dict, hash(item['notice_id'])):
                print('already exist!')
                raise DropItem("Duplicate item found:%s" % item)
            else:
                redis_db.hset(redis_data_dict, hash(item['notice_id']), item['spider_name'])
        return item