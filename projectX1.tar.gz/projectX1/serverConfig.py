# !/usr/bin/env python
# -*- coding: utf-8 -*-

# E-mail sender config
# EMAIL_SERVER = {
#     'host': 'smtp.exmail.qq.com',
#     'port': 465,
#     'addr': 'wequant_support@huobi.com',
#     'pwd': '!Huobi1234'
# }

# 网易163邮箱
EMAIL_SERVER = {
    'host': 'smtp.qiye.163.com',
    'port': 465,
    'addr': 'support@wequant.io',
    'pwd': '!Huobiyx'
}

# 用户接收信息邮箱地址
# RECEIVER_EMAIL = ['projectx_report@huobi.com']
RECEIVER_EMAIL = ['lizhicong@huobi.com', 'mengxiang@huobi.com', 'zhouchengyuan@huobi.com']
# RECEIVER_EMAIL = ['support@wequant.io']

# 检测所有进程状态的频率
PROCESS_MONITOR_FREQ = 300

# 接收实盘收益报告邮件的频率（单位为秒）
EMAIL_FREQ = 3600

# 接收实盘监控报告（正常）邮件的频率（单位为秒）
MONITOR_NORMAL_EMAIL_FREQ = 3600

# 接收实盘监控报告（异常）邮件的频率（单位为秒）
MONITOR_ALERT_EMAIL_FREQ = 3600

# 在数据库中记录持仓信息的频率 (单位为秒), 默认每60秒记录一次
POSITION_RECORD_FREQ = 600

# 所有标的产品列表
# 可选包括：huobi_cny_btc, huobi_usd_btc, huobi_cny_ltc, huobi_usd_ltc,
#         okcoin_cny_btc, okcoin_usd_btc, okcoin_cny_ltc, okcoin_usd_ltc,
#         btcc_cny_btc, btcc_usd_btc, btcc_cny_ltc, btcc_usd_ltc,
UNDERLYING_LIST = ['huobi_cny_btc', 'okcoin_cny_btc']

# 设置benchmark组成，选择市场标的，用算术平均计算
# 可选包括：huobi_cny_btc, huobi_usd_btc, huobi_cny_ltc, huobi_usd_ltc,
#         okcoin_cny_btc, okcoin_usd_btc, okcoin_cny_ltc, okcoin_usd_ltc,
#         btcc_cny_btc, btcc_usd_btc, btcc_cny_ltc, btcc_usd_ltc
BENCHMARK = ['huobi_cny_btc']

# 设置data和log目录下内容最长保留时间，单位为天
LONGEST_RESERVING_DAYS = 90

# 设置心跳时间戳最大延迟
HEARTBEAT_MAX_DELAY = 600

# 正常监控报告邮箱
# MONITOR_NORMAL_EMAIL = ['projectx_report@huobi.com']
MONITOR_NORMAL_EMAIL = ['lizhicong@huobi.com', 'mengxiang@huobi.com', 'zhouchengyuan@huobi.com']
# 监控异常报告邮箱
# MONITOR_ALERT_EMAIL = ['projectx_alert@huobi.com']
MONITOR_ALERT_EMAIL = ['lizhicong@huobi.com', 'mengxiang@huobi.com', 'zhouchengyuan@huobi.com']

# 深度数据更新频率（单位为秒）
DEPTH_DATA_UPDATE_FREQ = 1

# 获取行情信息,可以接受的时间戳的最大延迟时间 
MAX_TIME_DELAY = 5

# 获取accountInfo的sleep_time
ACCOUNT_INFO_FREQ = 1

# 数据服务器地址
DATA_USER = "root"
DATA_PASSWORD = "abc123"
DATA_HOST = "10.155.0.201"
DATA_DB_NAME = "kline_data"
LATEST_DATA_DELAY_THRESHOLD = 30  # 秒，数据延迟不能超过30秒
