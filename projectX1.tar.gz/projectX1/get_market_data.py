# !/usr/bin/env python
# -*- coding: utf-8 -*-
import gevent.monkey
gevent.monkey.patch_all()

from exchangeConnection.okcoin.util import getOkcoinSpot
from exchangeConnection.chbtc.rest_api import CHBTCRestAPI
from exchangeConnection.pro.proService import ProServiceAPIKey as ProService
from exchangeConnection.poloniex.rest import init_polo_account
from exchangeConnection.kraken.KrakenService import KrakenServiceAPIKey
from exchangeConnection.okex import okex_service
from exchangeConnection.bittrex.BittrexService import Bittrex_Service
from exchangeConnection.huobi import huobiService
from exchangeConnection.bitfinex import bitfinexService
from utils import helper, redisHelper
import time
import traceback
import logging
import datetime
import random

logging.basicConfig(level=logging.INFO,
                    format='%(asctime)s %(filename)s[line:%(lineno)d] %(levelname)s %(message)s',
                    datefmt='%a, %d %b %Y %H:%M:%S',
                    filename='get_market_data' + datetime.datetime.now().strftime("%Y%m%d-%H%M%S") + '.log',
                    filemode='w'
                   )
# market_list = ["huobi", "okcoin", "bitex", "pro", "polo", "chbtc", "bitvc"]
logging.getLogger("requests").setLevel(logging.WARNING)
logging.getLogger("urllib3").setLevel(logging.WARNING)

market_dict = {
             #"pro": ["ltc_btc", "eth_btc", "etc_btc", "bcc_btc"],
             "kraken": ["ltc_btc", "eth_btc", "etc_btc", "bcc_btc"],
             # "chbtc": ["btc_cny", "eth_cny", "ltc_cny", "etc_cny"],
             # "okcoin": ["btc_cny", "ltc_cny", "eth_cny"],
             # "huobi": ["btc_cny", "ltc_cny"],
             # "bitex": ["eth_cny", "etc_cny", "bcc_cny"],
             "pro": ["ltc_btc", "eth_btc", "etc_btc", "bcc_btc", "bt1_btc", "bt2_btc",
                     "eos_btc", "knc_btc", "ast_btc", "zrx_btc", "tnt_btc",
                     "omg_btc", "storj_btc","snt_btc", "rdn_btc","qsp_btc", "rcn_btc",
                     "pay_btc", "mtl_btc", "dash_btc", "xrp_btc", "tnb_btc", "itc_btc", "btg_btc", "bcd_btc",
                     "dgd_btc", "gnt_btc",
                     "btc_usdt", "eth_usdt", "ltc_usdt", "bcc_usdt", "etc_usdt","dash_usdt", "xrp_usdt",
                     "omg_eth", "eos_eth", "rdn_eth", "qsp_eth", "rcn_eth", "tnb_eth", "itc_eth", "pay_eth",
                     "dgd_eth", "gnt_eth",],
             # "chbtc": ["btc_cny", "eth_cny", "ltc_cny", "etc_cny"],
             "okex": ["etc_btc", "ltc_btc", "eth_btc", "bcc_btc"],
             "okex_future": ["btc_usd:this_week", "btc_usd:next_week", "btc_usd:quarter",
                             "ltc_usd:this_week", "ltc_usd:next_week", "ltc_usd:quarter"],
             "bittrex": ["ltc_btc", "eth_btc", "etc_btc", "bcc_btc", "btc_usdt", "eth_usdt", "ltc_usdt", "omg_btc",
                         "omg_eth", "dash_btc", "etc_usdt", "bcc_usdt", "dash_usdt"],
             "bitfinex": ["btc_usd", "bcc_usd", "eth_usd", "ltc_usd", "dash_usd", "etc_usd", "xrp_usd"
                 , "dash_btc",  "bcc_btc", "eos_btc", "omg_btc", "eth_btc", "ltc_btc", "etc_btc", "xrp_btc"]

             # "polo": ["ltc_btc", "eth_btc", "etc_btc"],
             # "bitvc": ["btc_cny", "ltc_cny"]

             }

global acc_count, lock_count, error_count
acc_count = 0
lock_count = 0
error_count = 0


def huobi_depth(coinMarketType, depth):
    huobi_service = huobiService.HuobiService(None)
    while True:
        try:
            lock_time = time.time()
            if redisHelper.redis_lock("_".join(["md", "huobi", coinMarketType]), lock_time, 2):
                ret = huobi_service.getDepth(helper.coinTypeStructure[coinMarketType]["huobi"]["coin_type"],
                                            helper.coinTypeStructure[coinMarketType]["huobi"]["market"], depth_size=depth)
                ret['time'] = time.time()
                redisHelper.set_marketdata("huobi_%s" % coinMarketType, ret)
                time.sleep(0.5)
                redisHelper.redis_unlock("_".join(["md", "huobi", coinMarketType]), lock_time)
                time.sleep(random.random())
            else:
                time.sleep(0.5 + random.random())
        except Exception:
            logging.error(traceback.format_exc())
            time.sleep(1)


def pro_depth(coinMarketType, depth):
    symbol = coinMarketType.replace('_', '')
    pro_service = ProService()
    while True:
        try:
            lock_time = time.time()
            if redisHelper.redis_lock("_".join(["md", "pro", coinMarketType]), lock_time, 2):
                response = pro_service.get_depth(symbol)
                ret = dict()
                ret['time'] = response['ts'] / 1000
                ret['asks'] = response['tick']['asks']
                ret['bids'] = response['tick']['bids']
                redisHelper.set_marketdata("pro_{0}".format(coinMarketType), ret)
                time.sleep(0.5)
                redisHelper.redis_unlock("_".join(["md", "pro", coinMarketType]), lock_time)
                time.sleep(0.5 * random.random())
            else:
                time.sleep(0.5 + 0.5 * random.random())
        except Exception:
            logging.error(traceback.format_exc())
            time.sleep(1)


def polo_depth(coinMarketType, depth):
    coin_type, currency = coinMarketType.split('_')
    PoloRestAPI = init_polo_account()
    while True:
        try:
            lock_time = time.time()
            if redisHelper.redis_lock("_".join(["md", "polo", coinMarketType]), lock_time, 2):
                response = PoloRestAPI.get_depth(coin_type, currency)
                ret = dict()
                ret['time'] = time.time()
                ret['asks'] = response['asks']
                ret['bids'] = response['bids']
                redisHelper.set_marketdata("polo_{0}".format(coinMarketType), ret)
                time.sleep(0.5)
                redisHelper.redis_unlock("_".join(["md", "polo", coinMarketType]), lock_time)
                time.sleep(random.random())
            else:
                time.sleep(0.5 + random.random())
        except Exception:
            logging.error(traceback.format_exc())
            time.sleep(1)


def okcoin_depth(coinMarketType, depth):
    OKCoinService = getOkcoinSpot()
    while True:
        try:
            ret = OKCoinService.depth(helper.coinTypeStructure[coinMarketType]["okcoin"]["coin_type"], size=depth)
            # okcoin depth data的时间戳
            ret["asks"].reverse()
            ret['time'] = time.time()
            # depth_data["okcoin"] = ret
            redisHelper.set_marketdata("okcoin_%s" % coinMarketType, ret)
            time.sleep(0.1)
        except Exception:
            logging.error(traceback.format_exc())
            time.sleep(1)


def chbtc_depth(coinMarketType, depth):
    while True:
        try:
            coin_type, currency = coinMarketType.split("_")
            ret = CHBTCRestAPI.get_depth(coin_type, currency, size=depth)
            ret["asks"].reverse()
            ret['time'] = time.time()
            redisHelper.set_marketdata("chbtc_{0}".format(coinMarketType), ret)
            time.sleep(1)
        except Exception:
            logging.error(traceback.format_exc())
            time.sleep(1)


def kraken_depth(coinMarketType, depth):
    while True:
        try:
            lock_time = time.time()
            if redisHelper.redis_lock("_".join(["md", "kraken", coinMarketType]), lock_time, 2):
                coin_type, currency = coinMarketType.split("_")
                kraken_api = KrakenServiceAPIKey()
                ret = kraken_api.get_depth(coin_type, currency, size=depth)
                ret['time'] = time.time()
                redisHelper.set_marketdata("kraken_{0}".format(coinMarketType), ret)
                time.sleep(0.5)
                redisHelper.redis_unlock("_".join(["md", "kraken", coinMarketType]), lock_time)
                time.sleep(random.random())
            else:
                time.sleep(0.5 + random.random())
        except Exception:
            logging.error(traceback.format_exc())
            time.sleep(1)


def okex_spot_depth(coinMarketType, depth):
    OkexService = okex_service.get_okex_spot()
    while True:
        try:
            lock_time = time.time()
            if redisHelper.redis_lock("_".join(["md", "okex", coinMarketType]), lock_time, 2):
                ret = OkexService.depth(coinMarketType, size=depth)
                # okcoin depth data的时间戳
                ret["asks"].reverse()
                ret['time'] = time.time()
                # depth_data["okcoin"] = ret
                redisHelper.set_marketdata("okex_%s" % coinMarketType, ret)
                time.sleep(0.5)
                redisHelper.redis_unlock("_".join(["md", "okex", coinMarketType]), lock_time)
                time.sleep(random.random())
            else:
                time.sleep(0.5 + random.random())
        except Exception:
            # logging.info(traceback.format_exc())
            time.sleep(1)


def okex_future_depth(symbol, contract_type, depth):
    OkexService = okex_service.get_okex_future()
    while True:
        try:
            lock_time = time.time()
            if redisHelper.redis_lock("_".join(["md", "okex", symbol, contract_type]), lock_time, 2):
                ret = OkexService.future_depth(symbol, contract_type, size=depth)
                # okcoin depth data的时间戳
                ret["asks"].reverse()
                ret['time'] = time.time()
                # depth_data["okcoin"] = ret
                redisHelper.set_marketdata("okex_%s:%s" % (symbol, contract_type), ret)
                time.sleep(0.5)
                redisHelper.redis_unlock("_".join(["md", "okex", symbol, contract_type]), lock_time)
                time.sleep(random.random())
            else:
                time.sleep(0.5 + random.random())
        except Exception:
            # printTracebackToLog(timeLog)
            time.sleep(1)


def bittrex_depth(symbol):
    BittrexService = Bittrex_Service()
    while True:
        try:
            lock_time = time.time()
            if redisHelper.redis_lock("_".join(["md", "bittrex", symbol]), lock_time, 2):
                coin_type, currency = symbol.split("_")
                ret = BittrexService.get_depth(coin_type, currency)
                bids = [[bid["Rate"], bid["Quantity"]] for bid in ret["buy"]]
                asks = [[bid["Rate"], bid["Quantity"]] for bid in ret["sell"]]
                redisHelper.set_marketdata("bittrex_%s" % symbol, {"bids": bids, "asks": asks, "time": time.time()})
                time.sleep(0.5)
                redisHelper.redis_unlock("_".join(["md", "bittrex", symbol]), lock_time)
                time.sleep(random.random())
            else:
                time.sleep(0.5 + random.random())
        except Exception:
            logging.error(traceback.format_exc())
            time.sleep(1)


def bitfinex_depth(symbol, depth):
    global acc_count, lock_count, error_count
    last_update = time.time()
    BitfinexService = bitfinexService.bitfinex_service(proxy=True)
    while True:
        try:
            lock_time = time.time()
            if redisHelper.redis_lock("_".join(["md", "bitfinex", symbol]), lock_time, 5):
                ret = BitfinexService.order_book(BitfinexService.create_symbol(symbol), limit_bids=depth,
                                                 limit_asks=depth)
                bids = [[float(bid["price"]), float(bid["amount"])] for bid in ret["bids"][:depth]]
                asks = [[float(bid["price"]), float(bid["amount"])] for bid in ret["asks"][:depth]]
                redisHelper.set_marketdata("bitfinex_%s" % symbol, {"bids": bids, "asks": asks, "time": time.time()})
                time.sleep(2)
                acc_count += 1
                redisHelper.redis_unlock("_".join(["md", "bitfinex", symbol]), lock_time)
                time.sleep(2 * random.random())
            else:
                lock_count += 1
                time.sleep(2 + 2 * random.random())
            if time.time() - last_update > 60:
                last_update = time.time()
                logging.info("bitfinex_depth_count   %s   %s  %s" % (acc_count, lock_count, error_count))
        except Exception:
            logging.error(traceback.format_exc())
            error_count += 1
            time.sleep(2)


def get_data(exchange, coin_type):
    if exchange == "pro":
        return pro_depth(coin_type, helper.DATA_DEPTH)
    elif exchange == "okcoin":
        return okcoin_depth(coin_type, helper.DATA_DEPTH)
    elif exchange == "polo":
        return polo_depth(coin_type, helper.DATA_DEPTH)
    elif exchange == "chbtc":
        return chbtc_depth(coin_type, helper.DATA_DEPTH)
    elif exchange == "kraken":
        return kraken_depth(coin_type, helper.DATA_DEPTH)
    elif exchange == "okex":
        return okex_spot_depth(coin_type, 200)
    elif exchange == "okex_future":
        symbol, contract_type = coin_type.split(":")
        return okex_future_depth(symbol, contract_type, helper.DATA_DEPTH)
    elif exchange == "bittrex":
        return bittrex_depth(coin_type)
    elif exchange == "huobi":
        return huobi_depth(coin_type, helper.DATA_DEPTH)
    elif exchange == "bitfinex":
        return bitfinex_depth(coin_type, helper.DATA_DEPTH * 2)


if __name__ == "__main__":
    proc_list = []
    for k in market_dict:
        logging.info(str([k, market_dict[k]]))
        for market in market_dict[k]:
            # proc_list.append(get_data(k, market))
            logging.warning("%s, %s" % (k, market))
            proc_list.append(gevent.spawn(get_data, k, market))
    gevent.joinall(proc_list)