#!/usr/bin/env python
# -*- coding: utf-8 -*-

import talib as ta
import numpy as np


############################################
# 部分常量

BREAKOUT_UP = "up"
BREAKOUT_DOWN = "down"
NO_BREAKOUT = "no_breakout"

BUY_SIG = "buy_signal"
SELL_SIG = "sell_signal"
NO_SIG = "no_signal"

# Moving Average Type
SMA = ta.MA_Type.SMA
EMA = ta.MA_Type.EMA
#############################################


def macd_golden_cross(data, fast_ema_period=12, slow_ema_period=26, sig_period=9):
    """
    :param data:
    :param fast_ema_period: fast EMA time period window
    :param slow_ema_period: slow EMA time peirod window
    :param sig_period:  signal time period window
    :return: Return BUY_SIG when there is MACD golden cross signal, SELL_SIG when dead cross, otherwise, NO_SIG
    """
    try:
        macd_hist = ta.MACD(data, fastperiod=fast_ema_period, slowperiod=slow_ema_period, signalperiod=sig_period)[2]
        macd_current = macd_hist[-1]
        macd_previous = macd_hist[-2]
    except Exception:
        return None
    # macd从下向上穿过0轴，买入信号
    if macd_previous <= 0 < macd_current:
        return BUY_SIG
    elif macd_current < 0 <= macd_previous:
        return SELL_SIG
    else:
        return NO_SIG


def bollinger_bands_breakout(close, current_price, time_period=20, up_std=2, down_std=2, ma_type=SMA, exceed_pct_up=0, exceed_pct_down=0):
    """
    :param close: price info
    :param current_price:
    :param time_period: int
    :param up_std: upper band multiplier of std
    :param down_std: lower band multiplier of std
    :param ma_type: upper band multiplier of std
    :param exceed_pct_up: get breakout sig when exceeds upper band a percentage, default 0
    :param exceed_pct_down: get breakout sig when exceeds lower band a percentage, default 0
    :return: Return BREAKOUT_UPPER if cross upper band, BREAKOUT_LOWER if lower band, NO_BREAKOUT if no cross
    """
    try:
        close = np.array(close)
        upper, middle, lower = ta.BBANDS(close, timeperiod=time_period, nbdevup=up_std, nbdevdn=down_std, matype=ma_type)
        upper_current = upper[-1]
        lower_current = lower[-1]
    except Exception:
        return None
    if current_price > upper_current * (1 + exceed_pct_up):
        return BREAKOUT_UP
    elif current_price < lower_current * (1 - exceed_pct_down):
        return BREAKOUT_DOWN
    else:
        return NO_BREAKOUT


def dual_moving_average(data, short_ma_period=5, long_ma_period=20, ma_type=SMA, exceed_pct_up=0, exceed_pct_down=0):
    try:
        ma_short = ta.MA(data, timeperiod=short_ma_period, matype=ma_type)
        ma_long = ta.MA(data, timeperiod=long_ma_period, matype=ma_type)
        ma_short_current = ma_short[-1]
        ma_long_current = ma_long[-1]
    except Exception:
        return None
    if ma_short_current > ma_long_current * (1+exceed_pct_up):
        return BUY_SIG
    elif ma_short_current < ma_long_current * (1-exceed_pct_down):
        return SELL_SIG
    else:
        return NO_SIG


def single_moving_average(data, current_price, time_period=5, ma_type=SMA, exceed_pct=0):
    try:
        ma = ta.MA(data, timeperiod=time_period, matype=ma_type)
        ma_current = ma[-1]
    except Exception:
        return None
    if current_price > ma_current * (1+exceed_pct):
        return BUY_SIG
    elif current_price < ma_current * (1-exceed_pct):
        return SELL_SIG


def dual_thrust(high, low, close, current_price, current_open, upper_multiplier, lower_multiplier):
    """
    :param high: high prices, current bar is not included
    :param low: low prices, current bar is not included
    :param close: close prices, current bar is not included
    :param current_price:
    :param current_open: open price of current bar
    :param upper_multiplier:
    :param lower_multiplier:
    :return:
    """
    try:
        hh = np.max(high)
        hc = np.max(close)
        lc = np.min(close)
        ll = np.min(low)
        price_range = max(hh - lc, hc - ll)
        up_bound = current_open + upper_multiplier * price_range
        low_bound = current_open + lower_multiplier * price_range
    except Exception:
        return None

    if current_price > up_bound:
        return BUY_SIG
    elif current_price < low_bound:
        return SELL_SIG
    else:
        return NO_SIG


def atr_value(high, low, close, window):
    try:
        high = np.array(high)
        low = np.array(low)
        close = np.array(close)
        atr = ta.ATR(high, low, close, window)
        atr = atr[-1]
        return atr
    except Exception:
        return None


def calc_unit(net, percentage, atr):
    """
    :param net: 账户净值
    :param percentage: 每个atr对应的账户波动比例
    :param atr: atr值
    :return: unit对应的security的数量
    """
    value = net * percentage / 100
    unit = value / atr
    return unit


def rsi_value(close, window):
    try:
        close = np.array(close)
        rsi = ta.RSI(close, timeperiod=window)
        rsi = rsi[-1]
        return rsi
    except Exception:
        return None




















































