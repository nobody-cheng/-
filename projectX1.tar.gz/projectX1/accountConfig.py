# !/usr/bin/env python
# -*- coding: utf-8 -*-

# huobi config
HUOBI = {
    "CNY_1":
        {
            "ACCESS_KEY": "",
            "SECRET_KEY": "0",
            "SERVICE_API": "https://api.huobi.com/apiv3",
        },
    "USD_1":
        {
            "ACCESS_KEY": "",
            "SECRET_KEY": "",
            "SERVICE_API": "https://api.huobi.com/apiv3",
        },
}

CHBTC = {
    "CNY_1":
        {
            "ACCESS_KEY": "1a922174-00fa-48cb-80c9-524060a3d356",
            "SECRET_KEY": "431838c8-2a66-43be-96cb-34ccce6063a4",
            "SERVICE_API": "https://api.chbtc.com/",
        },
    "USD_1":
        {
            "ACCESS_KEY": "",
            "SECRET_KEY": "",
            "SERVICE_API": "https://api.chbtc.com/",
        },
}

OKCOIN = {
    "CNY_1":
        {
            "ACCESS_KEY": "",
            "SECRET_KEY": "",
            "SERVICE_API": "https://www.okcoin.cn", # okcoin国内站
        },

    "USD_1":
        {
            "ACCESS_KEY": "",
            "SECRET_KEY": "",
        }
}

BITVC = {
    "CNY_1":
        {
            "ACCESS_KEY": "",
            "SECRET_KEY": "",
            "SERVICE_API": "https://www.okcoin.cn", # okcoin国内站
            "FUTURE_SERVICE_API": "",
        },

    "USD_1":
        {
            "ACCESS_KEY": "",
            "SECRET_KEY": "",
        }
}

POLO = {
    "CNY_1":
        {
            "ACCESS_KEY": "",
            "SECRET_KEY": "",
            "SERVICE_API": "https://www.okcoin.cn", # okcoin国内站
            "FUTURE_SERVICE_API": "",
        },

    "USD_1":
        {
            "ACCESS_KEY": "",
            "SECRET_KEY": "",
        }
}

BITEX = {
    "CNY_1":
        {
            "ACCESS_KEY": "9458bd08-51b2823b-aaafe70b-f2f22",
            "SECRET_KEY": "ed1646c3-376cc972-aff53085-0fec1",
        },

    "USD_1":
        {
            "ACCESS_KEY": "",
            "SECRET_KEY": "",
        }
}