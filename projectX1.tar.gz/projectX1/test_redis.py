import redis
import time
import utils.redisHelper as rh

r = redis.Redis(host="127.0.0.1", port=6379, db=0)

lock_time = time.time()
exchange = "pro"
acc_id = "redistest"
result = rh.redis_lock("_".join(["md", exchange, acc_id]), lock_time, 10)
print(result)
result = rh.redis_lock("_".join(["md", exchange, acc_id]), lock_time, 2)
print(result)
print(rh.redis_unlock("_".join(["md", exchange, acc_id]), lock_time))
result = rh.redis_lock("_".join(["md", exchange, acc_id]), lock_time, 2)
print(result)
time.sleep(3)
result = rh.redis_lock("_".join(["md", exchange, acc_id]), lock_time, 10)
print(result)