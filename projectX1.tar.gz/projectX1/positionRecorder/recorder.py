#!/usr/bin/env python
# -*- coding: utf-8 -*-


convert_dict = {"bitfinex": {"bch": "bcc", "dsh": "dash"},
                "okex": {"bch": "bcc"}}


def symbol_convert(exchange, symbol):
    if convert_dict[exchange].get(symbol):
        return convert_dict[exchange].get(symbol)
    else:
        return symbol


def chbtc_spot_record_formatter(acc_info):
    account = dict()
    prefix = 'chbtc'
    for coin in acc_info.get("coins"):
        account[prefix + "_" + coin.get("key") + '_avail'] = float(coin.get("available"))
        account[prefix + "_" + coin.get("key") + "_frozen"] = float(coin.get("freez"))
        account[prefix + "_" + coin.get("key")] = account[prefix + "_" + coin.get("key") + '_avail'] + account[prefix + "_" + coin.get("key") + "_frozen"]
    return account


def kraken_spot_record_formatter(acc_info):
    account = dict()
    prefix = 'kraken'
    for k, v in acc_info.get("balance").items():
        account[prefix + "_" + k.lower()] = v
    return account


def pro_spot_pos_record_formatter(acc_info):
    account = dict()
    prefix = 'pro'
    currencies = set([])
    for subaccount in acc_info:
        currency = subaccount['currency']
        currencies.add(currency)
        type_str = subaccount['type']
        if type_str == 'trade':
            key_str = '_'.join([prefix, currency, 'avail'])
        else:
            key_str = '_'.join([prefix, currency, type_str])
        account[key_str] = float(subaccount['balance'])
    for currency in currencies:
        key_str = prefix + '_' + currency
        account[key_str] = account[key_str + '_frozen'] + account[key_str + '_avail']
    return account


def polo_spot_pos_record_formatter(acc_info):
    account = dict()
    prefix = 'polo'
    for key in acc_info:
        account[prefix + '_' + key] = acc_info[key]
    return account


def okex_spot_pos_record_formatter(acc_info):
    account = dict()
    prefix = "okex"
    currencies = set([])
    for coin_type in acc_info:
        for coin_name in acc_info[coin_type]:
            currencies.add(symbol_convert("okex",coin_name))
            if coin_type == "free":
                account[prefix + "_" + symbol_convert("okex", coin_name) + '_avail'] = float(acc_info[coin_type][coin_name])
            elif coin_type == "freezed":
                account[prefix + "_" + symbol_convert("okex", coin_name) + "_frozen"] = float(acc_info[coin_type][coin_name])
            else:
                account[prefix + "_" + symbol_convert("okex", coin_name) + "_" + coin_type] = float(acc_info[coin_type][coin_name])
    for currency in currencies:
        key_str = prefix + '_' + currency
        account[key_str] = account[key_str + '_frozen'] + account[key_str + '_avail']    
    return account


def bittrex_spot_pos_record_formatter(acc_info):
    account = dict()
    prefix = "bittrex"
    for coin_type in acc_info:
        account["_".join([prefix, coin_type["Currency"].lower(), 'avail'])] = float(coin_type["Available"])
        account["_".join([prefix, coin_type["Currency"].lower(), 'frozen'])] = float(coin_type["Pending"])
        account["_".join([prefix, coin_type["Currency"].lower()])] = float(coin_type["Balance"])
    return account


def huobi_spot_pos_record_formatter(acc_info):
    account = dict()
    prefix = "huobi"
    for currency in ["cny", "btc", "ltc"]:
        account["_".join([prefix, currency, "avail"])] = float(acc_info["_".join(["available", currency, 'display'])])
        account["_".join([prefix, currency, "frozen"])] = float(acc_info["_".join(["frozen", currency, 'display'])])
        account["_".join([prefix, currency])] = account["_".join([prefix, currency, "avail"])] + account["_".join([prefix, currency, "frozen"])]
    account[prefix + '_total'] = float(acc_info['total'])
    account[prefix + '_net'] = float(acc_info['net_asset'])
    return account


def bitfinex_spot_pos_record_formatter(acc_info):
    account = dict()
    prefix = "bitfinex"
    for coin_type in acc_info:
        if coin_type.get("type") == "exchange":
            account["_".join([prefix, symbol_convert("bitfinex", coin_type["currency"]), 'avail'])] = float(coin_type["available"])
            account["_".join([prefix, symbol_convert("bitfinex", coin_type["currency"])])] = float(coin_type["amount"])
            account["_".join([prefix, symbol_convert("bitfinex", coin_type["currency"]), 'frozen'])] = float(coin_type["amount"]) - float(coin_type["available"])
    return account
