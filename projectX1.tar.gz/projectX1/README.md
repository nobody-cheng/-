project X -- run live bitcoin strategy

使用前注意事项：

程序使用matplotlib模块画图，需要先对其进行设置。方法如下：
打开 'matplotlibrc'，anaconda里的路径为
'anaconda/lib/python3.5/site-packages/matplotlib/mpl-data/matplotlibrc'
打开后，找到
backend     : macosx
这一行(不同操作系统冒号后的内容会有不同)，将其改为
backend     : Agg
将文件保存并退出。完成对matplotlib的配置。



