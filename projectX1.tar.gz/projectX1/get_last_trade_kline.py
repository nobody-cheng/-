# -*- coding: utf-8 -*-

import gevent.monkey
gevent.monkey.patch_all()

import traceback
import time
from exchangeConnection.pro import proService
from exchangeConnection.kraken import KrakenService
from exchangeConnection.okex import okex_service
from exchangeConnection.bittrex import BittrexService
import utils.redisHelper as rh
from logbook import Logger, FileHandler, INFO


handler = FileHandler(filename='get_last_trade_kline.log', mode="w", level=INFO)
handler.push_application()
my_log = Logger("trade_log")

market_dict = {
    "pro": {"ltc_btc": ["1min"], "eth_btc": ["1min"],"bcc_btc": ["1min"], "etc_btc": ["1min"]},
    "kraken": {"ltc_btc": ["1min"], "eth_btc": ["1min"], "bcc_btc": ["1min"], "etc_btc": ["1min"]},
    # "chbtc": {"btc_cny": ["1min"], "eth_cny": ["1min"], "ltc_cny": ["1min"], "etc_cny": ["1min"]},
    "okex": {"ltc_btc": ["1min"], "eth_btc": ["1min"],"bcc_btc": ["1min"], "etc_btc": ["1min"]},
    "bittrex": {"ltc_btc": ["1min"], "eth_btc": ["1min"],"bcc_btc": ["1min"], "etc_btc": ["1min"]}

}

kline_size = 1500

time_map = {"1min": 60, "5min": 300, "15min": 900, "30min": 1800, "60min": 3600,
            "1day": 86400, "1week": 86400, "1mon": 86400, "1year": 86400}

pro_service = proService.init_pro_account(None)
kraken_service = KrakenService.kraken_service(None)
okex_spot_service = okex_service.get_okex_spot(None)
bittrex_service = BittrexService.Bittrex_Service()

def set_pro(coin_type):
    while True:
        try:
            td_json = pro_service.get_latest_trade(coin_type.replace("_", "")).to_json(orient='split')
            rh.set_last_trade("pro", coin_type, td_json)
        except Exception as e:
            my_log.error(traceback.format_exc())
        finally:
            time.sleep(60)


def set_pro_kline(coin_type, frequency):
    while True:
        try:
            td_json = pro_service.get_prices(coin_type.replace("_", ""), frequency, kline_size).to_json(orient='split')
            rh.set_kline("pro", coin_type, frequency, td_json)
        except Exception as e:
            my_log.error(traceback.format_exc())
        finally:
            time.sleep(time_map[frequency])


def set_kraken(coin_type):
    while True:
        try:
            td_json = kraken_service.get_latest_trade(coin_type.split("_")[0], coin_type.split("_")[1]).to_json(orient='split')
            rh.set_last_trade("kraken", coin_type, td_json)
        except Exception as e:
            my_log.error(traceback.format_exc())
        finally:
            time.sleep(60)


def set_kraken_kline(coin_type, frequency):
    while True:
        try:
            td_json = kraken_service.get_kline(coin_type.split("_")[0], coin_type.split("_")[1], frequency, kline_size).to_json(orient='split')
            rh.set_kline("kraken", coin_type, frequency, td_json)
        except Exception as e:
            my_log.error(traceback.format_exc())
        finally:
            time.sleep(time_map[frequency])


def set_okex(coin_type):
    while True:
        try:
            td_json = okex_spot_service.get_last_trades(coin_type).to_json(orient='split')
            rh.set_last_trade("okex", coin_type, td_json)
        except Exception as e:
            my_log.error(traceback.format_exc())
        finally:
            time.sleep(60)


def set_okex_kline(coin_type, frequency):
    while True:
        try:
            td_json = okex_spot_service.get_klines(coin_type, frequency, kline_size).to_json(orient='split')
            rh.set_kline("okex", coin_type, frequency, td_json)
        except Exception as e:
            my_log.error(traceback.format_exc())
        finally:
            time.sleep(time_map[frequency])


def set_bittrex(coin_type):
    while True:
        try:
            td_json = bittrex_service.get_last_trades(coin_type).to_json(orient='split')
            rh.set_last_trade("bittrex", coin_type, td_json)
        except Exception as e:
            my_log.error(traceback.format_exc())
        finally:
            time.sleep(60)


def get_trade_data(exchange, coin_type):
    if exchange == "pro":
        return set_pro(coin_type)
    elif exchange == "kraken":
        return set_kraken(coin_type)
    elif exchange == "okex":
        return set_okex(coin_type)
    elif exchange == "bittrex":
        return set_bittrex(coin_type)

def get_kline_data(exchange, coin_type, frequency):
    if exchange == "pro":
        return set_pro_kline(coin_type, frequency)
    elif exchange == 'kraken':
        return set_kraken_kline(coin_type, frequency)
    elif exchange == 'okex':
        return set_okex_kline(coin_type, frequency)

if __name__ == "__main__":
    proc_list = []
    for k in market_dict:
        my_log.info(str([k, market_dict[k]]))
        for market in market_dict[k]:
            my_log.info("%s, %s" % (k, market))
            proc_list.append(gevent.spawn(get_trade_data, k, market))
            if k not in {"bittrex"}:
                for fr in market_dict[k][market]:
                    proc_list.append(gevent.spawn(get_kline_data, k, market, fr))
    gevent.joinall(proc_list)
