# -*- coding: utf-8 -*-

import logging
from utils import helper
from exchangeConnection.bittrex import BittrexService
import time


class BistampExchange:
    def __init__(self, bittrex_accid, logger):
        self.BittrexService = BittrexService.Bittrex_Service(bittrex_accid, 'trade')
        self.timeLog = logger
        self.exchange_name = "bittrex"
        # self.bitstamp_min_quantity = {}

    def bittrex_buy_limit(self, coinType, price, quantity):
        if price is None or quantity is None:
            self.timeLog("限价单必须填写下单价格和数量")
            return None
        self.timeLog("开始下达Bittrex限价买单...")
        self.timeLog("只保留下单数量的小数点后4位，下单价格的小数点后2位...")
        self.timeLog("原始下单数量:%s" % quantity)
        rounded_quantity = str(helper.downRound(float(quantity), 4))
        self.timeLog("做完小数点处理后的下单数量:%s" % rounded_quantity)

        # TODO 最小数量判断

        self.timeLog("原始下单价格:%s" % price)
        rounded_price = str(helper.downRound(float(price), 8))
        self.timeLog("做完小数点处理后的下单价格:%s" % rounded_price)
        coin_type, currency = coinType.split("_")
        try:
            res = self.BittrexService.buy_limit(coin_type, currency, rounded_price, rounded_quantity)
            if isinstance(res, dict):
                order_id = res["uuid"]
            else:
                self.timeLog(res)
                raise Exception
            return order_id
        except Exception as e:
            self.timeLog(
                "下达Bittrex限价买单（数量：%s，价格：%s）失败, 结果是：%s！" % (rounded_quantity, rounded_price, str(e)),
                level=logging.ERROR)
            return None

    def bittrex_sell_limit(self, coinType, price, quantity):
        if price is None or quantity is None:
            self.timeLog("限价单必须填写下单价格和数量")
            return None
        self.timeLog("开始下达Bittrex限价卖单...")
        self.timeLog("只保留下单数量的小数点后4位，下单价格的小数点后2位...")
        self.timeLog("原始下单数量:%s" % quantity)
        rounded_quantity = str(helper.downRound(float(quantity), 4))
        self.timeLog("做完小数点处理后的下单数量:%s" % rounded_quantity)

        # TODO 最小数量判断

        self.timeLog("原始下单价格:%s" % price)
        rounded_price = str(helper.downRound(float(price), 8))
        self.timeLog("做完小数点处理后的下单价格:%s" % rounded_price)
        coin_type, currency = coinType.split("_")
        try:
            res = self.BittrexService.sell_limit(coin_type, currency, rounded_price, rounded_quantity,)
            if isinstance(res, dict):
                order_id = res["uuid"]
            else:
                self.timeLog(res)
                raise Exception
            return order_id
        except Exception as e:
            self.timeLog(
                "下达Bittrex限价卖单（数量：%s，价格：%s）失败, 结果是：%s！" % (rounded_quantity, rounded_price, str(e)),
                level=logging.ERROR)
            return None

    def bittrex_order_info(self, order_id):
        order_info = self.BittrexService.get_order_info(order_id)
        return order_info

    def bittrex_order_cancel(self, order_id):
        self.timeLog("正在撤消bittrex订单 order id: %s" % order_id)
        try:
            res = self.BittrexService.cancel_order(str(order_id))
            return res
        except Exception as e:
            self.timeLog("bittrex订单撤销失败. order id: %s" % order_id)
            return u"failed"

    def bittrex_cancel_pending_order(self, coin_type, order_id_list=None):
        coin_name, currency = coin_type.split("_")
        res = self.BittrexService.get_active_orders(coin_name, currency)
        active_orders = [str(order["OrderUuid"]) for order in res]
        self.timeLog("获取bittrex订单 order id: %s" % active_orders)
        count = 0
        if order_id_list is None:
            while active_orders is not None and len(active_orders) > 0 and count < 3:
                for order_id in active_orders:
                    self.bittrex_order_cancel(order_id)
                time.sleep(2)
                res = self.BittrexService.get_active_orders(coin_name, currency)
                active_orders = [str(order["OrderUuid"]) for order in res]
                count += 1
        else:
            while active_orders is not None and len(active_orders) > 0 and len(order_id_list) > 0 and count < 3:
                active_orders_in_order_list = [order_id for order_id in active_orders if order_id in order_id_list]
                for order_id in active_orders_in_order_list:
                    self.bittrex_order_cancel(order_id)
                time.sleep(2)
                res = self.BittrexService.get_active_orders(coin_name, currency)
                active_orders = [str(order["OrderUuid"]) for order in res]
                count += 1

    def bittrex_get_active_orders(self, coin_type):
        coin_name, currency = coin_type.split("_")
        res = self.BittrexService.get_orders(coin_name, currency)
        active_orders = [str(order["OrderUuid"]) for order in res]
        return active_orders

