# -*- coding: utf-8 -*-

import logging
from utils import helper
from exchangeConnection.bitstamp import BitstampService


class BistampExchange:
    def __init__(self, bitstamp_accid, logger):
        self.BitstampService = BitstampService.bitstamp_service(bitstamp_accid)
        self.timeLog = logger
        self.bitstamp_min_quantity = {}
        self.exchange_name = "bitstamp"

    def bitstamp_buy_limit(self, coinType, price, quantity):
        if price is None or quantity is None:
            self.timeLog("限价单必须填写下单价格和数量")
            return None
        self.timeLog("开始下达Bitex限价买单...")
        self.timeLog("只保留下单数量的小数点后4位，下单价格的小数点后2位...")
        self.timeLog("原始下单数量:%s" % quantity)
        rounded_quantity = str(helper.downRound(float(quantity), 4))
        self.timeLog("做完小数点处理后的下单数量:%s" % rounded_quantity)

        if float(rounded_quantity) < self.bitstamp_min_quantity.get(coinType):
            self.timeLog(
                "数量:%s 小于交易所最小交易数量(bitstamp最小数量:%f),因此无法下单,此处忽略该信号" %
                (rounded_quantity, self.bitstamp_min_quantity.get(coinType)),
                level=logging.WARN)
            return None

        self.timeLog("原始下单价格:%s" % price)
        rounded_price = str(helper.downRound(float(price), 2))
        self.timeLog("做完小数点处理后的下单价格:%s" % rounded_price)
        coin_type, currency = coinType.split("_")
        try:
            res = self.BitstampService.buy_limit(coin_type, currency, rounded_price, rounded_quantity,)
            if res['status'] == 'ok':
                order_id = res['data']
            else:
                raise Exception
            return order_id
        except Exception as e:
            self.timeLog(
                "下达Bitex限价买单（数量：%s，价格：%s）失败, 结果是：%s！" % (rounded_quantity, rounded_price, str(e)),
                level=logging.ERROR)
            return None

    def bitstamp_sell_limit(self, coinType, price, quantity):
        if price is None or quantity is None:
            self.timeLog("限价单必须填写下单价格和数量")
            return None
        self.timeLog("开始下达Bitex限价卖单...")
        self.timeLog("只保留下单数量的小数点后4位，下单价格的小数点后2位...")
        self.timeLog("原始下单数量:%s" % quantity)
        rounded_quantity = str(helper.downRound(float(quantity), 4))
        self.timeLog("做完小数点处理后的下单数量:%s" % rounded_quantity)

        if float(rounded_quantity) < self.bitstamp_min_quantity.get(coinType):
            self.timeLog(
                "数量:%s 小于交易所最小交易数量(bitstamp最小数量:%f),因此无法下单,此处忽略该信号" %
                (rounded_quantity, self.bitstamp_min_quantity.get(coinType)),
                level=logging.WARN)
            return None

        self.timeLog("原始下单价格:%s" % price)
        rounded_price = str(helper.downRound(float(price), 2))
        self.timeLog("做完小数点处理后的下单价格:%s" % rounded_price)
        coin_type, currency = coinType.split("_")
        try:
            res = self.BitstampService.sell_limit(coin_type, currency, rounded_price, rounded_quantity,)
            if res['status'] == 'ok':
                order_id = res['data']
            else:
                raise Exception
            return order_id
        except Exception as e:
            self.timeLog(
                "下达Bitex限价买单（数量：%s，价格：%s）失败, 结果是：%s！" % (rounded_quantity, rounded_price, str(e)),
                level=logging.ERROR)
            return None

    def bitstamp_order_info(self, id):
        order_info = self.BitstampService.get_order_info(id)
        return order_info

    def bitstamp_order_cancel(self, id):
        self.timeLog("正在撤消kraken订单。order id: %s" % id)
        try:
            res = self.BitstampService.cancel_order(str(id))
            return res
        except Exception as e:
            self.timeLog("kraken订单撤销失败. order id: %s" % id)
            return u"failed"

    def bitstamp_cancel_pending_order(self):
        res = self.BitstampService.cancel_all_order()
        return res

    def bitstamp_get_active_orders(self, coinType):
        coin_type, currency = coinType.split("_")
        res = self.BitstampService.get_active_orders(coin_type, currency)
        return res

