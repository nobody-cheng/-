# -*- coding: utf-8 -*-

import logging
import time
from utils import helper
from exchangeConnection.chbtc import rest_api

class ChbtcExchange:
    def __init__(self, chbtc_accid, logger):
        self.CHBTCService = rest_api.chbtc_service(chbtc_accid)
        self.timeLog = logger
        self.chbtc_min_quantity = {"eth_usdt": 0.01, "etc_usdt": 0.01,
                                   "btc_usdt": 0.01, "ltc_usdt": 0.01,
                                  }
        self.exchange_name = "chbtc"

    def chbtc_buy_limit(self, coin_type, price, quantity):
        if price is None or quantity is None:
            self.timeLog("限价单必须填写下单价格和数量")
            return None
        self.timeLog("开始下达CHBTC限价买单...")
        self.timeLog("只保留下单数量的小数点后3位，下单价格的小数点后2位...")
        self.timeLog("原始下单数量:%s" % quantity)
        rounded_quantity = str(helper.downRound(float(quantity), 3))
        self.timeLog("做完小数点处理后的下单数量:%s" % rounded_quantity)

        if float(rounded_quantity) < self.chbtc_min_quantity.get(coin_type):
            self.timeLog(
                "数量:%s 小于交易所最小交易数量(CHB"
                "TC最小数量:%f),因此无法下单,此处忽略该信号" % (rounded_quantity, self.chbtc_min_quantity.get(coin_type)),
                level=logging.WARN)
            return None

        self.timeLog("原始下单价格:%s" % price)
        rounded_price = str(helper.downRound(float(price), 2))
        self.timeLog("做完小数点处理后的下单价格:%s" % rounded_price)
        chbtc_coinType, currency = coin_type.split('_')
        try:
            res = self.CHBTCService.buy_limit(chbtc_coinType, currency, rounded_price, rounded_quantity)
            if str(res['code']) == '1000':
                order_id = res['id']
            else:
                self.timeLog(
                    "下达CHBTC限价买单（数量：%s，价格：%s）失败, 结果是：%s！" % (rounded_quantity, rounded_price, str(res)),
                    level=logging.ERROR)
            return order_id
        except Exception as e:
            self.timeLog(
                "下达CHBTC限价买单（数量：%s，价格：%s）失败, 结果是：%s！" % (rounded_quantity, rounded_price, str(e)),
                level=logging.ERROR)
            return None

    def chbtc_sell_limit(self, coin_type, price, quantity):
        if price is None or quantity is None:
            self.timeLog("限价单必须填写下单价格和数量")
            return None
        self.timeLog("开始下达CHBTC限价卖单...")
        self.timeLog("只保留下单数量的小数点后3位，下单价格的小数点后2位...")
        self.timeLog("原始下单数量:%s" % quantity)
        rounded_quantity = str(helper.downRound(float(quantity), 3))
        self.timeLog("做完小数点处理后的下单数量:%s" % rounded_quantity)
        if float(rounded_quantity) < self.chbtc_min_quantity.get(coin_type):
            self.timeLog(
                "数量:%s 小于交易所最小交易数量(CHBTC最小数量:%f),因此无法下单,此处忽略该信号" % (rounded_quantity, self.chbtc_min_quantity.get(coin_type)),
                level=logging.WARN)
            return None
        self.timeLog("原始下单价格:%s" % price)
        price = str(helper.downRound(float(price), 2))
        self.timeLog("做完小数点处理后的下单价格:%s" % price)
        chbtc_coinType, currency = coin_type.split('_')
        try:
            res = self.CHBTCService.sell_limit(chbtc_coinType, currency, price, rounded_quantity)
            if str(res['code']) == '1000':
                order_id = res['id']
            else:
                self.timeLog(
                    "下达CHBTC限价买单（数量：%s，价格：%s）失败, 结果是：%s！" % (rounded_quantity, price, str(res)),
                    level=logging.ERROR)
            return order_id
        except Exception as e:
            self.timeLog(
                "下达CHBTC限价卖单（数量：%s，价格：%s）失败, 结果是：%s！" % (rounded_quantity, price, str(e)),
                level=logging.ERROR)
            return None

    def chbtc_cancel_pending_orders(self, order_id_list=None, pair=None):
        coin_type, currency = pair.split("_")
        active_orders = self.CHBTCService.get_active_orders(coin_type, currency)
        if order_id_list is None:
            count = 0
            while active_orders is not None and len(active_orders) > 0 and count < 3:
                for order in active_orders:
                    if helper.componentExtract(order, u"id", "") != "":
                        order_id = order[u"id"]
                        self.chbtc_order_cancel(order_id, pair)
                active_orders = self.CHBTCService.get_active_orders(coin_type, currency)
                count += 1
        else:
            count = 0
            while active_orders is not None and len(active_orders) > 0 and len(order_id_list)>0 and count < 3:
                for order in active_orders:
                    if helper.componentExtract(order, u"id", "") != "" and order[u"id"] in order_id_list:
                        order_id = order[u"id"]
                        if self.chbtc_order_cancel(order_id, pair) == 'success':
                            order_id_list.remove(order_id)
                active_orders = self.CHBTCService.get_active_orders(coin_type, currency)
                count += 1

    def chbtc_order_info(self, id, coinMarketType):
        coin_type, currency = coinMarketType.split("_")
        order_info = self.CHBTCService.get_order_info(coin_type, currency, id)
        if "status" in order_info.keys():
            status = order_info['status']
            deal_qty = float(order_info['trade_amount'])
            return status, deal_qty
        else:
            return None

    def chbtc_full_order_info(self, id, with_order_type=False):
        coin_type, currency = self.coinMarketType.split("_")
        order_info = self.CHBTCService.get_order_info(coin_type, currency, id)
        if "status" in order_info.keys() :
            status = order_info['status']
            deal_qty = float(order_info['trade_amount'])
            processed_price = float(order_info['trade_price'])
            if not with_order_type:
                return status, deal_qty, processed_price
            else:
                order_type = "sell" if(order_info['type'] == 0) else 'buy'
                return status, deal_qty, processed_price, order_type
        else:
            return None

    def chbtc_order_cancel(self, id, coinMarketType):
        self.timeLog("正在撤消chbtc订单。order id: %s" % id)
        try:
            coin_type, currency = coinMarketType.split("_")
            res = self.CHBTCService.cancel_order(coin_type, currency, str(id))
            if str(res['code']) in ['1000', '3001']:
                return 'success'
            self.timeLog("chbtc订单撤销失败. order id: %s" % res)
            raise Exception
        except Exception as e:
            self.timeLog("chbtc订单撤销失败. order id: %s %s" % (id, e))
            return u"failed"

    def chbtc_get_active_orders(self, pair):
        coin_type, currency = pair.split("_")
        active_orders = self.CHBTCService.get_active_orders(coin_type, currency)
        return active_orders
