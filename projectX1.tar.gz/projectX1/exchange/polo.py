# -*- coding: utf-8 -*-

import logging
import time
from utils import helper
from exchangeConnection.poloniex import rest

class PoloExchange:
    def __init__(self, polo_accid, logger):
        self.PoloService = rest.init_polo_account(polo_accid)
        self.timeLog = logger
        self.exchange_name = "polo"

    def polo_buy_limit(self, price, quantity, pair=None, get_order_object=False):
        if not pair:
            pair = self.coinMarketType
        coin_type, currency = pair.split('_')
        if price is None or quantity is None:
            self.timeLog("限价单必须填写下单价格和数量")
            return None
        self.timeLog("开始下达P网限价买单...")
        self.timeLog("只保留下单数量的小数点后8位，下单价格的小数点后8位...")
        self.timeLog("原始下单数量:%s" % quantity)
        rounded_quantity = helper.downRound(float(quantity), decimal_places=8)
        self.timeLog("做完小数点处理后的下单数量:%s" % rounded_quantity)
        self.timeLog("原始下单价格:%s" % price)
        rounded_price = helper.downRound(float(price), decimal_places=8)
        self.timeLog("做完小数点处理后的下单价格:%s" % rounded_price)
        order_amount = quantity * rounded_price
        if order_amount < helper.POLO_MIN_ORDER_BTC_AMOUNT:
            self.timeLog(
                "金额:%s 小于交易所最小交易金额(P网最小金额:%f),因此无法下单,此处忽略该信号" % (order_amount, helper.POLO_MIN_ORDER_BTC_AMOUNT),
                level=logging.WARN)
            return None

        try:
            order = self.PoloService.spot_buy(coin_type, currency, rounded_price, rounded_quantity)
            if get_order_object:
                return order
            else:
                return order.order_id
        except Exception as e:
            self.timeLog(
                "下达P网限价买单（数量：%s，价格：%s）失败, 结果是：%s！" % (rounded_quantity, rounded_price, str(e)), level=logging.ERROR)
            return None

    def polo_sell_limit(self, price, quantity, pair=None, get_order_object=False):
        if not pair:
            pair = self.coinMarketType
        coin_type, currency = pair.split('_')
        if price is None or quantity is None:
            self.timeLog("限价单必须填写下单价格和数量")
            return None
        self.timeLog("开始下达P网限价卖单...")
        self.timeLog("只保留下单数量的小数点后8位，下单价格的小数点后8位...")
        self.timeLog("原始下单数量:%s" % quantity)
        q_tmp = float(quantity)
        q_tmp = helper.downRound(q_tmp, decimal_places=8)
        quantity = q_tmp
        self.timeLog("做完小数点处理后的下单数量:%s" % quantity)
        self.timeLog("原始下单价格:%s" % price)
        p_tmp = float(price)
        p_tmp = helper.downRound(p_tmp, decimal_places=8)
        price = p_tmp
        self.timeLog("做完小数点处理后的下单价格:%s" % price)
        order_amount = q_tmp * p_tmp
        if order_amount < helper.POLO_MIN_ORDER_BTC_AMOUNT:
            self.timeLog(
                "金额:%s 小于交易所最小交易金额(P网最小金额:%f),因此无法下单,此处忽略该信号" % (order_amount, helper.POLO_MIN_ORDER_BTC_AMOUNT),
                level=logging.WARN)
            return None
        try:
            order = self.PoloService.spot_sell(coin_type, currency, price, quantity)
            if get_order_object:
                return order
            else:
                return order.order_id
        except Exception as e:
            self.timeLog(
                "下达P网限价卖单（数量：%s，价格：%s）失败, 结果是：%s！" % (quantity, price, str(e)), level=logging.ERROR)
            return None

    def polo_order_info(self, order_id=None, order=None):
        """
        get order info. pass order_id or order
        :type order_id: int or string
        :type order: PoloSpotOrderInfo
        :return:
        """
        if order:
            updated_order = self.PoloService.update_order_info(order)
            return updated_order
        elif order_id:
            order_info = self.PoloService.get_order_info(order_id)
            return order_info
        else:
            raise ValueError('At least one of order_id and order')

    def polo_order_cancel(self, id):
        self.timeLog("正在撤销P网订单。order id: %s" % id)
        try:
            res = self.PoloService.cancel_order(id)
            if res == 'success':
                return 'success'
            raise Exception
        except Exception as e:
            self.timeLog("P网订单撤销失败. order id: %s" % id)
            return u"failed"

    def polo_actvie_orders(self, pair):
        coin_type, currency = pair.split('_')
        return self.PoloService.get_active_orders(coin_type, currency)

    def polo_cancel_pending_orders(self, order_id_list=None, pair=None):
        active_orders = self.polo_actvie_orders(pair)
        if order_id_list is None:
            count = 0
            while active_orders is not None and len(active_orders) > 0 and count < 3:
                for order in active_orders:
                    if helper.componentExtract(order, u"orderNumber", "") != "":
                        order_id = str(order[u"orderNumber"])
                        self.polo_order_cancel(order_id)
                active_orders = self.polo_actvie_orders(pair)
                count += 1
        else:
            count = 0
            while active_orders is not None and len(active_orders) > 0 and len(order_id_list)>0 and count < 3:
                for order in active_orders:
                    if helper.componentExtract(order, u"orderNumber", "") != "" and str(order[u"orderNumber"]) in order_id_list:
                        order_id = str(order[u"orderNumber"])
                        if self.polo_order_cancel(order_id) == 'success':
                            order_id_list.remove(order_id)
                active_orders = self.polo_actvie_orders(pair)
                count += 1
