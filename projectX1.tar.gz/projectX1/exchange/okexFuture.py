# -*- coding: utf-8 -*-

import logging
from utils import helper
from exchangeConnection.okex import okex_service

future_trade_type = ["", "开多", "开空", "平多", "平空"]


class OkexFutureExchange:
    def __init__(self, okex_accid, logger):
        self.OkexService = okex_service.get_okex_future(okex_accid)
        self.timeLog = logger
        self.exchange_name = "okexFuture"

    def okex_future_order(self, symbol, contract_type, tradeType, price, amount, match_price=0, leverage=10):
        """
        合约下单
        :param symbol: btc_usd:比特币    ltc_usd :莱特币
        :param contract_type: 合约类型 (this_week 周 next_week 次周 quarter 季合约)
        :param tradeType: 交易类型 1:开多   2:开空   3:平多   4:平空
        :param price: 价格
        :param amount: 金额数量
        :param leverage: 杠杆倍数 10 20
        """

        self.timeLog("开始下达okex订单  %s" % (future_trade_type[tradeType]))
        price_rounded = helper.downRound(float(price), 2)
        self.timeLog("做完小数点处理后 下单价格：%s， 下单金额：%s" % (price_rounded, amount))
        # 执行下单委托
        res = self.OkexService.future_trade(symbol, contract_type, price_rounded,
                                            amount,tradeType, match_price, leverage)
        if 'result' not in res.keys() or not res["result"]:
            self.timeLog("okex订单处理出错，信息如下: %s" % res, level=logging.WARN)
            return None
        order_id = res[u"order_id"]
        return order_id

    def okex_future_order_info(self, coin_type, contract_type, orderId, status=None, current_page=None, page_length=None):
        order_info_res = self.OkexService.future_order_info(coin_type, contract_type, str(orderId), status, current_page, page_length)
        if "result" not in order_info_res.keys() or not order_info_res["result"]:
            self.timeLog("查询订单出错，返回结果为 %s" % order_info_res)
            return None
        return order_info_res["orders"]

    def okex_order_cancel(self, coin_type, contract_type, id):
        order_cancel_res = self.OkexService.future_cancel(coin_type, contract_type, id)
        self.timeLog("撤销订单, 返回结果为 %s" % order_cancel_res)
        if "result" not in order_cancel_res.keys():
            if order_cancel_res["error"]:
                return False
            else:
                return True
        return order_cancel_res["result"]

    def okex_cancel_pending_orders(self, coin_type, contract_type):
        orders = self.okex_future_order_info(coin_type, contract_type, -1, status=1, current_page=1, page_length=50)
        pending_orders = [str(order["order_id"]) for order in orders if order["status"] in [0, 1]]
        count = 0
        max_order_number = 3
        while pending_orders is not None and len(pending_orders) > 0 and count < 3:
            for i in range(0, len(pending_orders), max_order_number):
                result = self.okex_order_cancel(coin_type, contract_type, ",".join(pending_orders[i:i+max_order_number]))
                self.timeLog("撤销订单, 返回结果为 %s" % result)
            if not result:
                orders = self.okex_future_order_info(coin_type, contract_type, -1, status=1)
                pending_orders = [str(order["order_id"]) for order in orders if order["status"] in [0, 1]]
            else:
                break


