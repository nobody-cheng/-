# -*- coding: utf-8 -*-

import logging
from utils import helper
import time
from exchangeConnection.huobi import huobiService
from exchangeConnection.huobi import util


class HuobiExchange:
    def __init__(self, huobi_accid, logger):
        self.HuobiService = huobiService.HuobiService(huobi_accid)
        self.timeLog = logger

        self.huobi_min_quantity = {"btc_cny": helper.HUOBI_BTC_MIN_ORDER_QTY,
                                   "ltc_cny": helper.HUOBI_LTC_MIN_ORDER_QTY, }

    def huobi_buy_limit(self, coin_type, price, quantity):
        """
        火币限价买入
        :param coin_type:
        :param price:
        :param quantity:
        :return:
        """
        if price is None or quantity is None:
            self.timeLog("限价单必须填写下单价格和数量")
            return None
        self.timeLog("开始下达火币限价买单...")
        self.timeLog("只保留下单数量的小数点后4位，下单价格的小数点后2位...")
        self.timeLog("原始下单数量:%s" % quantity)
        rounded_quantity = str(helper.downRound(float(quantity), 4))
        self.timeLog("做完小数点处理后的下单数量:%s" % rounded_quantity)

        if float(rounded_quantity) < self.huobi_min_quantity.get(coin_type):
            self.timeLog(
                "数量:%s 小于交易所最小交易数量(火币最小数量:%f),因此无法下单,此处忽略该信号" % (rounded_quantity, self.huobi_min_quantity.get(coin_type)),
                level=logging.WARN)
            return None

        self.timeLog("原始下单价格:%s" % price)
        rounded_price = str(helper.downRound(float(price), 2))
        self.timeLog("做完小数点处理后的下单价格:%s" % rounded_price)

        market = helper.COIN_TYPE_CNY
        if(coin_type == 'btc_cny'):
            res = self.HuobiService.buy(1, rounded_price, rounded_quantity, None, None, market, util.BUY)
        elif(coin_type == 'ltc_cny'):
            res = self.HuobiService.buy(2, rounded_price, rounded_quantity, None, None, market, util.BUY)
            
        if helper.componentExtract(res, u"result", "") != u'success':
            self.timeLog("下达火币限价买单（数量：%s，价格：%s）失败, 结果是：%s！" % (rounded_quantity, rounded_price, res),
                         level=logging.ERROR)
            return None
        order_id = res[u"id"]
        return order_id

    def huobi_sell_limit(self, coinType, price, quantity):
        if price is None or quantity is None:
            self.timeLog("限价单必须填写下单价格和数量")
            return None
        self.timeLog("开始下达火币限价卖单...")
        self.timeLog("只保留下单数量的小数点后4位，下单价格的小数点后2位...")
        self.timeLog("原始下单数量:%s" % quantity)
        rounded_quantity = str(helper.downRound(float(quantity), 4))
        self.timeLog("做完小数点处理后的下单数量:%s" % rounded_quantity)
        if float(rounded_quantity) < self.HuobiService.getMinimumOrderQty(coinType):
            self.timeLog(
                "数量:%s 小于交易所最小交易数量(火币最小数量:%f),因此无法下单,此处忽略该信号" % (rounded_quantity, self.huobi_min_quantity.get(coinType)),
                level=logging.WARN)
            return None

        self.timeLog("原始下单价格:%s" % price)
        rounded_price = str(helper.downRound(float(price), 2))
        self.timeLog("做完小数点处理后的下单价格:%s" % rounded_price)
        market = helper.COIN_TYPE_CNY
        if(coinType == 'btc_cny'):
            res = self.HuobiService.sell(1, rounded_price, rounded_quantity, None, None, market, util.SELL)
        elif(coinType == 'ltc_cny'):
            res = self.HuobiService.sell(2, rounded_price, rounded_quantity, None, None, market, util.SELL)
        if helper.componentExtract(res, u"result", "") != u'success':
            self.timeLog("下达火币限价卖单（数量：%s, 价格：%s）失败, 结果是: %s！" % (rounded_quantity, rounded_price, res),
                         level=logging.ERROR)
            return None
        order_id = res[u"id"]
        return order_id

    def huobi_sell_market(self, coinType, quantity):
        if quantity is None:
            self.timeLog("市价单卖出必须填写下单数量")
            return None
        self.timeLog("开始下达火币市价卖单...")
        self.timeLog("只保留下单数量的小数点后4位...")
        self.timeLog("原始下单数量:%s" % quantity)
        rounded_quantity = str(helper.downRound(float(quantity), 4))
        self.timeLog("做完小数点处理后的下单数量:%s" % rounded_quantity)

        if float(rounded_quantity) < self.huobi_min_quantity.get(coinType):
            self.timeLog(
                "数量:%s 小于交易所最小交易数量(火币最小数量:%f),因此无法下单,此处忽略该信号" % (rounded_quantity, self.huobi_min_quantity.get(coinType)),
                level=logging.WARN)
            return None
        market = helper.COIN_TYPE_CNY

        res = self.HuobiService.sellMarket(coinType, rounded_quantity, None, None, market, util.SELL_MARKET)
        if helper.componentExtract(res, u"result", "") != u'success':
            self.timeLog("下达火币市价卖单（数量：%s）失败, 结果是: %s！" % (rounded_quantity, res),
                         level=logging.ERROR)
            return None
        order_id = res[u"id"]
        return order_id

    def huobi_buy_market(self, coinType, cash_amount):
        """
        火币市价买入
        :param coinType:  币种 1 比特币 2 莱特币
        :param cash_amount:
        :return:
        """
        if cash_amount is None:
            self.timeLog("市价单买入必须填写下单金额")
            return None
        self.timeLog("开始下达火币市价买单...")
        self.timeLog("只保留下单数量的小数点后2位...")
        self.timeLog("原始下单金额:%s" % cash_amount)
        cash_amount = str(helper.downRound(float(cash_amount), 2))
        self.timeLog("做完小数点处理后的下单金额:%s" % cash_amount)
        if float(cash_amount) < self.HuobiService.getMinimumOrderCashAmount():
            self.timeLog("金额:%s 小于交易所最小交易金额(火币最小金额:%s元),因此无法下单,此处忽略该信号" %
                         (cash_amount, self.HuobiService.getMinimumOrderCashAmount()),
                         level=logging.WARN)
            return None
        market = helper.COIN_TYPE_CNY
        res = self.HuobiService.buyMarket(coinType, cash_amount, None, None, market, util.BUY_MARKET)
        if helper.componentExtract(res, u"result", "") != u'success':
            self.timeLog("下达火币市价买单（金额：%s）失败, 结果是：%s！" % (cash_amount, res),
                         level=logging.ERROR)
            return None
        order_id = res[u"id"]
        return order_id

    # 查询huobi订单执行情况, 返回订单执行status和成交数量
    # 当订单为市价买入时，processed_amount 是金额而不是数量
    def huobi_order_info(self, coinType, id):
        market = "cny"
        order_info = self.HuobiService.getOrderInfo(coinType, id, market, util.ORDER_INFO)
        if "status" not in order_info.keys():
            self.timeLog("查询火币订单失败，错误信息为 %s" % order_info)
            return None
        if order_info["type"] == helper.HUOBI_ORDER_TYPE_BUY_MARKET:
            if float(order_info["processed_price"]) == 0:
                deal_qty = 0
            else:
                deal_qty = float(order_info["processed_amount"]) / float(order_info["processed_price"])
        else:
            deal_qty = float(order_info["processed_amount"])

        return order_info["status"], deal_qty

    def huobi_full_order_info(self, coinType, id):
        market = helper.coinTypeStructure[self.coinMarketType]["huobi"]["market"]
        order_info = self.HuobiService.getOrderInfo(coinType, id, market, util.ORDER_INFO)
        if "status" not in order_info.keys():
            self.timeLog("查询火币订单失败，错误信息为 %s" % order_info)
            return order_info
        if order_info["type"] == helper.HUOBI_ORDER_TYPE_BUY_MARKET:
            if float(order_info["processed_price"]) == 0:
                deal_qty = 0
            else:
                deal_qty = float(order_info["processed_amount"]) / float(order_info["processed_price"])
        else:
            deal_qty = float(order_info["processed_amount"])

        return order_info["status"], deal_qty, order_info["processed_price"]

    def huobi_order(self, coinType, tradeType, orderType, price=None, cash_amount=None, quantity=None):
        """
        :param coinType: 1 比特币， 2 莱特币
        :param tradeType: 买卖方向， "buy" / "sell"
        :param orderType: 下单方式，"limit_order" / "market_order"
        :param price: 限价单必填
        :param cash_amount: 市价买入必填
        :param quantity: 限价单、市价卖出必填
        :return:
        """
        # 火币市价单
        if orderType is helper.ORDER_TYPE_MARKET_ORDER:
            # 市价买入
            if tradeType is helper.SPOT_TRADE_TYPE_BUY:
                res = self.huobi_buy_market(coinType, cash_amount)
            # 市价单卖出
            elif tradeType is helper.SPOT_TRADE_TYPE_SELL:
                res = self.huobi_sell_market(coinType, quantity)
            else:
                self.timeLog("下单tradeType参数错误", level=logging.ERROR)
                return None
        elif orderType is helper.ORDER_TYPE_LIMIT_ORDER:
            # 限价买入
            if tradeType is helper.SPOT_TRADE_TYPE_BUY:
                res = self.huobi_buy_limit(coinType, price, quantity)
            elif tradeType is helper.SPOT_TRADE_TYPE_SELL:
                res = self.huobi_sell_limit(coinType, price, quantity)
            else:
                self.timeLog("下单tradeType参数错误", level=logging.ERROR)
                return None
        else:
            self.timeLog("下单orderType参数错误", level=logging.ERROR)
            return None
        return res

    def huobi_order_cancel(self, coin_type, id):
        market = helper.COIN_TYPE_CNY
        cancel_result = self.HuobiService.cancelOrder(coin_type, id, market, util.CANCEL_ORDER)
        if "result" not in cancel_result.keys():
            if "code" in cancel_result.keys():
                if cancel_result["code"] == 41 or cancel_result["code"] == 42:
                    # 已经取消成功或已经全部成交
                    self.timeLog("撤销订单 %s" % id)
                    return u"success"
            self.timeLog("撤销订单失败，错误信息为 %s" % cancel_result)
            return None
        return cancel_result["result"]

    def huobi_get_active_orders(self, pair):
        coinType = helper.coinTypeStructure[pair]["huobi"]["coin_type"]
        market = helper.coinTypeStructure[pair]["huobi"]["market"]
        orders = self.HuobiService.getOrders(coinType, market, util.GET_ORDERS)
        return orders

    def huobi_cancel_pending_orders(self, order_id_list=None, pair=None, exclude_id_list=None):
        coinType = helper.coinTypeStructure[pair]["huobi"]["coin_type"]
        market = helper.coinTypeStructure[pair]["huobi"]["market"]
        orders = self.HuobiService.getOrders(coinType, market, util.GET_ORDERS)
        if order_id_list is None and exclude_id_list is None:
            count = 0
            while orders is not None and len(orders) > 0 and count < 3:
                for order in orders:
                    if helper.componentExtract(order, u"id", "") != "":
                        order_id = order[u"id"]
                        self.timeLog('撤销未成交订单。OrderID = %s' % order_id)
                        self.huobi_order_cancel(coinType, order_id)
                orders = self.HuobiService.getOrders(coinType, market, util.GET_ORDERS)
                time.sleep(0.2)
                count += 1
        elif order_id_list is not None:
            if orders is not None and len(orders) > 0:
                for order in orders:
                    if helper.componentExtract(order, u"id", "") != "" and order[u"id"] in order_id_list:
                        self.timeLog('撤销未成交订单。OrderID = %s' % order[u"id"])
                        self.huobi_order_cancel(coinType, order[u"id"])
        elif exclude_id_list is not None:
            if orders is not None and len(orders) > 0:
                for order in orders:
                    if helper.componentExtract(order, u"id", "") != "" and order[u"id"] not in exclude_id_list:
                        self.timeLog('撤销未成交订单。OrderID = %s' % order[u"id"])
                        self.huobi_order_cancel(coinType, order[u"id"])

    def huobi_order_info_detail(self, coinType, id):
        market = helper.coinTypeStructure[self.coinMarketType]["huobi"]["market"]
        order_info = self.HuobiService.getOrderInfo(coinType, id, market, util.ORDER_INFO)
        if "status" not in order_info.keys():
            self.timeLog("查询火币订单失败，错误信息为 %s" % order_info)
            return None
        if order_info["type"] == helper.HUOBI_ORDER_TYPE_BUY_MARKET:
            if float(order_info["processed_price"]) == 0:
                deal_qty = 0
            else:
                deal_qty = float(order_info["processed_amount"]) / float(order_info["processed_price"])
        else:
            deal_qty = float(order_info["processed_amount"])

        return [order_info["status"], deal_qty, float(order_info["processed_price"])]

    def get_huobi_latest_price(self, huobi_coin_type):
        try:
            trade = self.HuobiService.getTicker(huobi_coin_type, market='cny')
            price = trade['ticker']['last']
            return price
        except Exception as e:
            raise Exception('Get huobi latest price fail: %s' % str(e))
