# -*- coding: utf-8 -*-

import logging
from utils import helper
from exchangeConnection.bitfinex import bitfinexService
import time


class BitfinexExchange:
    def __init__(self, bitfinex_accid, logger):
        self.BitfinexService = bitfinexService.bitfinex_service(bitfinex_accid, 'trade')
        self.timeLog = logger
        self.exchange_name = "bitfinex"
        # self.bitstamp_min_quantity = {}

    def bitfinex_buy_limit(self, coinType, price, quantity):
        if price is None or quantity is None:
            self.timeLog("限价单必须填写下单价格和数量")
            return None
        self.timeLog("开始下达Bitfinex限价买单...")
        self.timeLog("只保留下单数量的小数点后4位，下单价格的小数点后2位...")
        self.timeLog("原始下单数量:%s" % quantity)
        rounded_quantity = str(helper.downRound(float(quantity), 4))
        self.timeLog("做完小数点处理后的下单数量:%s" % rounded_quantity)

        self.timeLog("原始下单价格:%s" % price)
        if coinType.split('_')[1] == 'usd':
            if coinType.split('_')[0] == 'xrp':
                rounded_price = '{:.5f}'.format((helper.downRound(float(price), 5)))
            else:
                rounded_price = str(helper.downRound(float(price), 2))
        elif coinType.split('_')[1] == 'btc':
            if coinType.split('_')[0] == 'xrp':
                rounded_price = '{:.8f}'.format((helper.downRound(float(price), 8)))
            else:
                rounded_price = str(helper.downRound(float(price), 6))
            
        self.timeLog("做完小数点处理后的下单价格:%s" % rounded_price)
        try:
            res = self.BitfinexService.bid(self.BitfinexService.create_symbol(coinType), rounded_price, rounded_quantity)
            if isinstance(res, dict):
                order_id = res["id"]
            else:
                self.timeLog(res)
                raise Exception
            return order_id
        except Exception as e:
            self.timeLog(
                "下达Bitfinex限价买单（数量：%s，价格：%s）失败, 结果是：%s！" % (rounded_quantity, rounded_price, str(e)),
                level=logging.ERROR)
            return None

    def bitfinex_sell_limit(self, coinType, price, quantity):
        if price is None or quantity is None:
            self.timeLog("限价单必须填写下单价格和数量")
            return None
        self.timeLog("开始下达Bitfinex限价卖单...")
        self.timeLog("只保留下单数量的小数点后4位，下单价格的小数点后2位...")
        self.timeLog("原始下单数量:%s" % quantity)
        rounded_quantity = str(helper.downRound(float(quantity), 4))
        self.timeLog("做完小数点处理后的下单数量:%s" % rounded_quantity)
        
        self.timeLog("原始下单价格:%s" % price)
        if(coinType.split('_')[1] == 'usd'):
            if coinType.split('_')[0] == 'xrp':
                rounded_price = '{:.5f}'.format((helper.downRound(float(price), 5)))
            else:
                rounded_price = str(helper.downRound(float(price), 2))
        elif coinType.split('_')[1] == 'btc':
            if coinType.split('_')[0] == 'xrp':
                rounded_price = '{:.8f}'.format((helper.downRound(float(price), 8)))
            else:
                rounded_price = str(helper.downRound(float(price), 6))
            
        self.timeLog("做完小数点处理后的下单价格:%s" % rounded_price)
        try:
            res = self.BitfinexService.ask(self.BitfinexService.create_symbol(coinType),
                                           rounded_price, rounded_quantity)
            if isinstance(res, dict):
                order_id = res["id"]
            else:
                self.timeLog(res)
                raise Exception
            return order_id
        except Exception as e:
            self.timeLog(
                "下达Bitfinex限价卖单（数量：%s，价格：%s）失败, 结果是：%s！" % (rounded_quantity,
                                                           rounded_price, str(e)),
                level=logging.ERROR)
            return None

    def bitfinex_order_info(self, order_id):
        order_info = self.BitfinexService.order(order_id)
        return order_info

    def bitfinex_order_cancel(self, order_id):
        self.timeLog("正在撤消bitfinex订单 order id: %s" % order_id)
        try:
            res = self.BitfinexService.cancel_order(int(order_id))
            return res
        except Exception as e:
            self.timeLog("bitfinex订单撤销失败. order id: %s" % order_id)
            return u"failed"

    def bitfinex_cancel_pending_order(self, coin_type, order_id_list=None):
        res = self.BitfinexService.orders()
        active_orders = [order["id"] for order in res if order["symbol"] == self.BitfinexService.create_symbol(coin_type)]
        self.timeLog("获取bitfinex订单 order id: %s" % active_orders)
        count = 0
        if order_id_list is None:
            while active_orders is not None and len(active_orders) > 0 and count < 3:
                for order_id in active_orders:
                    self.bitfinex_order_cancel(order_id)
                time.sleep(2)
                res = self.BitfinexService.orders()
                active_orders = [order["id"] for order in res if order["symbol"] == self.BitfinexService.create_symbol(coin_type)]
                count += 1
        else:
            while active_orders is not None and len(active_orders) > 0 and len(order_id_list) > 0 and count < 3:
                active_orders_in_order_list = [order_id for order_id in active_orders if order_id in order_id_list]
                for order_id in active_orders_in_order_list:
                    self.bitfinex_order_cancel(order_id)
                time.sleep(2)
                res = self.BitfinexService.orders()
                active_orders = [order["id"] for order in res if order["symbol"] == self.BitfinexService.create_symbol(coin_type)]
                count += 1

    def bitfinex_get_active_orders(self, coin_type):
        res = self.BitfinexService.orders()
        active_orders = [int(order["id"]) for order in res if order["symbol"] == self.BitfinexService.create_symbol(coin_type)]
        return active_orders

