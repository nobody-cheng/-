# -*- coding: utf-8 -*-

import logging
from utils import helper
from exchangeConnection.kraken import KrakenService
import traceback


class KrakenExchange:
    def __init__(self, kraken_accid, logger):
        self.krakenService = KrakenService.kraken_service(kraken_accid, "trade")
        self.timeLog = logger
        self.exchange_name = "kraken"

    @staticmethod
    def kraken_min_order_qty(coin_type):
        base_cur = coin_type.split('_')[0]
        if base_cur == 'btc':
            return 0.002
        elif base_cur == 'bcc':
            return 0.002
        elif base_cur == 'ltc':
            return 0.1
        elif base_cur == 'etc':
            return 0.3
        elif base_cur == 'eth':
            return 0.02
        elif base_cur == 'xrp':
            return 30
        elif base_cur == 'xmr':
            return 0.1
        elif base_cur == 'zec':
            return 0.03
        elif base_cur == 'usdt':
            return 5
        else:
            raise ValueError('pair <%s> is not supported in Kraken' % coin_type)

    @staticmethod
    def kraken_price_round(price, coin_type):
        if coin_type in ['xrp_btc']:
            precision = 8
        elif coin_type in ['ltc_btc', 'etc_btc', 'xmr_btc']:
            precision = 6
        elif coin_type in ['bcc_btc', 'etc_eth', 'eth_btc', 'xrp_usd', 'xrp_eur', 'zec_btc']:
            precision = 5
        elif coin_type in ['usdt_usd']:
            precision = 4
        elif coin_type in ['etc_eur', 'etc_usd']:
            precision = 3
        elif coin_type in ['ltc_usd', 'ltc_eur', 'eth_usd', 'eth_eur', 'xmr_usd', 'xmr_eur', 'zec_eur', 'zec_usd']:
            precision = 2
        elif coin_type in ['btc_usd', 'btc_eur', 'bcc_usd', 'bcc_eur']:
            precision = 1
        else:
            raise ValueError('pair <%s> is not supported in kraken' % coin_type)
        return helper.downRound(price, decimal_places=precision)

    def kraken_buy_limit(self, coin_type, price, quantity, expiretm=0):
        """
        kraken buy limit
        :param coin_type:
        :param rounded_price:
        :param rounded_quantity:
        :return:
        """
        if price is None or quantity is None:
            self.timeLog("need both price/quantity")
            return None
        rounded_quantity = str(helper.downRound(float(quantity), 4))
        min_order_qty = self.kraken_min_order_qty(coin_type)
        if float(rounded_quantity) < min_order_qty:
            self.timeLog(
                "quantity:%s too small (kraken minimum:%f)" % (rounded_quantity, min_order_qty),
                level=logging.WARN)
            return None
        rounded_price = str(self.kraken_price_round(float(price), coin_type=coin_type))
        self.timeLog("kraken buy %s at %s for %s" % (coin_type, rounded_price, rounded_quantity))
        kraken_coinType, currency = coin_type.split("_")
        try:
            res = self.krakenService.buy_limit(kraken_coinType, currency, rounded_price, rounded_quantity, expiretm=expiretm)
            
            if res.get('txid'):
                order_id = res['txid']
                return order_id
            else:
                self.timeLog("buy %s at %s for %s" % (coin_type, price, quantity))
                self.timeLog(res)
                return -1
        except Exception as e:
            self.timeLog(traceback.format_exc())
            self.timeLog("Failed: kraken buy %s at %s for %s - %s!" %
                (coin_type, rounded_price, rounded_quantity, str(e)), level=logging.ERROR)
            return None

    def kraken_sell_limit(self, coin_type, price, quantity, expiretm=0):
        """
        limit order
        :param rounded_price:
        :param rouned_quantity:
        :return:
        """
        if price is None or quantity is None:
            self.timeLog("need both price/quantity")
            return None
        rounded_quantity = str(helper.downRound(float(quantity), 4))
        min_order_qty = self.kraken_min_order_qty(coin_type)
        if float(rounded_quantity) < min_order_qty:
            self.timeLog(
                "quantity:%s too small (kraken minimum:%f)" % (rounded_quantity, min_order_qty),
                level=logging.WARN)
            return None
        rounded_price = str(self.kraken_price_round(float(price), coin_type=coin_type))
        self.timeLog("kraken sell %s at %s for %s" % (coin_type, rounded_price, rounded_quantity))
        kraken_coinType, currency = coin_type.split('_')
        try:
            res = self.krakenService.sell_limit(kraken_coinType, currency, rounded_price, rounded_quantity, expiretm=expiretm)

            if res.get('txid'):
                order_id = res['txid']
                return order_id
            else:
                self.timeLog("sell %s at %s for %s" % (coin_type, price, quantity))
                self.timeLog(res)
                return -1
        except Exception as e:
            self.timeLog(traceback.format_exc())
            self.timeLog("Failed: kraken sell %s at %s for %s - %s!" %
                (coin_type, rounded_price, rounded_quantity, str(res)), level=logging.ERROR)
            return None

    def kraken_order_info(self, ord_id):
        order_info = self.krakenService.get_order_info(ord_id)
        if "status" in order_info.keys():
            return order_info
        else:
            return None

    def kraken_order_cancel(self, ord_id):
        self.timeLog("Cancel kraken order, order id: %s" % ord_id)
        try:
            res = self.krakenService.cancel_order(str(ord_id))
            return res
        except Exception as e:
            self.timeLog(traceback.format_exc())
            self.timeLog("Cancel kraken order failed. order id: %s" % ord_id)
            return u"failed"

    def kraken_cancel_pending_orders(self, order_id_list=None, pair=None, side=None, direct_cancel=True):
        active_orders = self.krakenService.get_active_orders(pair=pair, side=side)
        cxl_list = []
        if order_id_list is None:
            if(active_orders is not None and len(active_orders) > 0):
                for order_id in active_orders:
                    if(direct_cancel):
                        self.kraken_order_cancel(order_id)
                    cxl_list.append(order_id)
        else:
            if(active_orders is not None and len(active_orders) > 0 and len(order_id_list)>0):
                for order_id in active_orders:
                    if(direct_cancel):
                        self.kraken_order_cancel(order_id)
                    cxl_list.append(order_id)
        return cxl_list

    def kraken_get_active_orders(self, pair=None, side=None):
        active_orders = self.krakenService.get_active_orders(pair=pair, side=side)
        return active_orders
