# -*- coding: utf-8 -*-

import logging
import time
from utils import helper
from exchangeConnection.pro import proService


class ProExchange:
    def __init__(self, pro_accid, logger):
        self.ProService = proService.ProServiceAPIKey(pro_accid)
        self.timeLog = logger
        self.exchange_name = "pro"

    def pro_buy_limit(self, price, quantity, pair):
        """
        limit order
        :param rounded_price:
        :param quantity:
        :param pair: 'eth_btc' or 'ltc_btc'
        :return:
        """
        symbol = pair.replace('_', '')
        if price is None or quantity is None:
            self.timeLog("限价单必须填写下单价格和数量")
            return None
        self.timeLog("开始下达Pro限价买单...只保留下单数量的小数点后4位，下单价格的小数点后6位...")
        self.timeLog("原始下单数量:%s" % quantity)
        rounded_quantity = str(helper.getRoundedQuantity(float(quantity), pair))
        self.timeLog("做完小数点处理后的下单数量:%s" % rounded_quantity)
        min_order_qty = self.pro_min_order_qty(pair)
        if float(rounded_quantity) < min_order_qty:
            self.timeLog(
                "数量:%s 小于交易所最小交易数量(Pro最小数量:%f),因此无法下单,此处忽略该信号" % (rounded_quantity, min_order_qty),
                level=logging.WARN)
            return None
        self.timeLog("原始下单价格:%s" % price)
        rounded_price = str(self.pro_price_round(float(price), pair=pair))
        self.timeLog("做完小数点处理后的下单价格:%s" % rounded_price)
        try:
            res = self.ProService.order(symbol, rounded_price, rounded_quantity, "buy-limit")
            if res['status'] == 'ok':
                order_id = res['data']
            else:
                raise Exception
            return order_id
        except Exception as e:
            self.timeLog(
                "下达Pro限价买单（数量：%s，价格：%s）失败, 结果是：%s！" % (rounded_quantity, rounded_price, str(e)), level=logging.ERROR)
            return None

    def pro_sell_limit(self, price, quantity, pair):
        """
        limit order
        :param price:
        :param quantity:
        :param pair: 'eth_btc' or 'ltc_btc'
        :return:
        """
        symbol = pair.replace('_', '')
        if price is None or quantity is None:
            self.timeLog("限价单必须填写下单价格和数量")
            return None
        self.timeLog("开始下达Pro限价卖单...")
        self.timeLog("只保留下单数量的小数点后4位，下单价格的小数点后6位...")
        self.timeLog("原始下单数量:%s" % quantity)
        rounded_quantity = str(helper.getRoundedQuantity(float(quantity), pair))
        self.timeLog("做完小数点处理后的下单数量:%s" % rounded_quantity)
        min_order_qty = self.pro_min_order_qty(pair)
        if float(rounded_quantity) < min_order_qty:
            self.timeLog(
                "数量:%s 小于交易所最小交易数量(Pro最小数量:%f),因此无法下单,此处忽略该信号" % (rounded_quantity, min_order_qty),
                level=logging.WARN)
            return None
        self.timeLog("原始下单价格:%s" % price)
        rounded_price = str(self.pro_price_round(float(price), pair=pair))
        self.timeLog("做完小数点处理后的下单价格:%s" % rounded_price)
        res = None
        try:
            res = self.ProService.order(symbol, rounded_price, rounded_quantity, "sell-limit")
            if res['status'] == 'ok':
                order_id = res['data']
            else:
                raise Exception
            return order_id
        except Exception as e:
            self.timeLog(
                "下达Pro限价卖单（数量：%s，价格：%s）失败, 结果是：%s！" % (rounded_quantity, rounded_price, str(e)), level=logging.ERROR)
            return None

    def pro_buy_market(self, coinType, cash_amount):
        self.timeLog("开始下达pro市价买单...")
        self.timeLog("只保留下单数量的小数点后2位...")
        self.timeLog("原始下单金额:%s" % cash_amount)
        rounded_cash_amount = str(helper.downRound(float(cash_amount), 2))
        self.timeLog("做完小数点处理后的下单金额:%s" % rounded_cash_amount)
        symbol = coinType.replace('_', '')
        try:
            res = self.ProService.order(symbol, None, rounded_cash_amount, "buy-market")
            if res['status'] == 'ok':
                order_id = res['data']
            else:
                raise Exception
            return order_id
        except Exception as e:
            self.timeLog(
                "下达Bitex市价买单（金额：%s）失败, 结果是：%s！" % (rounded_cash_amount, str(e)),
                level=logging.ERROR)
            return None

    def pro_sell_market(self, coinType, quantity):
        self.timeLog("开始下达pro市价卖单...")
        self.timeLog("只保留下单数量的小数点后4位...")
        self.timeLog("原始下单数量:%s" % quantity)
        rounded_quantity = str(helper.downRound(float(quantity), 4))
        self.timeLog("做完小数点处理后的下单数量:%s" % rounded_quantity)
        symbol = coinType.replace('_', '')
        try:
            res = self.ProService.order(symbol, None, rounded_quantity, "sell-market")
            if res['status'] == 'ok':
                order_id = res['data']
            else:
                raise Exception
            return order_id
        except Exception as e:
            self.timeLog(
                "下达Bitex市价卖单（数量：%s）失败, 结果是：%s！" % (rounded_quantity, str(e)),
                level=logging.ERROR)
            return None


    @staticmethod
    def pro_min_order_qty(pair):
        if pair == 'eth_btc':
            return helper.PRO_ETH_BTC_MIN_ORDER_QTY
        elif pair == 'bcc_btc':
            return helper.PRO_BCC_BTC_MIN_ORDER_QTY
        elif pair == 'ltc_btc':
            return helper.PRO_LTC_BTC_MIN_ORDER_QTY
        elif pair == 'etc_btc':
            return helper.PRO_ETC_BTC_MIN_ORDER_QTY
        elif pair == 'bt1_btc':
            return helper.PRO_BT1_BTC_MIN_ORDER_QTY
        elif pair == 'bt2_btc':
            return helper.PRO_BT2_BTC_MIN_ORDER_QTY
        elif pair == "eos_btc":
            return helper.PRO_EOS_BTC_MIN_ORDER_QTY
        elif pair == "knc_btc":
            return helper.PRO_KNC_BTC_MIN_ORDER_QTY
        elif pair == "ast_btc":
            return helper.PRO_AST_BTC_MIN_ORDER_QTY
        elif pair == "zrx_btc":
            return helper.PRO_ZRX_BTC_MIN_ORDER_QTY
        elif pair == "tnt_btc":
            return helper.PRO_TNT_BTC_MIN_ORDER_QTY
        elif pair == "omg_btc":
            return helper.PRO_OMG_BTC_MIN_ORDER_QTY
        elif pair == "storj_btc":
            return helper.PRO_STORJ_BTC_MIN_ORDER_QTY
        elif pair == "dash_btc":
            return helper.PRO_DASH_BTC_MIN_ORDER_QTY
        elif pair == "xrp_btc":
            return helper.PRO_XRP_BTC_MIN_ORDER_QTY
        elif pair == "tnb_btc":
            return helper.PRO_TNB_BTC_MIN_ORDER_QTY
        elif pair == "itc_btc":
            return helper.PRO_ITC_BTC_MIN_ORDER_QTY
        elif pair == 'btc_usdt':
            return helper.PRO_BTC_USDT_MIN_ORDER_QTY
        elif pair == 'eth_usdt':
            return helper.PRO_ETH_USDT_MIN_ORDER_QTY
        elif pair == 'ltc_usdt':
            return helper.PRO_LTC_USDT_MIN_ORDER_QTY
        elif pair == 'bcc_usdt':
            return helper.PRO_BCC_USDT_MIN_ORDER_QTY
        elif pair == 'etc_usdt':
            return helper.PRO_ETC_USDT_MIN_ORDER_QTY
        elif pair == 'dash_usdt':
            return helper.PRO_DASH_USDT_MIN_ORDER_QTY
        elif pair == 'xrp_usdt':
            return helper.PRO_XRP_USDT_MIN_ORDER_QTY
        elif pair == "pay_btc":
            return helper.PRO_PAY_BTC_MIN_ORDER_QTY
        elif pair == "mtl_btc":
            return helper.PRO_MTL_BTC_MIN_ORDER_QTY
        elif pair == "snt_btc":
            return helper.PRO_SNT_BTC_MIN_ORDER_QTY
        elif pair == "rdn_btc":
            return helper.PRO_RDN_BTC_MIN_ORDER_QTY
        elif pair == "rcn_btc":
            return helper.PRO_RCN_BTC_MIN_ORDER_QTY
        elif pair == "qsp_btc":
            return helper.PRO_QSP_BTC_MIN_ORDER_QTY
        elif pair == "btg_btc":
            return 0.01
        elif pair == "bcd_btc":
            return 0.01
        elif pair == "dgd_btc":
            return 1
        elif pair == "gnt_btc":
            return 1
        elif pair == "omg_eth":
            return helper.PRO_OMG_ETH_MIN_ORDER_QTY
        elif pair == "rdn_eth":
            return helper.PRO_RDN_ETH_MIN_ORDER_QTY
        elif pair == "eos_eth":
            return helper.PRO_EOS_ETH_MIN_ORDER_QTY
        elif pair == "tnt_eth":
            return helper.PRO_TNT_ETH_MIN_ORDER_QTY
        elif pair == "qsp_eth":
            return helper.PRO_QSP_ETH_MIN_ORDER_QTY
        elif pair == "rcn_eth":
            return helper.PRO_RCN_ETH_MIN_ORDER_QTY
        elif pair == "tnb_eth":
            return helper.PRO_TNB_ETH_MIN_ORDER_QTY
        elif pair == "itc_eth":
            return helper.PRO_ITC_ETH_MIN_ORDER_QTY
        elif pair == "pay_eth":
            return 1
        elif pair == "dgd_eth":
            return 1
        elif pair == "gnt_eth":
            return 1
        else:
            raise ValueError('pair <%s> is not supported in Pro' % pair)

    @staticmethod
    def pro_price_precision(pair):
        if pair == 'eth_btc':
            precision = 6
        elif pair == 'etc_btc':
            precision = 6
        elif pair == 'ltc_btc':
            precision = 6
        elif pair == 'bcc_btc':
            precision = 6
        elif pair == 'bt1_btc':
            precision = 6
        elif pair == 'bt2_btc':
            precision = 6
        elif pair == 'btc_usdt':
            precision = 2
        elif pair == 'btg_btc':
            precision = 6
        elif pair == 'bcd_btc':
            precision = 6
        elif pair == 'eth_usdt':
            precision = 2
        elif pair == 'ltc_usdt':
            precision = 2
        elif pair == 'bcc_usdt':
            precision = 2
        elif pair == 'etc_usdt':
            precision = 2
        elif pair == 'dash_usdt':
            precision = 2
        elif pair == 'xrp_usdt':
            precision = 4
        elif pair == "eos_btc":
            precision = 8
        elif pair == "knc_btc":
            precision = 8
        elif pair == "ast_btc":
            precision = 8
        elif pair == "zrx_btc":
            precision = 8
        elif pair == "tnt_btc":
            precision = 6
        elif pair == "omg_btc":
            precision = 6
        elif pair == "storj_btc":
            precision = 8
        elif pair == "pay_btc":
            precision = 6
        elif pair == "dgd_btc":
            precision = 6
        elif pair == "gnt_btc":
            precision = 8
        elif pair == "mtl_btc":
            precision = 6
        elif pair == "snt_btc":
            precision = 8
        elif pair == "dash_btc":
            precision = 6
        elif pair == "rdn_btc":
            precision = 8
        elif pair == "qsp_btc":
            precision = 8
        elif pair == "rcn_btc":
            precision = 8
        elif pair == "xrp_btc":
            precision = 8
        elif pair == "btg_btc":
            precision = 6
        elif pair == "bcd_btc":
            precision = 6
        elif pair == "tnb_btc":
            precision = 8
        elif pair == "itc_btc":
            precision = 8
        elif pair == "omg_eth":
            precision = 6
        elif pair == "rdn_eth":
            precision = 8
        elif pair == "qsp_eth":
            precision = 8
        elif pair == "rcn_eth":
            precision = 8
        elif pair == "eos_eth":
            precision = 8
        elif pair == "tnt_eth":
            precision = 8
        elif pair == "tnb_eth":
            precision = 8
        elif pair == "itc_eth":
            precision = 8
        elif pair == "pay_eth":
            precision = 6
        elif pair == "dgd_eth":
            precision = 6
        elif pair == "gnt_eth":
            precision = 8
        else:
            raise ValueError('pair <%s> is not supported in Pro' % pair)
        return precision

    def pro_price_round(self, price, pair):
        precision = self.pro_price_precision(pair)
        return helper.downRound(price, decimal_places=precision)

    def pro_order_info(self, id):
        order_info = self.ProService.get_order_info(id)
        if "status" in order_info.keys() and order_info['status'] == 'ok':
            data = order_info['data']
            state = data['state']
            deal_qty = float(data['field-amount'])
            return state, deal_qty
        else:
            return None

    def pro_full_order_info(self, id):
        order_info = self.ProService.get_order_info(id)
        if "status" in order_info.keys() and order_info['status'] == 'ok':
            data = order_info['data']
            state = data['state']
            deal_qty = float(data['field-amount'])
            deal_value = float(data['field-cash-amount'])
            if deal_qty == 0:
                processed_price = 0
            else:
                processed_price = deal_value / deal_qty
            return state, deal_qty, processed_price
        else:
            return None

    def pro_order_cancel(self, id):
        self.timeLog("正在撤销pro订单。order id: %s" % id)
        res = self.ProService.cancel_order(id)
        if "status" in res.keys() and res['status'] == 'ok':
            self.timeLog("pro订单撤销成功. order id: %s" % id)
            return u"success"
        else:
            status, amt = self.pro_order_info(id)
            if status in ['filled', 'canceled', 'partial-canceled']:
                self.timeLog("pro订单已终结%s. order id: %s" % (status, id))
                return u"success"
            self.timeLog("pro订单撤销失败. order id: %s" % id)
            return u"failed"

    def pro_cancel_pending_orders(self, order_id_list=None, pair=None):
        symbol = pair.replace('_', '')
        ret = self.ProService.get_active_orders(symbol)
        #self.timeLog("ProService.get_active_orders. symbol: %s   result: %s" % (symbol, ret))
        orders = [order["id"] for order in ret['data']]
        max_order_number = 50
        if order_id_list is None:
            count = 0
            while orders is not None and len(orders) > 0 and count < 3:
                success_list = []
                for i in range(0, len(orders), max_order_number):
                    self.timeLog("批量删除pro订单 %s" % orders[i:i+max_order_number])
                    result = self.ProService.batch_cancel_order(orders[i:i+max_order_number])
                    self.timeLog("批量删除结果 {0}".format(result))
                    success_list.extend(result["data"]["success"])
                time.sleep(0.2)
                orders = [order["id"] for order in self.ProService.get_active_orders(symbol)['data']
                          if str(order["id"]) not in success_list]
                count += 1

        elif order_id_list is not None:
            count = 0
            cancel_orders = [order for order in orders if order in order_id_list or str(order) in order_id_list]
            while cancel_orders is not None and len(cancel_orders) > 0 and count < 3:
                success_list = []
                for i in range(0, len(cancel_orders), max_order_number):
                    self.timeLog("批量删除pro订单 %s" % cancel_orders)
                    result = self.ProService.batch_cancel_order(cancel_orders[i:i+max_order_number])
                    self.timeLog("批量删除结果 {0}".format(result))
                    success_list.extend(result["data"]["success"])
                time.sleep(0.2)
                orders = [order["id"] for order in self.ProService.get_active_orders(symbol)['data']
                          if str(order["id"]) not in success_list]
                count += 1
                cancel_orders = [order for order in orders if order in order_id_list or str(order) in order_id_list]

    def get_pro_latest_price(self, pair):
        symbol = pair.replace('_', '')
        self.ProService.get_latest_trade(symbol)
        try:
            trade = self.BitexService.get_latest_trade(symbol)
            price = trade['tick']['data'][0]['price']
            return price
        except Exception as e:
            raise Exception('Get pro latest price fail: %s' % str(e))

    def pro_get_active_orders(self, pair):
        symbol = pair.replace('_', '')
        orders = [order["id"] for order in self.ProService.get_active_orders(symbol)['data']]
        return orders
