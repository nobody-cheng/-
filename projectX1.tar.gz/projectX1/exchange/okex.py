# -*- coding: utf-8 -*-

import logging
from utils import helper
from exchangeConnection.okex import okex_service




class OkexSpotExchange:
    def __init__(self, okex_accid, logger):
        self.OkexService = okex_service.get_okex_spot(okex_accid)
        self.timeLog = logger
        self.okex_min_quantity = {"bcc_btc": 0.01, "ltc_btc": 0.1, "eth_btc": 0.1, "etc_btc":0.1, "bt1_bt2":0.1}
        self.exchange_name = "okex"

    def okex_buy_limit(self, coin_type, price, quantity):
        if price is None or quantity is None:
            self.timeLog("限价单必须填写下单价格和数量")
            return None
        self.timeLog("开始下达okex限价买单...只保留下单数量的小数点后3位...")
        rounded_quantity = str(helper.downRound(float(quantity), 3))
        self.timeLog("做完小数点处理后的下单数量:%s" % rounded_quantity)
        if float(rounded_quantity) < self.okex_min_quantity.get(coin_type):
            self.timeLog(
                "数量:%s 小于交易所最小交易数量(okcoin最小数量:%f),因此无法下单,此处忽略该信号" %
                (rounded_quantity, self.okex_min_quantity.get(coin_type)), level=logging.WARN)
            return None
        rounded_price = str(helper.downRound(float(price), 8))
        self.timeLog("做完小数点处理后的下单价格:%s" % rounded_price)
        res = self.OkexService.trade(coin_type, "buy", price=rounded_price, amount=rounded_quantity)
        if not helper.componentExtract(res, "result"):
            self.timeLog(
                "下达okex限价买单（数量：%s，价格：%s）失败, 结果是：%s！" % (rounded_quantity, rounded_price, res),
                level=logging.ERROR)
            return None
        order_id = res["order_id"]
        return order_id

    def okex_sell_limit(self, coin_type, price, quantity):
        if price is None or quantity is None:
            self.timeLog("限价单必须填写下单价格和数量")
            return None
        self.timeLog("开始下达okex限价卖单...只保留下单数量的小数点后3位...")
        rounded_quantity = str(helper.downRound(float(quantity), 3))
        self.timeLog("做完小数点处理后的下单数量:%s" % rounded_quantity)
        if float(rounded_quantity) < self.okex_min_quantity.get(coin_type):
            self.timeLog(
                "数量:%s 小于交易所最小交易数量(okcoin最小数量:%f),因此无法下单,此处忽略该信号" %
                (rounded_quantity, self.okex_min_quantity.get(coin_type)), level=logging.WARN)
            return None
        rounded_price = str(helper.downRound(float(price), 8))
        self.timeLog("做完小数点处理后的下单价格:%s" % rounded_price)
        res = self.OkexService.trade(coin_type, "sell", price=rounded_price, amount=rounded_quantity)
        if not helper.componentExtract(res, "result"):
            self.timeLog(
                "下达okex限价卖单（数量：%s, 价格：%s）失败, 结果是：%s" % (rounded_quantity, rounded_price, res),
                level=logging.ERROR)
            return None
        order_id = res["order_id"]
        return order_id

    def okex_buy_market(self, coin_type, cash_amount, sell_1_price):
        if sell_1_price is None:
            raise ValueError("处理okex市价买单之前，需要提供当前Okcoin卖一的价格信息，请检查传入的sell_1_price参数是否完备！")
        self.timeLog("开始下达okex市价买单...只保留下单数量的小数点后2位...")
        rounded_cash_amount = str(helper.downRound(float(cash_amount), 2))
        self.timeLog("做完小数点处理后的下单金额:%s" % rounded_cash_amount)

        if float(rounded_cash_amount) < self.okex_min_quantity.get(coin_type) * sell_1_price:
            self.timeLog(
                "金额:%s 不足以购买交易所最小交易数量(okcex最小数量:%f，当前卖一价格%.2f,最小金额要求：%.2f),因此无法下单,此处忽略该信号" % (
                    rounded_cash_amount, self.okex_min_quantity.get(coin_type), sell_1_price,
                    self.okex_min_quantity.get(coin_type) * sell_1_price),
                level=logging.WARN)
            return None

        res = self.OkexService.trade(coin_type, "buy_market", price=rounded_cash_amount)

        if not helper.componentExtract(res, "result"):
            self.timeLog("下达okex市价买单（金额：%s）失败, 结果是：%s！" % (rounded_cash_amount, res),
                         level=logging.ERROR)
            return None
        order_id = res["order_id"]
        return order_id

    def okex_sell_market(self, coin_type, quantity):
        if quantity is None:
            self.timeLog("市价卖出订单必须填写数量")
            return None
        self.timeLog("开始下达okex市价卖单...只保留下单数量的小数点后2位...")
        rounded_quantity = str(helper.downRound(float(quantity), 2))
        self.timeLog("做完小数点处理后的下单数量:%s" % rounded_quantity)
        if float(rounded_quantity) < self.okex_min_quantity.get(coin_type):
            self.timeLog(
                "数量:%s 小于交易所最小交易数量(okex最小数量:%f),因此无法下单,此处忽略该信号" %
                (rounded_quantity, self.okex_min_quantity.get(coin_type)), level=logging.WARN)
            return None

        res = self.OkexService.trade(coin_type, "sell_market", amount=rounded_quantity)
        if not helper.componentExtract(res, "result"):
            self.timeLog("下达okex市价卖单（数量：%s）失败, 结果是：%s" % (rounded_quantity, res),
                         level=logging.ERROR)
            return None
        order_id = res["order_id"]
        return order_id

    def okex_order_info(self, coin_type, order_id):
        order_info = self.OkexService.orderInfo(coin_type, int(order_id))
        if "status" not in order_info["orders"][0]:
            self.timeLog("查询okex订单失败，错误信息为 %s" % order_info)
            return None
        return order_info["orders"][0]["status"], float(order_info["orders"][0]["deal_amount"])

    def okex_order_cancel(self, coinType, id):
        cancel_result = self.OkexService.cancelOrder(coinType, str(id))
        return cancel_result

    def okex_order_info_detail(self, coin_type, order_id):
        coin_type = helper.coinTypeStructure[coin_type]["okcoin"]["coin_type"]
        order_info = self.OkexService.orderInfo(coin_type, str(order_id))
        if "status" not in order_info["orders"][0]:
            self.timeLog("查询okex订单失败，错误信息为 %s" % order_info)
            return None
        return [order_info["orders"][0]["status"], float(order_info["orders"][0]["deal_amount"]),
                float(order_info["orders"][0]["avg_price"])]

    def okex_cancel_pending_orders(self, pair, order_id_list=None):
        max_order_number = 3
        active_orders = [str(order["order_id"]) for order in self.OkexService.orderInfo(pair, -1).get("orders")]
        if order_id_list is None:
            count = 0
            while active_orders is not None and len(active_orders) > 0 and count < 3:
                for i in range(0, len(active_orders), max_order_number):
                    ret = self.okex_order_cancel(pair, ",".join(active_orders[i:i+max_order_number]))
                    self.timeLog("撤单结果：{0}".format(ret))
                active_orders = [str(order["order_id"]) for order in self.OkexService.orderInfo(pair, -1).get("orders")]
                count += 1
        else:
            count = 0
            while active_orders is not None and len(active_orders) > 0 and len(order_id_list)>0 and count < 3:
                active_orders_in_order_list = [order_id for order_id in active_orders if order_id in order_id_list]
                for i in range(0, len(active_orders), max_order_number):
                    ret = self.okex_order_cancel(pair, ",".join(active_orders_in_order_list[i:i+max_order_number]))
                    self.timeLog("撤单结果：{0}".format(ret))
                active_orders = [str(order["order_id"]) for order in self.OkexService.orderInfo(pair, -1).get("orders")]
                count += 1

    def okex_get_active_orders(self, pair):
        active_orders = [str(order["order_id"]) for order in self.OkexService.orderInfo(pair, -1).get("orders")]
        return active_orders


future_trade_type = ["", "开多", "开空", "平多", "平空"]


class OkexFutureExchange:
    def __init__(self, okex_accid, logger):
        self.OkexService = okex_service.get_okex_future(okex_accid)
        self.timeLog = logger

    def okex_future_order(self, symbol, contract_type, tradeType, price, amount, match_price=0, leverage=10):
        """
        合约下单
        :param symbol: btc_usd:比特币    ltc_usd :莱特币
        :param contract_type: 合约类型 (this_week 周 next_week 次周 quarter 季合约)
        :param tradeType: 交易类型 1:开多   2:开空   3:平多   4:平空
        :param price: 价格
        :param amount: 金额数量
        :param leverage: 杠杆倍数 10 20
        """

        self.timeLog("开始下达okex订单  %s" % (future_trade_type[tradeType]))
        price_rounded = helper.downRound(float(price), 2)
        self.timeLog("做完小数点处理后 下单价格：%s， 下单金额：%s" % (price_rounded, amount))
        # 执行下单委托
        res = self.OkexService.future_trade(symbol, contract_type, price_rounded,
                                            amount,tradeType, match_price, leverage)
        if 'result' not in res.keys() or not res["result"]:
            self.timeLog("okex订单处理出错，信息如下: %s" % res, level=logging.WARN)
            return None
        order_id = res[u"order_id"]
        return order_id

    def okex_future_order_info(self, coin_type, contract_type, orderId, status=None, current_page=None, page_length=None):
        order_info_res = self.OkexService.future_order_info(coin_type, contract_type, str(orderId), status, current_page, page_length)
        if "result" not in order_info_res.keys() or not order_info_res["result"]:
            self.timeLog("查询订单出错，返回结果为 %s" % order_info_res)
            return None
        return order_info_res["orders"]

    def okex_order_cancel(self, coin_type, contract_type, id):
        order_cancel_res = self.OkexService.future_cancel(coin_type, contract_type, id)
        self.timeLog("撤销订单, 返回结果为 %s" % order_cancel_res)
        if "result" not in order_cancel_res.keys():
            if order_cancel_res["error"]:
                return False
            else:
                return True
        return order_cancel_res["result"]

    def okex_cancel_pending_orders(self, coin_type, contract_type):
        orders = self.okex_future_order_info(coin_type, contract_type, -1, status=1, current_page=1, page_length=50)
        pending_orders = [str(order["order_id"]) for order in orders if order["status"] in [0, 1]]
        count = 0
        max_order_number = 3
        while pending_orders is not None and len(pending_orders) > 0 and count < 3:
            for i in range(0, len(pending_orders), max_order_number):
                result = self.okex_order_cancel(coin_type, contract_type, ",".join(pending_orders[i:i+max_order_number]))
                self.timeLog("撤销订单, 返回结果为 %s" % result)
            if not result:
                orders = self.okex_future_order_info(coin_type, contract_type, -1, status=1)
                pending_orders = [str(order["order_id"]) for order in orders if order["status"] in [0, 1]]
            else:
                break


