# -*- coding: utf-8 -*-

import logging
from utils import helper
from exchangeConnection.okcoin import util
import traceback


class OkcoinExchange:
    def __init__(self, okcoin_accid, logger):
        self.OKCoinService = util.getOkcoinSpot(okcoin_accid)
        self.timeLog = logger
        self.okcoin_min_quantity = {"btc_cny": 0.01, "ltc_cny": 0.1, "eth_cny": 0.1}

    def okcoin_buy_limit(self, coinType, price, quantity):
        if price is None or quantity is None:
            self.timeLog("限价单必须填写下单价格和数量")
            return None
        self.timeLog("开始下达okcoin限价买单...")
        self.timeLog("只保留下单数量的小数点后2位...")
        self.timeLog("原始下单数量:%s" % quantity)
        rounded_quantity = str(helper.downRound(float(quantity), 2))
        self.timeLog("做完小数点处理后的下单数量:%s" % rounded_quantity)
        if float(rounded_quantity) < self.okcoin_min_quantity.get(coinType):
            self.timeLog(
                "数量:%s 小于交易所最小交易数量(okcoin最小数量:%f),因此无法下单,此处忽略该信号" %
                (rounded_quantity, self.okcoin_min_quantity.get(coinType)), level=logging.WARN)
            return None
        self.timeLog("原始下单价格:%s" % price)
        rounded_price = str(helper.downRound(float(price), 2))
        self.timeLog("做完小数点处理后的下单价格:%s" % rounded_price)
        res = self.OKCoinService.trade(coinType, "buy", price=rounded_price, amount=rounded_quantity)
        if not helper.componentExtract(res, "result"):
            self.timeLog(
                "下达okcoin限价买单（数量：%s，价格：%s）失败, 结果是：%s！" % (rounded_quantity, rounded_price, res),
                level=logging.ERROR)
            return None
        order_id = res["order_id"]
        return order_id

    def okcoin_sell_limit(self, coinType, price, quantity):
        if price is None or quantity is None:
            self.timeLog("限价单必须填写下单价格和数量")
            return None
        self.timeLog("开始下达okcoin限价卖单...")
        self.timeLog("只保留下单数量的小数点后2位...")
        self.timeLog("原始下单数量:%s" % quantity)
        rounded_quantity = str(helper.downRound(float(quantity), 2))
        self.timeLog("做完小数点处理后的下单数量:%s" % rounded_quantity)
        if float(rounded_quantity) < self.okcoin_min_quantity.get(coinType):
            self.timeLog(
                "数量:%s 小于交易所最小交易数量(okcoin最小数量:%f),因此无法下单,此处忽略该信号" % (rounded_quantity, self.okcoin_min_quantity.get(coinType)),
                level=logging.WARN)
            return None
        self.timeLog("原始下单价格:%s" % price)
        rounded_price = str(helper.downRound(float(price), 2))
        self.timeLog("做完小数点处理后的下单价格:%s" % rounded_price)
        res = self.OKCoinService.trade(coinType, "sell", price=rounded_price, amount=rounded_quantity)
        if not helper.componentExtract(res, "result"):
            self.timeLog(
                "下达okcoin限价卖单（数量：%s, 价格：%s）失败, 结果是：%s" % (rounded_quantity, rounded_price, res),
                level=logging.ERROR)
            return None
        order_id = res["order_id"]
        return order_id

    # okcoin市价买入
    def okcoin_buy_market(self, coinType, cash_amount, sell_1_price):
        if sell_1_price is None:
            raise ValueError("处理okcoin市价买单之前，需要提供当前Okcoin卖一的价格信息，请检查传入的sell_1_price参数是否完备！")
        self.timeLog("开始下达okcoin市价买单...")
        self.timeLog("只保留下单数量的小数点后2位...")
        self.timeLog("原始下单金额:%s" % cash_amount)
        rounded_cash_amount = str(helper.downRound(float(cash_amount), 2))
        self.timeLog("做完小数点处理后的下单金额:%s" % rounded_cash_amount)

        if float(rounded_cash_amount) < self.okcoin_min_quantity.get(coinType) * sell_1_price:
            self.timeLog(
                "金额:%s 不足以购买交易所最小交易数量(okcoin最小数量:%f，当前卖一价格%.2f,最小金额要求：%.2f),因此无法下单,此处忽略该信号" % (
                    rounded_cash_amount, self.okcoin_min_quantity.get(coinType), sell_1_price,
                    self.okcoin_min_quantity.get(coinType) * sell_1_price),
                level=logging.WARN)
            return None

        res = self.OKCoinService.trade(coinType, "buy_market", price=rounded_cash_amount)

        if not helper.componentExtract(res, "result"):
            self.timeLog("下达okcoin市价买单（金额：%s）失败, 结果是：%s！" % (rounded_cash_amount, res),
                         level=logging.ERROR)
            return None
        order_id = res["order_id"]
        return order_id

    def okcoin_sell_market(self, coinType, quantity):
        if quantity is None:
            self.timeLog("市价卖出订单必须填写数量")
            return None
        self.timeLog("开始下达okcoin市价卖单...")
        self.timeLog("只保留下单数量的小数点后2位...")
        self.timeLog("原始下单数量:%s" % quantity)
        rounded_quantity = str(helper.downRound(float(quantity), 2))
        self.timeLog("做完小数点处理后的下单数量:%s" % rounded_quantity)
        if float(rounded_quantity) < self.okcoin_min_quantity.get(coinType):
            self.timeLog(
                "数量:%s 小于交易所最小交易数量(okcoin最小数量:%f),因此无法下单,此处忽略该信号" % (rounded_quantity, self.okcoin_min_quantity.get(coinType)),
                level=logging.WARN)
            return None

        res = self.OKCoinService.trade(coinType, "sell_market", amount=rounded_quantity)
        if not helper.componentExtract(res, "result"):
            self.timeLog("下达okcoin市价卖单（数量：%s）失败, 结果是：%s" % (rounded_quantity, res),
                         level=logging.ERROR)
            return None
        order_id = res["order_id"]
        return order_id

    def okcoin_order(self, coinType, tradeType, orderType, price=None, cash_amount=None, quantity=None,
                     sell_1_price=None):
        coinType = helper.coinTypeStructure[coinType]["okcoin"]["coin_type"]
        # okcoin市价单
        if orderType is helper.ORDER_TYPE_MARKET_ORDER:
            # 市价买入
            if tradeType is helper.SPOT_TRADE_TYPE_BUY:
                res = self.okcoin_buy_market(coinType, cash_amount, sell_1_price=sell_1_price)
            # 市价单卖出
            elif tradeType is helper.SPOT_TRADE_TYPE_SELL:
                res = self.okcoin_sell_market(coinType, quantity)
            else:
                self.timeLog("下单tradeType参数错误", level=logging.ERROR)
                return None
        # okcoin限价单
        elif orderType is helper.ORDER_TYPE_LIMIT_ORDER:
            # 限价买入
            if tradeType is helper.SPOT_TRADE_TYPE_BUY:
                res = self.okcoin_buy_limit(coinType, price, quantity)
            elif tradeType is helper.SPOT_TRADE_TYPE_SELL:
                res = self.okcoin_sell_limit(coinType, price, quantity)
            else:
                self.timeLog("下单tradeType参数错误", level=logging.ERROR)
                return None
        else:
            self.timeLog("下单orderType参数错误", level=logging.ERROR)
            return None
        return res

    def okcoin_order_info(self, coinType, id):
        coinType = helper.coinTypeStructure[coinType]["okcoin"]["coin_type"]
        order_info = self.OKCoinService.orderInfo(coinType, str(id))
        if "status" not in order_info["orders"][0]:
            self.timeLog("查询okcoin订单失败，错误信息为 %s" % order_info)
            return None
        return order_info["orders"][0]

    def okcoin_order_cancel(self, coinType, id):
        coinType = helper.coinTypeStructure[coinType]["okcoin"]["coin_type"]
        cancel_result = self.OKCoinService.cancelOrder(coinType, str(id))
        if "result" not in cancel_result.keys():
            self.timeLog("撤销订单失败，错误信息为 %s" % cancel_result)
            return None
        if cancel_result["result"] == "true":
            return u'success'
        else:
            return u'fail'
