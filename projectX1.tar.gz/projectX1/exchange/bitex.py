# -*- coding: utf-8 -*-

import logging
from utils import helper
import time
from exchangeConnection.bitex import bitexService


class BitexExchange:
    def __init__(self, bitex_accid, logger):
        self.BitexService = bitexService.BitexServiceAPIKey(acc_id=bitex_accid)
        self.timeLog = logger

        self.bitex_min_quantity = {helper.HUOBI_COIN_TYPE_ETH: helper.BITEX_ETH_MIN_ORDER_QTY,
                                   helper.HUOBI_COIN_TYPE_ETC: helper.BITEX_ETC_MIN_ORDER_QTY,
                                   helper.HUOBI_COIN_TYPE_BCC: helper.BITEX_BCC_MIN_ORDER_QTY, }
        self.exchange_name = "bitex"

    # bitex限价买入
    def bitex_buy_limit(self, coinType, price, quantity):
        if price is None or quantity is None:
            self.timeLog("限价单必须填写下单价格和数量")
            return None
        self.timeLog("开始下达Bitex限价买单...")
        self.timeLog("只保留下单数量的小数点后4位，下单价格的小数点后2位...")
        self.timeLog("原始下单数量:%s" % quantity)
        rounded_quantity = str(helper.downRound(float(quantity), 4))
        self.timeLog("做完小数点处理后的下单数量:%s" % rounded_quantity)

        if float(rounded_quantity) < self.bitex_min_quantity.get(coinType):
            self.timeLog(
                "数量:%s 小于交易所最小交易数量(火币最小数量:%f),因此无法下单,此处忽略该信号" %
                (rounded_quantity, self.bitex_min_quantity.get(coinType)),
                level=logging.WARN)
            return None

        self.timeLog("原始下单价格:%s" % price)
        rounded_price = str(helper.downRound(float(price), 2))
        self.timeLog("做完小数点处理后的下单价格:%s" % rounded_price)
        symbol = self.bitex_coinType_to_symbol(coinType)
        try:
            res = self.BitexService.order(symbol, rounded_price, rounded_quantity, "buy-limit")
            if res['status'] == 'ok':
                order_id = res['data']
            else:
                raise Exception
            return order_id
        except Exception as e:
            self.timeLog(
                "下达Bitex限价买单（数量：%s，价格：%s）失败, 结果是：%s！" % (rounded_quantity, rounded_price, str(e)),
                level=logging.ERROR)
            return None

    @staticmethod
    def bitex_coinType_to_symbol(coinType):
        if coinType == helper.HUOBI_COIN_TYPE_BTC:
            symbol = 'btccny'
        elif coinType == helper.HUOBI_COIN_TYPE_LTC:
            symbol = 'ltccny'
        elif coinType == helper.HUOBI_COIN_TYPE_ETH:
            symbol = 'ethcny'
        elif coinType == helper.HUOBI_COIN_TYPE_BCC:
            symbol = 'bcccny'
        elif coinType == helper.HUOBI_COIN_TYPE_ETC:
            symbol = 'etccny'
        else:
            symbol = None
        return symbol

    # bitex限价卖出
    def bitex_sell_limit(self, coinType, price, quantity):
        if price is None or quantity is None:
            self.timeLog("限价单必须填写下单价格和数量")
            return None
        self.timeLog("开始下达Bitex限价卖单...")
        self.timeLog("只保留下单数量的小数点后4位，下单价格的小数点后2位...")
        self.timeLog("原始下单数量:%s" % quantity)
        rounded_quantity = str(helper.downRound(float(quantity), 4))
        self.timeLog("做完小数点处理后的下单数量:%s" % rounded_quantity)

        if float(rounded_quantity) < self.bitex_min_quantity.get(coinType):
            self.timeLog(
                "数量:%s 小于交易所最小交易数量(火币最小数量:%f),因此无法下单,此处忽略该信号" %
                (rounded_quantity, self.bitex_min_quantity.get(coinType)),
                level=logging.WARN)
            return None

        self.timeLog("原始下单价格:%s" % price)
        rounded_price = str(helper.downRound(float(price), 2))
        self.timeLog("做完小数点处理后的下单价格:%s" % rounded_price)
        symbol = self.bitex_coinType_to_symbol(coinType)
        try:
            res = self.BitexService.order(symbol, rounded_price, rounded_quantity, "sell-limit")
            if res['status'] == 'ok':
                order_id = res['data']
            else:
                self.timeLog(res)
                raise Exception
            return order_id
        except Exception as e:
            self.timeLog(
                "下达Bitex限价卖单（数量：%s，价格：%s）失败, 结果是：%s！" % (rounded_quantity, rounded_price, str(e)),
                level=logging.ERROR)
            return None

    def bitex_buy_market(self, coinType, cash_amount):
        self.timeLog("开始下达bitex市价买单...")
        self.timeLog("只保留下单数量的小数点后2位...")
        self.timeLog("原始下单金额:%s" % cash_amount)
        rounded_cash_amount = str(helper.downRound(float(cash_amount), 2))
        self.timeLog("做完小数点处理后的下单金额:%s" % rounded_cash_amount)
        symbol = self.bitex_coinType_to_symbol(coinType)
        try:
            res = self.BitexService.order(symbol, None, rounded_cash_amount, "buy-market")
            if res['status'] == 'ok':
                order_id = res['data']
            else:
                raise Exception
            return order_id
        except Exception as e:
            self.timeLog(
                "下达Bitex市价买单（金额：%s）失败, 结果是：%s！" % (rounded_cash_amount, str(e)),
                level=logging.ERROR)
            return None

    def bitex_sell_market(self, coinType, quantity):
        self.timeLog("开始下达bitex市价卖单...")
        self.timeLog("只保留下单数量的小数点后4位...")
        self.timeLog("原始下单数量:%s" % quantity)
        rounded_quantity = str(helper.downRound(float(quantity), 4))
        self.timeLog("做完小数点处理后的下单数量:%s" % rounded_quantity)
        symbol = self.bitex_coinType_to_symbol(coinType)
        try:
            res = self.BitexService.order(symbol, None, rounded_quantity, "sell-market")
            if res['status'] == 'ok':
                order_id = res['data']
            else:
                raise Exception
            return order_id
        except Exception as e:
            self.timeLog(
                "下达Bitex市价卖单（数量：%s）失败, 结果是：%s！" % (rounded_quantity, str(e)),
                level=logging.ERROR)
            return None

    def bitex_order(self, coinType, tradeType, orderType, price, cash_amount, quantity):
        if orderType is helper.ORDER_TYPE_MARKET_ORDER:
            if tradeType is helper.SPOT_TRADE_TYPE_BUY:
                res = self.bitex_buy_market(coinType, cash_amount)
            elif tradeType is helper.SPOT_TRADE_TYPE_SELL:
                res = self.huobi_sell_market(coinType, quantity)
            else:
                self.timeLog("下单tradeType参数错误", level=logging.ERROR)
                return None
        elif orderType is helper.ORDER_TYPE_LIMIT_ORDER:
            # 限价买入
            if tradeType is helper.SPOT_TRADE_TYPE_BUY:
                res = self.bitex_buy_limit(coinType, price, quantity)
            elif tradeType is helper.SPOT_TRADE_TYPE_SELL:
                res = self.bitex_sell_limit(coinType, price, quantity)
            else:
                self.timeLog("下单tradeType参数错误", level=logging.ERROR)
                return None
        else:
            self.timeLog("下单orderType参数错误", level=logging.ERROR)
            return None
        return res

    def bitex_order_info(self, id):
        order_info = self.BitexService.get_order_info(id)
        if "status" in order_info.keys() and order_info['status'] == 'ok':
            data = order_info['data']
            state = data['state']
            deal_qty = float(data['field-amount'])
            return state, deal_qty
        else:
            return None

    def bitex_full_order_info(self, id, with_order_type=False):
        order_info = self.BitexService.get_order_info(id)
        if "status" in order_info.keys() and order_info['status'] == 'ok':
            data = order_info['data']
            state = data['state']
            deal_qty = float(data['field-amount'])
            deal_value = float(data['field-cash-amount'])
            if deal_qty == 0:
                processed_price = 0
            else:
                processed_price = deal_value/deal_qty
            if not with_order_type:
                return state, deal_qty, processed_price
            else:
                order_type = "sell" if(data['type'] in ['sell-limit', 'sell-market']) else "buy"
                return state, deal_qty, processed_price, order_type
        else:
            return None

    def bitex_order_cancel(self, id):
        self.timeLog("正在撤销bitex订单。order id: %s" % id)
        res = self.BitexService.cancel_order(id)
        if "status" in res.keys() and res['status'] == 'ok':
            self.timeLog("bitex订单撤销成功. order id: %s" % id)
            return u"success"
        else:
            status, amt = self.bitex_order_info(id)
            if status in ['filled', 'canceled', 'partial-canceled']:
                self.timeLog("bitex订单已终结%s. order id: %s" % (status, id))
                return u"success"
            self.timeLog("bitex订单撤销失败. order id: %s" % id)
            return u"failed"

    def bitex_cancel_pending_orders(self, order_id_list=None, pair=None, exclude_id_list=None):
        symbol = pair.replace('_', '')
        orders = [order["id"] for order in self.BitexService.get_active_orders(symbol)['data']]
        max_order_number = 50
        if order_id_list is None and exclude_id_list is None:
            count = 0
            while orders is not None and len(orders) > 0 and count < 3:
                success_list = []
                for i in range(0, len(orders), max_order_number):
                    self.timeLog("批量删除bitex订单 %s" % orders[i:i+max_order_number])
                    result = self.BitexService.batch_cancel_order(orders[i:i+max_order_number])
                    self.timeLog("批量删除结果 {0}".format(result))
                    success_list.extend(result["data"]["success"])
                time.sleep(0.2)
                orders = [order["id"] for order in self.BitexService.get_active_orders(symbol)['data']
                          if str(order["id"]) not in success_list]
                count += 1
        elif order_id_list is not None:
            count = 0
            cancel_orders = [order for order in orders if order in order_id_list or str(order) in order_id_list]
            while cancel_orders is not None and len(cancel_orders) > 0 and count < 3:
                success_list = []
                for i in range(0, len(cancel_orders), max_order_number):
                    self.timeLog("批量删除bitex订单 %s" % cancel_orders)
                    result = self.BitexService.batch_cancel_order(cancel_orders[i:i + max_order_number])
                    self.timeLog("批量删除结果 {0}".format(result))
                    success_list.extend(result["data"]["success"])
                time.sleep(0.2)
                orders = [order["id"] for order in self.BitexService.get_active_orders(symbol)['data']
                          if str(order["id"]) not in success_list]
                count += 1
                cancel_orders = [order for order in orders if order in order_id_list or str(order) in order_id_list]
        elif exclude_id_list is not None:
            count = 0
            cancel_orders = [order for order in orders if order not in exclude_id_list
                             or str(order) not in exclude_id_list]
            while cancel_orders is not None and len(cancel_orders) > 0 and count < 3:
                success_list = []
                for i in range(0, len(cancel_orders), max_order_number):
                    self.timeLog("批量删除bitex订单 %s" % cancel_orders)
                    result = self.BitexService.batch_cancel_order(cancel_orders[i:i + max_order_number])
                    self.timeLog("批量删除结果 {0}".format(result))
                    success_list.extend(result["data"]["success"])
                time.sleep(0.2)
                orders = [order["id"] for order in self.BitexService.get_active_orders(symbol)['data']
                          if str(order["id"]) not in success_list]
                count += 1
                cancel_orders = [order for order in orders if order not in order_id_list
                                 or str(order) not in exclude_id_list]

    def get_bitex_latest_price(self, coin_type):
        symbol = self.bitex_coinType_to_symbol(coin_type)
        try:
            trade = self.BitexService.get_latest_trade(symbol)
            price = trade['tick']['data'][0]['price']
            return price
        except Exception as e:
            raise Exception('Get bitex latest price fail: %s' % str(e))

