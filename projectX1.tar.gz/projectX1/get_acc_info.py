# !/usr/bin/env python
# -*- coding: utf-8 -*-
import gevent.monkey
gevent.monkey.patch_all()

from exchangeConnection.okcoin.util import getOkcoinSpot
from exchangeConnection.pro.proService import init_pro_account
from exchangeConnection.poloniex.rest import init_polo_account
from exchangeConnection.chbtc.rest_api import chbtc_service
from exchangeConnection.kraken.KrakenService import kraken_service
from exchangeConnection.okex import okex_service
from exchangeConnection.bittrex import BittrexService
from exchangeConnection.huobi import huobiService
from exchangeConnection.bitfinex import bitfinexService
import traceback
import time
import greenlet
import utils.redisHelper as rh
from logbook import Logger, FileHandler, INFO, set_datetime_format
import datetime
import random

set_datetime_format("local")
handler = FileHandler(filename='get_acc_info' + datetime.datetime.now().strftime("%Y%m%d-%H%M%S") + '.log', mode="w", level=INFO)
handler.push_application()
my_log = Logger("acc_log")
global acc_count, lock_count
acc_count = 0
lock_count = 0


def fetch_acc_info(exchange, acc_id):
    global acc_count, lock_count
    last_update = time.time()
    if exchange == "okcoin":
        OKCoinService = getOkcoinSpot(acc_id)

    elif exchange == "pro":
        pro_service = init_pro_account(acc_id)
        if not pro_service:
            return None

    elif exchange == "polo":
        polo_service = init_polo_account(acc_id)
        if not polo_service:
            return None

    elif exchange == "chbtc":
        chbtc = chbtc_service(acc_id)
        if not chbtc:
            return None
        
    elif exchange == "kraken":
        kraken = kraken_service(acc_id, 'acc')
        if not kraken:
            return None

    elif exchange == "okex":
        okex_spot_service = okex_service.get_okex_spot(acc_id)
        okex_future_service = okex_service.get_okex_future(acc_id)

    elif exchange == "bittrex":
        bittrex_service = BittrexService.Bittrex_Service(acc_id, 'acc')

    elif exchange == "huobi":
        huobi_service = huobiService.HuobiService(acc_id)

    elif exchange == "bitfinex":
        bitfinex_service = bitfinexService.bitfinex_service(acc_id, 'acc')

    while True:
        try:
            if exchange == "okcoin":
                okcoinAcct = OKCoinService.userInfo()
                rh.set_redis_acc_info(exchange, acc_id, okcoinAcct)
                time.sleep(1)

            elif exchange == "pro":
                lock_time = time.time()
                if rh.redis_lock("_".join(["acc", exchange, acc_id]), lock_time, 2):
                    acc_info = dict()
                    acc_info["data"] = pro_service.get_spot_acct_info()['data']['list']
                    acc_info["time"] = time.time()
                    rh.set_redis_acc_info(exchange, acc_id, acc_info)
                    time.sleep(0.5)
                    rh.redis_unlock("_".join(["acc", exchange, acc_id]), lock_time)
                    acc_count += 1
                    time.sleep(random.random())
                else:
                    lock_count += 1
                    time.sleep(0.5 + random.random())

            elif exchange == "polo":
                lock_time = time.time()
                if rh.redis_lock("_".join(["acc", exchange, acc_id]), lock_time, 2):
                    acc_info = polo_service.get_spot_acct_info()
                    acc_info["time"] = time.time()
                    rh.set_redis_acc_info(exchange, acc_id, acc_info)
                    time.sleep(0.5)
                    rh.redis_unlock("_".join(["acc", exchange, acc_id]), lock_time)
                    time.sleep(random.random())
                else:
                    time.sleep(0.5 + random.random())

            elif exchange == "chbtc":
                acc_info = chbtc.get_acct_info()
                acc_info["time"] = time.time()
                rh.set_redis_acc_info(exchange, acc_id, acc_info)
                time.sleep(1)

            elif exchange == "okex":
                lock_time = time.time()
                if rh.redis_lock("_".join(["acc", exchange, acc_id]), lock_time, 2):
                    acc_info = okex_spot_service.userInfo()
                    acc_info["time"] = time.time()
                    rh.set_redis_acc_info(exchange, acc_id, acc_info)
                    future_acc_info = okex_future_service.future_userinfo()
                    future_acc_info["time"] = time.time()
                    rh.set_redis_acc_future_info("okexFuture", acc_id, future_acc_info)
                    time.sleep(0.5)
                    rh.redis_unlock("_".join(["acc", exchange, acc_id]), lock_time)
                    time.sleep(random.random())
                else:
                    time.sleep(0.5 + random.random())

            elif exchange == "kraken":
                lock_time = time.time()
                if rh.redis_lock("_".join(["acc", exchange, acc_id]), lock_time, 3):
                    acc_info = {}
                    acc_info_result = kraken.get_acct_info()
                    if not acc_info_result:
                        acc_info_result = {}
                    acc_info['balance'] = acc_info_result
                    acc_info["time"] = time.time()
                    rh.set_redis_acc_info(exchange, acc_id, acc_info)
                    time.sleep(1)
                    rh.redis_unlock("_".join(["acc", exchange, acc_id]), lock_time)
                    time.sleep(random.random())
                else:
                    time.sleep(1 + random.random())

            elif exchange == "bittrex":
                lock_time = time.time()
                if rh.redis_lock("_".join(["acc", exchange, acc_id]), lock_time, 3):
                    acc_info = bittrex_service.get_acct_infos()
                    if acc_info.get("success"):
                        acc_info["time"] = time.time()
                        rh.set_redis_acc_info(exchange, acc_id, acc_info)
                    else:
                        my_log.error("bittrex_service error for %s %s" % (exchange, acc_info))
                    time.sleep(0.5)
                    rh.redis_unlock("_".join(["acc", exchange, acc_id]), lock_time)
                    time.sleep(random.random())
                else:
                    time.sleep(0.5 + random.random())

            elif exchange == "huobi":
                huobi_acc = huobi_service.getAccountInfo("cny", "get_account_info")
                huobi_acc["time"] = time.time()
                rh.set_redis_acc_info(exchange, acc_id, huobi_acc)
                time.sleep(1.5)

            elif exchange == "bitfinex":
                lock_time = time.time()
                if rh.redis_lock("_".join(["acc", exchange, acc_id]), lock_time, 7):
                    bitfinex_acc = bitfinex_service.balance()
                    rh.set_redis_acc_info(exchange, acc_id, {"data": bitfinex_acc, "time": time.time()})
                    time.sleep(2.5)
                    rh.redis_unlock("_".join(["acc", exchange, acc_id]), lock_time)
                    time.sleep(2.5 * random.random())
                else:
                    time.sleep(2.5 + 2.5 * random.random())

            if time.time() - last_update > 10:
                last_update = time.time()
                my_log.info("Heartbeat for %s, %s" % (exchange, acc_id))
                my_log.info("pro_acc_count   %s   %s" % (acc_count, lock_count))

        except greenlet.GreenletExit:
            my_log.info("Greenlet has stopped.")
            return
        except Exception:
            my_log.info(traceback.format_exc())
            time.sleep(2)
            
if __name__ == "__main__":
    proc_list = {}
    while True:
        try:
            ret_ = set(rh.account_alllist())
            cur_keys = set(proc_list.keys())
            my_log.info("%s %s %s" % (ret_, cur_keys, ret_ - cur_keys))
            for acc in ret_ - cur_keys:
                try:
                    exchange_, acc_id_ = acc.decode("utf-8").split("_")
                    my_log.info("Adding account %s, %s" % (exchange_, acc_id_))
                    proc_list[acc] = gevent.spawn(fetch_acc_info, exchange_, acc_id_)
                except Exception:
                    my_log.info(traceback.format_exc())
            
            for acc in cur_keys - ret_:
                try:
                    my_log.info("Removing account %s" % acc.decode("utf-8"))
                    proc = proc_list.pop(acc)
                    proc.kill()
                except Exception:
                    my_log.exception("Error occurs while kill greenlet")
            
            time.sleep(10)
        except Exception:
            my_log.error(traceback.format_exc())
            time.sleep(10)