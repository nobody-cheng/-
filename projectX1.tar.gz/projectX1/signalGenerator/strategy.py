#!/usr/bin/env python
# -*- coding: utf-8 -*-
import datetime
import logging
import traceback
import time
import positionRecorder.recorder as pos_recorder

from exchange import pro, chbtc, kraken, okcoin, polo, bitstamp, okex, bittrex, huobi, bitfinex
from utils import helper
from utils.errors import StartRunningTimeEmptyError
from utils import redisHelper


class Strategy(object):
    def __init__(self, instance_id=None, startRunningTime=None,
                 name=None, chbtc_accid=None, okcoin_accid=None, pro_accid=None,
                 polo_accid=None, kraken_accid=None, bitstamp_accid=None, okex_accid=None, bittrex_accid=None,
                 huobi_accid=None, bitex_accid=None, bitfinex_accid=None):
        if startRunningTime is None:
            startRunningTime = datetime.datetime.now()
        if name is None:
            name = self.__class__.__name__
        self.name = name

        self.startRunningTime = startRunningTime
        self.TimeFormatForFileName = "%Y%m%d%H%M%S%f"
        self.TimeFormatForLog = "%Y-%m-%d %H:%M:%S.%f"
        if instance_id is None:
            self.instanceId = helper.getUUID()
        else:
            self.instanceId = instance_id
        # setup timeLogger
        self.timeLogger = helper.TimeLogger(self.getTimeLogFileName()) 
        self.update_config()

        self.okcoin_accid = okcoin_accid
        self.pro_accid = pro_accid
        self.polo_accid = polo_accid
        self.chbtc_accid = chbtc_accid
        self.kraken_accid = kraken_accid
        self.bitstamp_accid = bitstamp_accid
        self.okex_accid = okex_accid
        self.bittrex_accid = bittrex_accid
        self.huobi_accid = huobi_accid
        self.bitex_accid = bitex_accid
        self.bitfinex_accid = bitfinex_accid

        # 一些变量，可在策略init中重新设置
        # add order query retry maximum times
        self.okcoin_order_query_retry_maximum_times = 10
        self.chbtc_order_query_retry_maximum_times = 10
        self.pro_order_query_retry_maximum_times = 10
        self.polo_order_query_retry_maximum_times = 10
        self.kraken_order_query_retry_maximum_times = 10
        # add order "cancellation" query retry maximum times
        self.okcoin_order_cancel_query_retry_maximum_times = 5
        self.chbtc_order_cancel_query_retry_maximum_times = 5
        self.pro_order_cancel_query_retry_maximum_times = 5
        self.polo_order_cancel_query_retry_maximum_times = 5
        self.kraken_order_cancel_query_retry_maximum_times = 5
        self.orderWaitingTime = 0.2
        self.max_time_delay = 5  # 获取的行情数据最多与当前时间相差5秒
        self.timeInterval = 1  # 每次循环结束之后睡眠的时间, 单位：秒

        self.latest_trade_time = time.time()

        self.ProExchange = pro.ProExchange(self.pro_accid, self.timeLog)
        self.ChbtcExchange = chbtc.ChbtcExchange(self.chbtc_accid, self.timeLog)
        if self.kraken_accid:
            self.KrakenExchange = kraken.KrakenExchange(self.kraken_accid, self.timeLog)
        self.OkcoinExchange = okcoin.OkcoinExchange(self.okcoin_accid, self.timeLog)
        self.PoloExchange = polo.PoloExchange(self.polo_accid, self.timeLog)
        self.BitstampExchange = bitstamp.BistampExchange(self.bitstamp_accid, self.timeLog)
        self.OkexSpotExchange = okex.OkexSpotExchange(self.okex_accid, self.timeLog)
        self.OkexFutureExchange = okex.OkexFutureExchange(self.okex_accid, self.timeLog)
        self.BittrexExchange = bittrex.BistampExchange(self.bittrex_accid, self.timeLog)
        if self.huobi_accid:
            self.HuobiExchange = huobi.HuobiExchange(self.huobi_accid, self.timeLog)
        if self.bitfinex_accid:
            self.BitfinexExchange = bitfinex.BitfinexExchange(self.bitfinex_accid, self.timeLog)

    def update_config(self):
        """
        更新配置
        :return:
        """
        self.cfg = redisHelper.get_strategy_config(self.name)
        self.timeLog("读取策略新配置：{0}".format(self.cfg))

    def getStartRunningTime(self):
        if self.startRunningTime is None:
            raise StartRunningTimeEmptyError("startRunningTime is not set yet!")
        return self.startRunningTime

    def getTimeLogFileName(self):
        return "log/%s_log_%s_%s.txt" % (
            self.__class__.__name__, self.getStartRunningTime().strftime(self.TimeFormatForFileName), self.instanceId)

    def timeLog(self, content, level=logging.INFO):
        self.timeLogger.timeLog(content, level=level)

    def buy_limit(self, exchange, coin_type, price, quantity, **kwargs):
        if exchange == helper.CHBTC:
            ret = self.ChbtcExchange.chbtc_buy_limit(coin_type, price, quantity, **kwargs)
        elif exchange == helper.PRO:
            ret = self.ProExchange.pro_buy_limit(price, quantity, coin_type, **kwargs)
        elif exchange == helper.OKCOIN:
            ret = self.OkcoinExchange.okcoin_buy_limit(coin_type, price, quantity, **kwargs)
        elif exchange == helper.POLO:
            ret = self.PoloExchange.polo_buy_limit(price, quantity, coin_type, **kwargs)
        elif exchange == helper.KRAKEN:
            ret = self.KrakenExchange.kraken_buy_limit(coin_type, price, quantity, **kwargs)
        elif exchange == helper.BITSTAMP:
            ret = self.BitstampExchange.bitstamp_buy_limit(coin_type, price, quantity, **kwargs)
        elif exchange == helper.OKEX:
            ret = self.OkexSpotExchange.okex_buy_limit(coin_type, price, quantity, **kwargs)
        elif exchange == helper.BITTREX:
            ret = self.BittrexExchange.bittrex_buy_limit(coin_type, price, quantity, **kwargs)
        elif exchange == helper.HUOBI:
            ret = self.HuobiExchange.huobi_buy_limit(coin_type, price, quantity, **kwargs)
        elif exchange == helper.BITFINEX:
            ret = self.BitfinexExchange.bitfinex_buy_limit(coin_type, price, quantity, **kwargs)
        else:
            self.timeLog("买卖的市场不支持 {0}".format(exchange))
            return None
        self.latest_trade_time = time.time()
        return ret

    def sell_limit(self, exchange, coin_type, price, quantity, **kwargs):
        if exchange == helper.CHBTC:
            ret = self.ChbtcExchange.chbtc_sell_limit(coin_type, price, quantity, **kwargs)
        elif exchange == helper.PRO:
            ret = self.ProExchange.pro_sell_limit(price, quantity, coin_type, **kwargs)
        elif exchange == helper.OKCOIN:
            ret = self.OkcoinExchange.okcoin_sell_limit(coin_type, price, quantity, **kwargs)
        elif exchange == helper.POLO:
            ret = self.PoloExchange.polo_sell_limit(price, quantity, coin_type, **kwargs)
        elif exchange == helper.KRAKEN:
            ret = self.KrakenExchange.kraken_sell_limit(coin_type, price, quantity, **kwargs)
        elif exchange == helper.BITSTAMP:
            ret = self.BitstampExchange.bitstamp_sell_limit(coin_type, price, quantity, **kwargs)
        elif exchange == helper.OKEX:
            ret = self.OkexSpotExchange.okex_sell_limit(coin_type, price, quantity, **kwargs)
        elif exchange == helper.BITTREX:
            ret = self.BittrexExchange.bittrex_sell_limit(coin_type, price, quantity, **kwargs)
        elif exchange == helper.HUOBI:
            ret = self.HuobiExchange.huobi_sell_limit(coin_type, price, quantity, **kwargs)
        elif exchange == helper.BITFINEX:
            ret = self.BitfinexExchange.bitfinex_sell_limit(coin_type, price, quantity, **kwargs)
        else:
            self.timeLog("买卖的市场不支持 {0}".format(exchange))
            return None
        self.latest_trade_time = time.time()
        return ret

    def spot_order_info(self, exchange, order_id, coin_type=None):
        if exchange == helper.OKCOIN:
            res = self.OkcoinExchange.okcoin_order_info(coin_type, order_id)
        elif exchange == helper.PRO:
            res = self.ProExchange.pro_order_info(order_id)
        elif exchange == helper.POLO:
            res = self.PoloExchange.polo_order_info(order_id)
        elif exchange == helper.CHBTC:
            res = self.ChbtcExchange.chbtc_order_info(order_id, coin_type)
        elif exchange == helper.KRAKEN:
            res = self.KrakenExchange.kraken_order_info(order_id)
        elif exchange == helper.BITSTAMP:
            res = self.BitstampExchange.bitstamp_order_info(order_id)
        elif exchange == helper.OKEX:
            res = self.OkexSpotExchange.okex_order_info(coin_type, order_id)
        elif exchange == helper.BITTREX:
            res = self.BittrexExchange.bittrex_order_info(order_id)
        elif exchange == helper.HUOBI:
            res = self.HuobiExchange.huobi_order_info(coin_type, order_id)
        elif exchange == helper.BITFINEX:
            res = self.BitfinexExchange.bitfinex_order_info(order_id)
        else:
            self.timeLog("订单查询失败：市场参数marketType错误", level=logging.ERROR)
            return None
        return res

    def spot_order_cancel(self, exchange, order_id, coin_type=None):
        if exchange == helper.OKCOIN:
            res = self.OkcoinExchange.okcoin_order_cancel(coin_type, order_id)
        elif exchange == helper.PRO:
            res = self.ProExchange.pro_order_cancel(order_id)
        elif exchange == helper.POLO:
            res = self.PoloExchange.polo_order_cancel(order_id)
        elif exchange == helper.KRAKEN:
            res = self.KrakenExchange.kraken_order_cancel(order_id)
        elif exchange == helper.BITSTAMP:
            res = self.BitstampExchange.bitstamp_order_cancel(order_id)
        elif exchange == helper.CHBTC:
            res = self.ChbtcExchange.chbtc_order_cancel(order_id)
        elif exchange == helper.OKEX:
            res = self.OkexSpotExchange.okex_order_cancel(coin_type, order_id)
        elif exchange == helper.BITTREX:
            res = self.BittrexExchange.bittrex_order_cancel(order_id)
        elif exchange == helper.HUOBI:
            res = self.HuobiExchange.huobi_order_cancel(coin_type, order_id)
        elif exchange == helper.BITFINEX:
            res = self.BitfinexExchange.bitfinex_order_cancel(order_id)
        else:
            self.timeLog("订单撤销失败：市场参数marketType错误", level=logging.ERROR)
            return None
        self.latest_trade_time = time.time()
        return res

    def get_active_orders(self, exchange, pair):
        if exchange == helper.PRO:
            res = self.ProExchange.pro_get_active_orders(pair)
        elif exchange == helper.POLO:
            res = self.PoloExchange.polo_actvie_orders(pair)
        elif exchange == helper.KRAKEN:
            res = self.KrakenExchange.kraken_get_active_orders(pair)
        elif exchange == helper.BITSTAMP:
            res = self.BitstampExchange.bitstamp_get_active_orders(pair)
        elif exchange == helper.CHBTC:
            res = self.ChbtcExchange.chbtc_get_active_orders(pair)
        elif exchange == helper.OKEX:
            res = self.OkexSpotExchange.okex_get_active_orders(pair)
        elif exchange == helper.BITTREX:
            res = self.BittrexExchange.bittrex_get_active_orders(pair)
        elif exchange == helper.HUOBI:
            res = self.HuobiExchange.huobi_get_active_orders(pair)
        elif exchange == helper.BITFINEX:
            res = self.BitfinexExchange.bitfinex_get_active_orders(pair)
        else:
            self.timeLog("获取订单失败：市场参数marketType错误", level=logging.ERROR)
            return None
        return res

    def cancel_pending_orders(self, exchange='pro', order_id_list=None, pair=None, **kwargs):
        """
        :param exchange:
        :param order_id_list: 为None时，删除所有进行中的订单
        :return:
        """
        if exchange == helper.PRO:
            self.ProExchange.pro_cancel_pending_orders(order_id_list=order_id_list, pair=pair, **kwargs)
        elif exchange == helper.POLO:
            self.PoloExchange.polo_cancel_pending_orders(order_id_list=order_id_list, pair=pair, **kwargs)
        elif exchange == helper.CHBTC:
            self.ChbtcExchange.chbtc_cancel_pending_orders(order_id_list=order_id_list, pair=pair, **kwargs)
        elif exchange == helper.KRAKEN:
            self.KrakenExchange.kraken_cancel_pending_orders(order_id_list=order_id_list, pair=pair, **kwargs)
        elif exchange == helper.BITSTAMP:
            self.BitstampExchange.bitstamp_cancel_pending_order()
        elif exchange == helper.OKEX:
            self.OkexSpotExchange.okex_cancel_pending_orders(order_id_list=order_id_list, pair=pair, **kwargs)
        elif exchange == helper.BITTREX:
            self.BittrexExchange.bittrex_cancel_pending_order(pair, order_id_list=order_id_list, **kwargs)
        elif exchange == helper.BITFINEX:
            res = self.BitfinexExchange.bitfinex_cancel_pending_order(pair, order_id_list=order_id_list, **kwargs)
        elif exchange == helper.HUOBI:
            res = self.HuobiExchange.huobi_cancel_pending_orders(order_id_list=order_id_list, pair=pair, **kwargs)
        else:
            self.timeLog("exchange %s is not supported" % exchange)
            return None
        self.latest_trade_time = time.time()

    # 获取深度信息
    def get_depth(self, exchange, time_out=None, max_delay=None, coin_type=None):
        """
        读取shared queue中的深度信息。
        :param exchange: 交易所，  "okcoin", "pro"
        :param time_out: 获取信息的最长等待时间
        :param max_delay: 获取的信息时间戳的最大延迟
        :return:
        """
        start_time = time.time()
        if time_out is None:
            time_out = 10
        if max_delay is None:
            max_delay = 10
        while time.time() - start_time < time_out:
            try:
                depth_data = redisHelper.get_depth(exchange, coin_type)
                timestamp = depth_data["time"]
                bids = depth_data['bids']
                asks = depth_data['asks']
                if time.time() - float(timestamp) > max_delay:
                    raise TimeoutError
                return bids, asks
            except Exception:
                self.timeLog(traceback.format_exc())
                time.sleep(1)
                continue
        self.timeLog("获取深度信息超时")
        return None

    def get_buy_or_sell_n_price_or_vol(self, exchange, buy_or_sell, price_or_vol, n=1, time_out=None, max_delay=None, coin_type=None):
        """
        :param exchange:
        :param buy_or_sell: 0: buy, 1: sell
        :param price_or_vol: 0: price, 1: volume
        :param n: depth level
        :param time_out:
        :param max_delay:
        :param contract_type:
        :return:
        """
        res = self.get_depth(exchange, time_out=time_out, max_delay=max_delay, coin_type=coin_type)
        if res is None:
            return None
        try:
            return float(res[buy_or_sell][n-1][price_or_vol])
        except KeyError:
            self.timeLog("所给深度值超过范围： n = %s" % n)
            time.sleep(0.5)
            return None
        except Exception:
            self.timeLog(traceback.format_exc())
            time.sleep(0.5)
            return None

    def get_future_depth(self, exchange, coin_type, contract_type, time_out=None, max_delay=None):
        start_time = time.time()
        if time_out is None:
            time_out = 10
        if max_delay is None:
            max_delay = 10
        while time.time() - start_time < time_out:
            try:
                depth_data = redisHelper.get_depth(exchange, "{0}:{1}".format(coin_type, contract_type))
                timestamp = depth_data["time"]
                bids = depth_data['bids']
                asks = depth_data['asks']
                if time.time() - float(timestamp) > max_delay:
                    raise TimeoutError
                return bids, asks
            except Exception:
                self.timeLog(traceback.format_exc())
                continue
        self.timeLog("获取深度信息超时")
        return None


    def get_acc_id(self, exchange):
        if exchange == helper.OKCOIN:
            acc_id = self.okcoin_accid
        elif exchange == helper.PRO:
            acc_id = self.pro_accid
        elif exchange == helper.POLO:
            acc_id = self.polo_accid
        elif exchange == helper.CHBTC:
            acc_id = self.chbtc_accid
        elif exchange == helper.KRAKEN:
            acc_id = self.kraken_accid
        elif exchange == helper.BITSTAMP:
            acc_id = self.bitstamp_accid
        elif exchange in {helper.OKEX, helper.OKEXFUTURE}:
            acc_id = self.okex_accid
        elif exchange == helper.BITTREX:
            acc_id = self.bittrex_accid
        elif exchange == helper.HUOBI:
            acc_id = self.huobi_accid
        elif exchange == helper.BITFINEX:
            acc_id = self.bitfinex_accid
        return acc_id

    def get_account_info_dict(self, exchange, time_after=None, time_out=None, max_delay=None):
        """
        从shared queue中获取当前账户信息。 返回一个字典
        :param exchange: 如果不填，则返回全部账户信息
        :param time_after:
        :param time_out:
        :param max_delay:
        :return:
        """
        start_time = time.time()
        if time_after is None:
            time_after = self.latest_trade_time
        if time_out is None:
            time_out = 10
        if max_delay is None:
            max_delay = 10

        # 获取账户持仓信息
        while time.time() - start_time < time_out:
            try:
                acc_id = self.get_acc_id(exchange)
                acc_info = redisHelper.get_account_info(exchange, acc_id)
                account_update_time = acc_info["time"]
                if float(account_update_time) < time_after or time.time() - float(account_update_time) > max_delay:
                    continue
                if exchange == helper.CHBTC:
                    formatted_acc_info = pos_recorder.chbtc_spot_record_formatter(acc_info.get("result"))
                    return formatted_acc_info
                elif exchange == helper.PRO:
                    formatted_acc_info = pos_recorder.pro_spot_pos_record_formatter(acc_info["data"])
                    return formatted_acc_info
                elif exchange == helper.KRAKEN:
                    formatted_acc_info = pos_recorder.kraken_spot_record_formatter(acc_info)
                    return formatted_acc_info
                elif exchange == helper.OKEX:
                    formatted_acc_info = pos_recorder.okex_spot_pos_record_formatter(acc_info["info"]["funds"])
                    return formatted_acc_info
                elif exchange == helper.BITTREX:
                    formatted_acc_info = pos_recorder.bittrex_spot_pos_record_formatter(acc_info["result"])
                    return formatted_acc_info
                elif exchange == helper.HUOBI:
                    formatted_acc_info = pos_recorder.huobi_spot_pos_record_formatter(acc_info)
                    return formatted_acc_info
                elif exchange == helper.BITFINEX:
                    formatted_acc_info = pos_recorder.bitfinex_spot_pos_record_formatter(acc_info["data"])
                    return formatted_acc_info
                else:
                    return acc_info
            except Exception:
                time.sleep(1)
                print(traceback.format_exc())
                continue
        self.timeLog("获取账号信息超时")
        return None

    def get_account_future_info_dict(self, exchange, time_after=None, time_out=None, max_delay=None):
        """
        从shared queue中获取当前账户信息。 返回一个字典
        :param exchange: 如果不填，则返回全部账户信息
        :param time_after:
        :param time_out:
        :param max_delay:
        :return:
        """
        start_time = time.time()
        if time_after is None:
            time_after = self.latest_trade_time
        if time_out is None:
            time_out = 10
        if max_delay is None:
            max_delay = 10

        # 获取账户持仓信息
        while time.time() - start_time < time_out:
            try:
                acc_id = self.get_acc_id(exchange)
                acc_info = redisHelper.get_account_future_info(exchange, acc_id)
                account_update_time = acc_info["time"]
                if float(account_update_time) < time_after or time.time() - float(account_update_time) > max_delay:
                    continue
                return acc_info
            except Exception:
                time.sleep(1)
                print(traceback.format_exc())
                continue
        self.timeLog("获取账号信息超时")
        return None