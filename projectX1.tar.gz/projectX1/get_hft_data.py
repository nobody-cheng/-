#!/usr/bin/env python
# -*- coding: utf-8 -*-
import gevent.monkey
gevent.monkey.patch_all()

import pymysql, json, traceback, time, logging, gevent
from multiprocessing.dummy import Pool
#from sshtunnel import SSHTunnelForwarder
from exchangeConnection.bitex.websocket_api import BitexWebsocketClient
from exchangeConnection.huobi.websocket_api import HuobiWebsocketClient
from exchangeConnection.pro.websocket_api import ProWebsocketClient

logging.basicConfig(level=logging.INFO,
                    format='%(asctime)s %(filename)s[line:%(lineno)d] %(levelname)s %(message)s',
                    datefmt='%a, %d %b %Y %H:%M:%S',
                    filename='get_hft_info.log',
                    filemode='w'
                   )

logging.getLogger("requests").setLevel(logging.WARNING)
logging.getLogger("urllib3").setLevel(logging.WARNING)

# rds_host = '127.0.0.1'
# rds_port = 10024
rds_host = 'strategy.cjkcbp5cnpti.rds.cn-north-1.amazonaws.com.cn'
rds_port = 3306

class SQLBitexWebsocketClient(BitexWebsocketClient):
    
    def __init__(self):
        super(SQLBitexWebsocketClient, self).__init__(logging)
        self.cur = {}
        cur.execute('use hft_data')
        self.trade_cache = {}
        self.depth_cache = {}
        for coin_type in coin_type_list:
            self.trade_cache[coin_type] = []
            self.depth_cache[coin_type] = []
            self.cur[coin_type] = self.create_sql_cur()
        self.worker_pool = Pool(3)
        
    def create_sql_cur(self):
        conn = pymysql.connect(host=rds_host,
                       port=rds_port,
                       user='strategy',
                       passwd='2wsx3edc',
                       connect_timeout=20,
                       autocommit = True
                       )
        cur = conn.cursor()
        cur.execute("use hft_data")
        return cur
    
    def start(self):
        BitexWebsocketClient.start(self)
        self.sub_trade('etccny')
        self.sub_trade('ethcny')
        self.sub_trade('bcccny')
        self.sub_depth('ethcny')
        self.sub_depth('etccny')
        self.sub_depth('bcccny')
        while not self.stop:
            self.worker_pool.map(self.write_to_sql, ['eth_cny', 'etc_cny', 'bcc_cny'])
            time.sleep(2)
    
    def on_trade(self, coin_type, msg):
        data_list=msg.get('tick').get('data')
        for item in data_list:
            self.trade_cache[coin_type].append(item)   
    
    def on_depth(self, coin_type, msg):
        item = msg.get('tick')
        self.depth_cache[coin_type].append(item)
        
    def write_to_sql(self, coin_type):
        try:
            cur = self.cur[coin_type]
            trades = self.trade_cache[coin_type]
            self.trade_cache[coin_type] = []
            depth = self.depth_cache[coin_type]
            self.depth_cache[coin_type] = []
            if(len(trades) > 0):
                trade_insert = "INSERT IGNORE INTO huobi_%s_trade (time, amount, direction, id, price) VALUES " % coin_type
                trade_insert += "('%s', %s, '%s', '%s', %s)" % (trades[0]['ts'], trades[0]['amount'], trades[0]['direction'], trades[0]['id'], trades[0]['price'])
                for item in trades[1:]:
                    trade_insert += ", ('%s', %s, '%s', '%s', %s)" % (item['ts'], item['amount'], item['direction'], item['id'], item['price'])
                cur.execute(trade_insert)
            if(len(depth) > 0):
                depth_insert = "INSERT IGNORE INTO huobi_%s_depth (time, bids, asks) VALUES " % coin_type
                depth_insert += "('%s', '%s', '%s')" % (depth[0]['ts'], json.dumps(depth[0]['bids'][:10]), json.dumps(depth[0]['asks'][:10]))
                for item in depth[1:]:
                    depth_insert += ", ('%s', '%s', '%s')" % (item['ts'], json.dumps(item['bids'][:10]), json.dumps(item['asks'][:10]))
                cur.execute(depth_insert)
        except Exception:
            self.logger.error(traceback.format_exc())
        
class SQLHuobiWebsocketClient(HuobiWebsocketClient):
    
    def __init__(self):
        super(SQLHuobiWebsocketClient, self).__init__(logging)
        self.cur = {}
        cur.execute('use hft_data')
        self.trade_cache = {}
        self.depth_cache = {}
        for coin_type in coin_type_list:
            self.trade_cache[coin_type] = []
            self.depth_cache[coin_type] = []
            self.cur[coin_type] = self.create_sql_cur()
        self.worker_pool = Pool(2)
        
    def create_sql_cur(self):
        conn = pymysql.connect(host=rds_host,
                       port=rds_port,
                       user='strategy',
                       passwd='2wsx3edc',
                       connect_timeout=20,
                       autocommit = True
                       )
        cur = conn.cursor()
        cur.execute("use hft_data")
        return cur
    
    def start(self):
        HuobiWebsocketClient.start(self)
        self.sub_trade('btccny')
        self.sub_trade('ltccny')
        self.sub_depth('btccny')
        self.sub_depth('ltccny')
        while not self.stop:
            self.worker_pool.map(self.write_to_sql, ['btc_cny', 'ltc_cny'])
            time.sleep(2)
    
    def on_trade(self, coin_type, msg):
        data_list=msg.get('tick').get('data')
        for item in data_list:
            self.trade_cache[coin_type].append(item)   
    
    def on_depth(self, coin_type, msg):
        item = msg.get('tick')
        self.depth_cache[coin_type].append(item)
        
    def write_to_sql(self, coin_type):
        try:
            cur = self.cur[coin_type]
            trades = self.trade_cache[coin_type]
            self.trade_cache[coin_type] = []
            depth = self.depth_cache[coin_type]
            self.depth_cache[coin_type] = []
            if(len(trades) > 0):
                trade_insert = "INSERT IGNORE INTO huobi_%s_trade (time, amount, direction, id, price) VALUES " % coin_type
                trade_insert += "('%s', %s, '%s', '%s', %s)" % (trades[0]['ts'], trades[0]['amount'], trades[0]['direction'], trades[0]['id'], trades[0]['price'])
                for item in trades[1:]:
                    trade_insert += ", ('%s', %s, '%s', '%s', %s)" % (item['ts'], item['amount'], item['direction'], item['id'], item['price'])
                cur.execute(trade_insert)
            if(len(depth) > 0):
                depth_insert = "INSERT IGNORE INTO huobi_%s_depth (time, bids, asks) VALUES " % coin_type
                depth_insert += "('%s', '%s', '%s')" % (depth[0]['ts'], json.dumps(depth[0]['bids'][:10]), json.dumps(depth[0]['asks'][:10]))
                for item in depth[1:]:
                    depth_insert += ", ('%s', '%s', '%s')" % (item['ts'], json.dumps(item['bids'][:10]), json.dumps(item['asks'][:10]))
                cur.execute(depth_insert)
        except Exception:
            self.logger.error(traceback.format_exc())
            
class SQLProWebsocketClient(ProWebsocketClient):
    
    def __init__(self):
        super(SQLProWebsocketClient, self).__init__(logging)
        self.cur = {}
        cur.execute('use hft_data')
        self.trade_cache = {}
        self.depth_cache = {}
        for coin_type in coin_type_list:
            self.trade_cache[coin_type] = []
            self.depth_cache[coin_type] = []
            self.cur[coin_type] = self.create_sql_cur()
        self.worker_pool = Pool(4)
        
    def create_sql_cur(self):
        conn = pymysql.connect(host=rds_host,
                       port=rds_port,
                       user='strategy',
                       passwd='2wsx3edc',
                       connect_timeout=20,
                       autocommit = True
                       )
        cur = conn.cursor()
        cur.execute("use hft_data")
        return cur
    
    def start(self):
        ProWebsocketClient.start(self)
        self.sub_trade('etcbtc')
        self.sub_trade('ethbtc')
        self.sub_trade('bccbtc')
        self.sub_trade('ltcbtc')
        self.sub_depth('ethbtc')
        self.sub_depth('etcbtc')
        self.sub_depth('bccbtc')
        self.sub_depth('ltcbtc')
        while not self.stop:
            self.worker_pool.map(self.write_to_sql, ['eth_btc', 'etc_btc', 'bcc_btc', 'ltc_btc'])
            time.sleep(2)
    
    def on_trade(self, coin_type, msg):
        data_list=msg.get('tick').get('data')
        for item in data_list:
            self.trade_cache[coin_type].append(item)   
    
    def on_depth(self, coin_type, msg):
        item = msg.get('tick')
        self.depth_cache[coin_type].append(item)
        
    def write_to_sql(self, coin_type):
        try:
            cur = self.cur[coin_type]
            trades = self.trade_cache[coin_type]
            self.trade_cache[coin_type] = []
            depth = self.depth_cache[coin_type]
            self.depth_cache[coin_type] = []
            if(len(trades) > 0):
                trade_insert = "INSERT IGNORE INTO huobi_%s_trade (time, amount, direction, id, price) VALUES " % coin_type
                trade_insert += "('%s', %s, '%s', '%s', %s)" % (trades[0]['ts'], trades[0]['amount'], trades[0]['direction'], trades[0]['id'], trades[0]['price'])
                for item in trades[1:]:
                    trade_insert += ", ('%s', %s, '%s', '%s', %s)" % (item['ts'], item['amount'], item['direction'], item['id'], item['price'])
                cur.execute(trade_insert)
            if(len(depth) > 0):
                depth_insert = "INSERT IGNORE INTO huobi_%s_depth (time, bids, asks) VALUES " % coin_type
                depth_insert += "('%s', '%s', '%s')" % (depth[0]['ts'], json.dumps(depth[0]['bids'][:10]), json.dumps(depth[0]['asks'][:10]))
                for item in depth[1:]:
                    depth_insert += ", ('%s', '%s', '%s')" % (item['ts'], json.dumps(item['bids'][:10]), json.dumps(item['asks'][:10]))
                cur.execute(depth_insert)
        except Exception:
            self.logger.error(traceback.format_exc())
            
if __name__ == "__main__":
#     tunnel = SSHTunnelForwarder(
#         ("54.222.228.2", 22),
#         ssh_username="strategy_dev",
#         ssh_pkey="/Users/mengxiang/.ssh/id_rsa",
#         remote_bind_address=('strategy.cjkcbp5cnpti.rds.cn-north-1.amazonaws.com.cn', 3306),
#         local_bind_address=('0.0.0.0', rds_port)
#     ) 
#     tunnel.start()
    conn = pymysql.connect(host=rds_host,
                       port=rds_port,
                       user='strategy',
                       passwd='2wsx3edc',
                       connect_timeout=20
                       )
    cur = conn.cursor()
    cur.execute('create database if not exists hft_data')
    cur.execute('use hft_data')
    coin_type_list = ['btc_cny', 'ltc_cny', 'eth_cny', 'etc_cny', 'bcc_cny', 'eth_btc', 'etc_btc', 'ltc_btc', 'bcc_btc']
    
    create_trade_table = '''CREATE TABLE IF NOT EXISTS huobi_%s_trade ( 
                            time VARCHAR(30), 
                            amount DOUBLE, 
                            direction VARCHAR(5),
                            id VARCHAR(30),
                            price DOUBLE,
                            primary key (id))'''
    
    create_depth_table = '''CREATE TABLE IF NOT EXISTS huobi_%s_depth (
                            time VARCHAR(30),
                            bids TEXT,
                            asks TEXT,
                            PRIMARY KEY (time))'''
    
    [cur.execute(create_trade_table % coin_type) for coin_type in coin_type_list]
    [cur.execute(create_depth_table % coin_type) for coin_type in coin_type_list]
    
    proc_list = []
    wsBitexClient = SQLBitexWebsocketClient()
    def bitex_sub():
        wsBitexClient.start()
        logging.info("Start bitex socket")
    proc_list.append(gevent.spawn(bitex_sub))
    
    wsHuobiClient = SQLHuobiWebsocketClient()
    def huobi_sub():
        wsHuobiClient.start()
        logging.info("Start huobi socket")
    proc_list.append(gevent.spawn(huobi_sub))
    
    wsProClient = SQLProWebsocketClient()
    def pro_sub():
        wsProClient.start()
        logging.info("Start pro socket")
    proc_list.append(gevent.spawn(pro_sub))
    
    gevent.joinall(proc_list)