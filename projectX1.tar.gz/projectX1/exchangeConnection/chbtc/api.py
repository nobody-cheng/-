# !/usr/bin/env python
# -*- coding: utf-8 -*-

# @Author : Lloyd Lee


# print(CHBTCRestAPI.get_ticker('eth', 'cny'))
# print(CHBTCRestAPI.get_depth('eth', 'cny', size=1))
# print(CHBTCRestAPI.get_trades('eth', 'cny'))
from exchangeConnection.chbtc.rest_api import CHBTCRestAPI

CHBTC_ACCESS_KEY = ""
CHBTC_SECRET_KEY = ""
chbtc = CHBTCRestAPI(CHBTC_ACCESS_KEY, CHBTC_SECRET_KEY)
print(chbtc.get_acct_info())
# print(chbtc.place_order('eth', 'cny', 1, 0.001, '1'))
print(chbtc.buy_limit('eth', 'usdt', 1, 0.001))
# print(chbtc.get_order_info('eth', 'cny', order_id='2017052668702556'))
# orders = chbtc.get_orders('eth', 'cny')
# print(chbtc.get_actvie_orders('eth', 'cny'))
# print(chbtc.cancel_order('eth', 'cny', '2017052668702556')) # {'message': '操作成功', 'code': 1000}
# print(chbtc.buy_limit('eth', 'cny', 1, 0.001))