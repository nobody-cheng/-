# !/usr/bin/env python
# -*- coding: utf-8 -*-

# @Author : Lloyd Lee
import datetime


class PoloSpotAccountInfo(object):
    def __init__(self, info=None):
        self.btc = None  # available
        self.eth = None  # available
        self.ltc = None  # available

        self.btc_frozen = None
        self.eth_frozen = None
        self.ltc_frozen = None

        self.btc_total = None
        self.eth_total = None
        self.ltc_total = None

        self.btc_value = None
        self.ltc_value = None
        self.eth_value = None

        self.net = None

        if info is not None:
            self.set_up_values(info)

    def set_up_values(self, info):
        self.btc = float(info['BTC']['available'])  # available
        self.ltc = float(info['LTC']['available'])  # available
        self.eth = float(info['ETH']['available']) # available

        self.btc_frozen = float(info['BTC']['onOrders'])
        self.ltc_frozen = float(info['LTC']['onOrders'])
        self.eth_frozen = float(info['ETH']['onOrders'])

        self.btc_total = self.btc + self.btc_frozen
        self.ltc_total = self.ltc + self.ltc_frozen
        self.eth_total = self.eth + self.eth_frozen

        self.btc_value = float(info['BTC']['btcValue'])
        self.ltc_value = float(info['LTC']['btcValue'])
        self.eth_value = float(info['ETH']['btcValue'])

        self.net = self.btc_value + self.ltc_value + self.eth_value


class PoloSpotOrderInfo(object):
    def __init__(self, init_info=None, coin_type=None, currency=None):
        self.order_id = None
        self.order_price = None
        self.order_type = None
        self.order_time_string = None  # string
        self.order_time_unix = None
        self.order_quantity = None
        self.order_amount = None  # value of the order
        self.coin_type = coin_type
        self.currency = currency
        self.currency_pair = None
        self.set_currency_pair(coin_type, currency)

        self.deal_quantity = 0
        self.deal_amount = 0
        self.deal_avg_price = 0
        self.fee = 0
        if init_info:
            self.order_init(init_info)

    def set_currency_pair(self, coin_type, currency):
        if not coin_type or not currency:
            symbol = None
        else:
            coin_type = coin_type.upper()
            currency = currency.upper()
            symbol = currency + '_' + coin_type
        self.currency_pair = symbol

    def order_init(self, info):
        self.order_time_string = info['date']
        self.order_id = info['orderNumber']
        self.order_type = info['type']
        self.order_price = float(info['rate'])
        self.order_quantity = float(info['amount'])
        self.order_amount = float(info['total'])
        self.order_time_unix = datetime.datetime.strptime(self.order_time_string, "%Y-%m-%d %H:%M:%S").timestamp()

    def _reset_deal_info(self):
        self.deal_quantity = 0
        self.deal_amount = 0
        self.deal_avg_price = 0
        self.fee = 0

    def update_order_info(self, trades_info):
        """
        update order info according to trades info
        :param trades_info: list
        :return:
        """
        if not isinstance(trades_info, list):
            return
        self._reset_deal_info()
        for trade in trades_info:
            if not self.coin_type or not self.currency or not self.currency_pair:
                self.currency_pair = trade['currencyPair']
                self.currency, self.coin_type = self.currency_pair.lower().split('_')
            self.deal_amount += float(trade['total'])
            self.deal_quantity += float(trade['amount'])
            self.fee += float(trade['fee'])
        if self.deal_quantity > 0:
            self.deal_avg_price = self.deal_amount / self.deal_quantity






