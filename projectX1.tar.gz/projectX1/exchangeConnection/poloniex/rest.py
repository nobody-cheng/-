# !/usr/bin/env python
# -*- coding: utf-8 -*-

# @Author : Lloyd Lee
import datetime
import urllib
import urllib.parse
import time
import hmac
import hashlib

import requests

from exchangeConnection.poloniex.data import PoloSpotAccountInfo, PoloSpotOrderInfo
# import accountConfig as cfg
import utils.redisHelper as md

PUBLIC_URL = 'https://poloniex.com/public'
TRADE_URL = 'https://poloniex.com/tradingApi'


def http_get(url, params, headers=None):
    if not headers:
        headers = {
            "Content-type": "application/x-www-form-urlencoded",
        }
    payload = urllib.parse.urlencode(params)
    response = requests.get(url, payload, headers=headers, timeout=10)
    if response.status_code == 200:
        return response.json()
    else:
        raise Exception("httpGet failed, detail is:%s" % response.text)


def create_sign(params, secret_key):
    secret_key = secret_key.encode(encoding='utf-8')
    params = urllib.parse.urlencode(params).encode(encoding='utf-8')
    sign = hmac.new(secret_key, params, hashlib.sha512).hexdigest()
    return sign


def post_headers(params, access_key, secret_key):
    sign = create_sign(params, secret_key)
    headers = {
        'Sign': sign,
        'Key': access_key
    }
    return headers


def http_post(url, params, access_key, secret_key, nonce=None):
    nonce = nonce or int(time.time() * 150000000)
    params['nonce'] = nonce
    headers = post_headers(params, access_key, secret_key)
    response = requests.post(url, params, headers=headers, timeout=10)
    if response.status_code == 200:
        return response.json()
    else:
        raise Exception("httpPost failed, detail is:%s" % response.text)


def generate_symbol(coin_type, currency):
    coin_type = coin_type.upper()
    currency = currency.upper()
    symbol = currency + '_' + coin_type
    return symbol


def get_ticker():
    params = dict()
    params['command'] = 'returnTicker'
    return http_get(PUBLIC_URL, params)


def get_depth(coin_type=None, currency=None, depth=10000):
    if not coin_type or not currency:
        symbol = 'all'
    else:
        symbol = generate_symbol(coin_type, currency)
    params = dict()
    params['command'] = 'returnOrderBook'
    params['currencyPair'] = symbol
    if depth:
        params['depth'] = depth
    return http_get(PUBLIC_URL, params)


def get_24volume():
    params = dict()
    params['command'] = 'return24hVolume'
    return http_get(PUBLIC_URL, params)


def get_market_trade_history(coin_type, currency):
    symbol = generate_symbol(coin_type, currency)
    params = dict()
    params['command'] = 'returnTradeHistory'
    params['currencyPair'] = symbol
    return http_get(PUBLIC_URL, params)


def get_kline(coin_type, currency, freq, start_time, end_time=None):
    """
    :param freq: valid: 300(5min), 900(15min), 1800(30min), 7200(2hour), 14400(4hour), and 86400(1day)
    """
    symbol = generate_symbol(coin_type, currency)
    params = dict()
    params['command'] = 'returnChartData'
    params['currencyPair'] = symbol
    params['start'] = start_time
    params['end'] = end_time or '9999999999'
    params['period'] = freq
    return http_get(PUBLIC_URL, params)


def balances(access_key, secret_key):
    """
    :return: Returns all of your available balances
    """
    params = dict()
    params['command'] = 'returnBalances'
    return http_post(TRADE_URL, params, access_key, secret_key)


def complete_balances(access_key, secret_key, account=None):
    """
    :return: Returns all of your balances, including available balance, balance on orders, and the estimated BTC value
        of your balance. By default, this call is limited to your exchange account; set the "account" POST parameter
        to "all" to include your margin and lending accounts.
    """
    params = dict()
    params['command'] = 'returnCompleteBalances'
    if account:
        params['account'] = account
    return http_post(TRADE_URL, params, access_key, secret_key)


def get_active_orders(access_key, secret_key, coin_type=None, currency=None):
    if not coin_type or not currency:
        symbol = 'all'
    else:
        symbol = generate_symbol(coin_type, currency)
    params = dict()
    params['command'] = 'returnOpenOrders'
    params['currencyPair'] = symbol
    return http_post(TRADE_URL, params, access_key, secret_key)


def get_trade_history(access_key, secret_key, coin_type=None, currency=None, start=None, end=None):
    """
    Returns your trade history for a given market, specified by the "currencyPair" POST parameter. You may specify
        "all" as the currencyPair to receive your trade history for all markets. You may optionally specify a range
        via "start" and/or "end" POST parameters, given in UNIX timestamp format; if you do not specify a range,
        it will be limited to one day.
    """
    if not coin_type or not currency:
        symbol = 'all'
    else:
        symbol = generate_symbol(coin_type, currency)
    params = dict()
    params['command'] = 'returnTradeHistory'
    params['currencyPair'] = symbol
    if start:
        params['start'] = start
    if end:
        params['end'] = end
    return http_post(TRADE_URL, params, access_key, secret_key)


def get_order_trades_info(access_key, secret_key, order_number):
    """
    只查询有成交的order记录。未成交的，不会有信息
    """
    params = dict()
    params['command'] = 'returnOrderTrades'
    params['orderNumber'] = order_number
    return http_post(TRADE_URL, params, access_key, secret_key)


def buy(access_key, secret_key, coin_type, currency, rate, amount):
    """
    limit buy
    """
    symbol = generate_symbol(coin_type, currency)
    params = dict()
    params['command'] = 'buy'
    params['currencyPair'] = symbol
    params['rate'] = rate
    params['amount'] = amount
    return http_post(TRADE_URL, params, access_key, secret_key)


def sell(access_key, secret_key, coin_type, currency, rate, amount):
    """
    limit sell
    """
    symbol = generate_symbol(coin_type, currency)
    params = dict()
    params['command'] = 'sell'
    params['currencyPair'] = symbol
    params['rate'] = rate
    params['amount'] = amount
    return http_post(TRADE_URL, params, access_key, secret_key)


def cancel_order(access_key, secret_key, order_number):
    params = dict()
    params['command'] = 'cancelOrder'
    params['orderNumber'] = order_number
    return http_post(TRADE_URL, params, access_key, secret_key)


class PoloRestAPI(object):
    def __init__(self, access_key=None, secret_key=None):
        self._access_key = access_key
        self._secret_key = secret_key

    def set_access_key(self, access_key):
        self._access_key = access_key

    def set_secret_key(self, secret_key):
        self._secret_key = secret_key

    def _check_key(self):
        if self._access_key is None:
            raise ValueError('Missing access_key.')
        if self._secret_key is None:
            raise ValueError('Missing secret_key.')
        return True

    @classmethod
    def create_symbol(cls, coin_type, currency):
        return generate_symbol(coin_type, currency)

    @classmethod
    def coin_type_currency_from_symbol(cls, symbol):
        """
        return cointype, currency
        :param symbol: string like 'BTC_ETH'
        :return: tuple like 'eth', 'btc'
        """
        coin_type, currency = symbol.split('_')
        return coin_type.lower(), currency.lower()

    @classmethod
    def get_kline(cls, coin_type, currency, freq, start_time, end_time=None):
        return get_kline(coin_type, currency, freq, start_time, end_time=end_time)

    @classmethod
    def get_ticker(cls):
        return get_ticker()

    @classmethod
    def get_market_trade_history(cls, coin_type, currency):
        return get_market_trade_history(coin_type, currency)

    @classmethod
    def get_depth(cls, coin_type, currency):
        return get_depth(coin_type=coin_type, currency=currency)

    def get_balance(self):
        self._check_key()
        balance_info = balances(self._access_key, self._secret_key)
        return balance_info

    def get_spot_acct_info(self):
        self._check_key()
        acct_info = complete_balances(self._access_key, self._secret_key)
        return PoloSpotAccountInfo(acct_info)

    def get_active_orders(self, coin_type, currency):
        """
        return active orders of given coint_type and currency pair
        :param coin_type:
        :param currency:
        :return: list
        """
        self._check_key()
        return get_active_orders(self._access_key, self._secret_key, coin_type=coin_type, currency=currency)

    def get_all_active_orders(self):
        """
        return all kinds of active orders
        :return: dict
        """
        self._check_key()
        return get_active_orders(self._access_key, self._secret_key)

    def get_trade_history(self, coin_type=None, currency=None, start=None, end=None):
        """
        return user's trades history. (not order history)
        :param coin_type:
        :param currency:
        :param start:
        :param end:
        :return:
        """
        self._check_key()
        return get_trade_history(self._access_key, self._secret_key, coin_type=coin_type, currency=currency, start=start, end=end)

    def get_order_trades_info(self, order_id):
        """
        if no trades occur, return error
        :param order_id:
        :return:
        """
        self._check_key()
        return get_order_trades_info(self._access_key, self._secret_key, order_number=order_id)

    def get_order_info(self, order_id):
        self._check_key()
        trades_info = self.get_order_trades_info(order_id)
        order_info = PoloSpotOrderInfo()
        order_info.update_order_info(trades_info)
        return order_info

    def update_order_info(self, order):
        """
        update order info
        :type order: PoloSpotOrderInfo
        :return:
        """
        if not isinstance(order, PoloSpotOrderInfo):
            raise ValueError('must be type: <PoloSpotOrderInfo>')
        if not order.order_id:
            raise ValueError('missing order id')
        self._check_key()
        trades_info = self.get_order_trades_info(order.order_id)
        order.update_order_info(trades_info)
        return order

    def spot_buy(self, coin_type, currency, rate, quantity):
        self._check_key()
        order = PoloSpotOrderInfo()
        order.order_type = 'buy'
        order.coin_type = coin_type
        order.currency = currency
        order.currency_pair = coin_type + '_' + currency
        order.order_price = rate
        order.order_quantity = quantity
        order.order_amount = rate * quantity
        order.order_time_unix = time.time()
        order.order_time_string = datetime.datetime.strftime(datetime.datetime.fromtimestamp(order.order_time_unix),
                                                             "%Y-%m-%d %H:%M:%S")

        order_result = buy(self._access_key, self._secret_key, coin_type, currency, rate, quantity)
        if 'orderNumber' in order_result:
            order.order_id = order_result['orderNumber']
            return order
        else:
            raise Exception('Poloniex: place order error. %s' % order_result)

    def spot_sell(self, coin_type, currency, rate, quantity):
        self._check_key()
        order = PoloSpotOrderInfo()
        order.order_type = 'sell'
        order.coin_type = coin_type
        order.currency = currency
        order.currency_pair = coin_type + '_' + currency
        order.order_price = rate
        order.order_quantity = quantity
        order.order_amount = rate * quantity
        order.order_time_unix = time.time()
        order.order_time_string = datetime.datetime.strftime(datetime.datetime.fromtimestamp(order.order_time_unix),
                                                             "%Y-%m-%d %H:%M:%S")

        order_result = sell(self._access_key, self._secret_key, coin_type, currency, rate, quantity)
        if 'orderNumber' in order_result:
            order.order_id = order_result['orderNumber']
            return order
        else:
            raise Exception('Poloniex: place order error. %s' % order_result)

    def cancel_order(self, order_id):
        self._check_key()
        cancel_res = cancel_order(self._access_key, self._secret_key, order_id)
        if 'success' in cancel_res:
            return 'success'
        else:
            raise Exception('Poloniex: cancel order <order-id: %s> error. %s' % (order_id, cancel_res))


def init_polo_account(key_index=None):
    if key_index is None:
        access_key, secret_key = "", ""
    else:
        acc = md.get_account("polo", key_index)
        access_key = acc.get("ACCESS_KEY")
        secret_key = acc.get("SECRET_KEY")
    return PoloRestAPI(access_key=access_key, secret_key=secret_key)