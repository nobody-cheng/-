#!/usr/bin/env python
# -*- coding: utf-8 -*-

from exchangeConnection.huobi.huobiService import *
from exchangeConnection.huobi.realData import *
from serverConfig import *
from utils.helper import *

valid_security_list = [HUOBI_CNY_BTC, HUOBI_CNY_LTC]

frequency_to_seconds = {
    "1m": 60,
    "5m": 5 * 60,
    "15m": 15 * 60,
    "30m": 30 * 60,
    "60m": 60 * 60,
    "4h": 4 * 60 * 60,
    "1d": 60 * 60 * 24,
    "1w": 60 * 60 * 24 * 7,
    "1M": 60 * 60 * 24 * 30,
    "1y": 60 * 60 * 24 * 360
}

db = MySQLDB(
    DATA_USER,
    DATA_PASSWORD,
    DATA_HOST,
    DATA_DB_NAME,
)
query_obj = Query(db, datetime.datetime.now)

DEFAULT_TIME_FORMAT = "%Y-%m-%d %H:%M:%S"

def get_current_price(security):
    # 取得最近1 minute bar的close
    minute_hist = get_price(security, count=1, frequency="1m")
    start_time_for_waiting_data = time.time()
    while len(minute_hist.index) == 0 and time.time() - start_time_for_waiting_data < LATEST_DATA_DELAY_THRESHOLD:
        time.sleep(1)
        minute_hist = get_price(security, count=1, frequency="1m")

    if len(minute_hist.index) == 0:
        raise Exception("数据更新不及时，程序异常退出！")

        # check the last bar vs last_processed_bar_start_time
    current_price = minute_hist['close'][-1]
    return current_price


def get_price_v2(security, count=None, start_time=None, end_time=None, frequency="None"):
    return query_obj.get_price(
        security=security,
        count=count,
        start_time=start_time,
        end_time=end_time,
        frequency=frequency,
    )


def str2time(time_str):
    if not isinstance(time_str, str):
        raise TypeError(
            "You can only convert string to datetime, not %s" % type(time_str)
        )
    try:
        time = dt.datetime.strptime(time_str, DEFAULT_TIME_FORMAT)
    except ValueError:
        raise ValueError("时间格式不合法，需要 %s " % DEFAULT_TIME_FORMAT)
    return dt.datetime(*time.timetuple()[:6])


def get_price(security, count=None, start_time=None, end_time=None, frequency="None"):
    dt_now = dt.datetime.now()
    if count is not None and start_time is not None:
        raise ValueError("count and start_time can not be both setup")
    coinMarketType = getCoinMarketTypeFromSecurity(security)
    coin_type = coinTypeStructure[coinMarketType]["huobi"]["coin_type"]
    if count is not None:
        data = get_prices(coin_type, frequency=frequency, length=count+1)
    else:
        data = get_prices(coin_type, frequency=frequency)
    # 移除掉最后一根未完成的bar
    _frequency = string2frequency(frequency)
    if data.index[-1] + dt.timedelta(seconds=_frequency) > dt_now:
        data = data[0:len(data)-1]
    if start_time is not None:
        start_time = str2time(start_time)
        if end_time is None:
            end_time = dt.datetime.now()
        else:
            end_time = str2time(end_time)
        data = data[data.index >= start_time]
        data = data[data.index < end_time]
    return data

def get_all_securities():
    result = {"security": [],
              "exchange": [],
              "settlement_currency": []}
    result["security"].append(HUOBI_CNY_BTC)
    result["exchange"].append("huobi")
    result["settlement_currency"].append(COIN_TYPE_CNY)

    result["security"].append(HUOBI_CNY_LTC)
    result["exchange"].append("huobi")
    result["settlement_currency"].append(COIN_TYPE_CNY)
    result = pd.DataFrame(result)
    return result


if __name__ == "__main__":
    # print(get_current_price(HUOBI_CNY_BTC))
    print(get_price(HUOBI_CNY_BTC, frequency="1m", count=100))
    #print(get_price_v2(HUOBI_CNY_BTC, frequency="1m", count=100))
    print(get_current_price(HUOBI_CNY_BTC))
