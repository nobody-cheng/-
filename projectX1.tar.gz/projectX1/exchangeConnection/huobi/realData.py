# coding: utf-8
import datetime as dt

import pandas as pd
import pymysql

from serverConfig import *

pymysql.install_as_MySQLdb()
from sqlalchemy import engine

GET_PRICE_DEFAULT_BAR_COUNT = 200
GET_PRICE_MIN_BAR_COUNT = 1
GET_PRICE_MAX_BAR_COUNT = 14400
BTC_NAME = 'huobi_cny_btc'
LTC_NAME = 'huobi_cny_ltc'

"""
.. moduleauthor:: joffrey <@huobi.inc>
.. refers to pyalgotrade/barfeed/sqlitefeed.py
"""

INSTRUMENTS_IDS = ['btccny_bars', 'ltccny_bars']
SECURITY_MAP = {
    BTC_NAME: 'btccny',
    LTC_NAME: 'ltccny',
}

_SECOND = 1
_MINUTE = _SECOND * 60
_HOUR = _MINUTE * 60
_DAY = _HOUR * 24
_WEEK = _DAY * 7
_MONTH = _DAY * 31

FREQUENCY_TUPLE = (
    ("1m", _MINUTE),
    ("5m", _MINUTE * 5),
    ("15m", _MINUTE * 15),
    ("30m", _MINUTE * 30),
    ("60m", _HOUR),
    ("4h", _HOUR * 4),
    ("1d", _DAY),
    ("1w", _WEEK),
    # ("1M", _MONTH),
    # ("1y", _DAY * 365),
)

FREQUENCY_MAP = dict(
    FREQUENCY_TUPLE
)

DEFAULT_TIME_FORMAT = "%Y-%m-%d %H:%M:%S"

DROP_QUERY = "drop table {instrument}_bars"
CREATE_QUERY = """
CREATE TABLE `{instrument}_bars` (
    `id` bigint(20) unsigned NOT NULL AUTO_INCREMENT COMMENT 'meaningless primary key',
    `bar_time` datetime  COMMENT 'datetime type to identify time range',
    `volume` decimal(20,0) unsigned NOT NULL COMMENT 'total amount happend during the time range',
    `open` decimal(20,0) unsigned NOT NULL COMMENT 'open price',
    `high` decimal(20,0) unsigned NOT NULL COMMENT 'highest price',
    `low` decimal(20,0) unsigned NOT NULL  COMMENT 'lowest price',
    `close` decimal(20,0) unsigned NOT NULL COMMENT 'close price',
    `adj_close` decimal(20,0) unsigned NOT NULL COMMENT 'adjusted close price, always equals to close price',
    `frequency` decimal(20,0) unsigned NOT NULL COMMENT '1min=60 1hour=1min*60 and so on',
    PRIMARY KEY (`id`),
    KEY idx_time_frequency (`bar_time`,`frequency`),
    KEY idx_time (`bar_time`),
    KEY idx_frequency (`frequency`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8
"""


def freq2delta(frequency):
    return dt.timedelta(seconds=frequency)


def get_query_time(start_time_in, end_time_in, frequency):
    """
    Get query time range in SQL query.
    """
    end_freq_delta = freq2delta(frequency - 1)
    start_freq_delta = freq2delta(frequency - 1)
    return start_time_in - start_freq_delta, end_time_in - end_freq_delta


def time2str(datetime_obj):
    assert isinstance(datetime_obj, dt.datetime), "got %s: %s" % (type(datetime_obj), datetime_obj)
    return datetime_obj.strftime(DEFAULT_TIME_FORMAT)


def str2time(time_str):
    if not isinstance(time_str, str):
        raise TypeError(
            "You can only convert string to datetime, not %s" % type(time_str)
        )
    try:
        time = dt.datetime.strptime(time_str, DEFAULT_TIME_FORMAT)
    except ValueError:
        raise ValueError("时间格式不合法，需要 %s " % DEFAULT_TIME_FORMAT)
    return dt.datetime(*time.timetuple()[:6])


def mk_time_period(frequency, start_time=None, end_time=None, count=None):
    """
    :type frequency: int
    :type start_time:
    :type end_time:
    :type count:
    :rtype: list[str]
    """
    _start_time = start_time

    if all((start_time, count)):
        raise ValueError("不能同时配置start_time和count")
    if end_time is None:
        raise ValueError("end_time不能是None")
    _end_time = end_time

    if start_time is None:
        _start_time, _end_time = _count2time(count, frequency, end_time)

    return _start_time, _end_time


def _count2time(count, frequency, end_time):
    """
    Convert count and end-time to start_time and end_time pair.
    :type count: int
    :type frequency: int
    :type end_time: datetime.datetime
    """
    end_time = end_time
    start_time = end_time - dt.timedelta(seconds=frequency * count)
    return start_time, end_time


def _convert2db_field(security_name):
    return SECURITY_MAP[security_name]


def _get_table_name(raw_security):
    instrument = _convert2db_field(raw_security)
    return instrument + "_bars"


def time_range2count(start_time, end_time, frequency):
    """
    Return if the start_time and end_tie got the bad bar-count.
    :type start_time: datetime.datetime
    :type end_time: datetime.datetime
    :param frequency: seconds in int
    :return: int of the count number
    """
    return (end_time - start_time).total_seconds() / frequency


class MySQLFeedException(Exception):
    pass


class GetPriceTimeParams(object):
    def __init__(self, start_time, end_time, frequency):
        self.start_time = start_time
        self.end_time = end_time
        self.frequency = frequency

    def validate(self):
        if self.end_time <= self.start_time:
            raise ValueError("end time should always greater than start time")

        count = time_range2count(
            self.start_time,
            self.end_time,
            self.frequency,
        )
        if not (GET_PRICE_MIN_BAR_COUNT <= count <= GET_PRICE_MAX_BAR_COUNT):
            raise ValueError(
                "Start-time, end-time and frequency pair is invalid,"
                " you can only access %s of bars." % GET_PRICE_MAX_BAR_COUNT
            )
        return True


# Mysql DB.
# Timestamps are stored in UTC.
class MySQLDB(object):
    def __init__(
            self,
            user,
            password,
            host,
            db_name,
            is_utc=None,
    ):
        if password is None:
            raise MySQLFeedException("please provide mysql credentials.")

        server = "mysql://{user}:{passwd}@{host}/{db}".format(
            user=user,
            passwd=password,
            host=host,
            db=db_name
        )
        self.__engine = engine.create_engine(server)

    def get_engine(self):
        return self.__engine

    def get_bars(self, security, frequency, from_datetime, to_datetime):
        """
        :param from_datetime: utc datetime object
        :param to_datetime: utc datetime object
        """
        instrument = _convert2db_field(security)
        return self._get_bars(security, instrument, frequency, from_datetime, to_datetime)

    def _get_bars(self, security_name, instrument, frequency, from_datetime, to_datetime, desc=False):
        """
        :param instrument: secrurity name
        :param frequency: integer that stands for seconds
        :param from_datetime:  datetime object
        :param to_datetime: datetime object

        :comment Lack of type checking
        :limit Rows
        : !careful! sql injection attack should be considered
        """
        # TODO(winkidney): Use "?" to query instead of the string join.
        sql_str = """
        SELECT
        bar.bar_time,
        bar.open,
        bar.high,
        bar.low,
        bar.close,
        bar.volume,
        bar.adj_close,
        bar.frequency
        FROM
        {table_name} bar
        WHERE
        bar.frequency = {frequency}
        """.format(
            table_name=instrument + "_bars",
            frequency=frequency
        )
        start_time, end_time = get_query_time(from_datetime, to_datetime, frequency)

        if from_datetime is not None:
            sql_str += " AND bar.bar_time >= '{}' ".format(time2str(start_time))
        if to_datetime is not None:
            sql_str += " AND bar.bar_time < '{}' ".format(time2str(end_time))

        sql_str += " order by bar.bar_time"
        if desc:
            sql_str += " desc"

        bar_time_list = []
        bar_dict_list = {
            "security": [],
            "open": [],
            "high": [],
            "low": [],
            "close": [],
            "volume": [],
        }
        columns = ("security", "open", "high", "low", "close", "volume")
        c = self.__engine.connect()
        for row in c.execute(sql_str).fetchall():
            _bar_time, _open, _high, _low, _close, _volume, _adj_close, _frequency = row.values()

            bar_time_list.append(_bar_time)
            bar_dict_list['security'].append(security_name)
            bar_dict_list['open'].append(_open / 1e10)
            bar_dict_list['high'].append(_high / 1e10)
            bar_dict_list['low'].append(_low / 1e10)
            bar_dict_list['close'].append(_close / 1e10)
            bar_dict_list['volume'].append(_volume / 1e10)
        c.close()

        return pd.DataFrame(
            data=bar_dict_list,
            index=bar_time_list,
            columns=columns
        )

    def get_price(self, security, frequency, count=None, start_time=None, end_time=None):
        """
        :param frequency: seconds, an int.
        :type frequency: int
        :type security: str
        :type count: int
        :type start_time: datetime.datetime, CST time
        :type end_time: datetime.datetime, CST time
        """
        if not any((count, start_time, end_time)):
            count = GET_PRICE_DEFAULT_BAR_COUNT
        _start_time, _end_time = mk_time_period(
            frequency,
            start_time=start_time,
            end_time=end_time,
            count=count,
        )

        return self.get_bars(security, frequency, _start_time, _end_time)


def string2frequency(frequency_string):
    _frequency = FREQUENCY_MAP.get(frequency_string)
    if _frequency is None:
        raise ValueError(
            "频率非法，必须是如下频率之一： %s"
            % str(tuple(key for key, value in FREQUENCY_TUPLE))
        )
    return _frequency


class Query(object):
    def __init__(self, db, get_curent_time_func):
        self._get_current_time = get_curent_time_func
        self.db = db

    def get_price(self, security, frequency=None, count=None, start_time=None, end_time=None):
        """
        :type security: str
        :type frequency: str
        :type count: int
        :type start_time: str
        :type end_time: str
        :rtype: pandas.DataFrame
        """
        security = security
        _end_time, _start_time = end_time, start_time

        _frequency = string2frequency(frequency)

        if start_time is not None:
            _start_time = str2time(start_time)

        if end_time is not None:
            _end_time = str2time(end_time)
        else:
            _end_time = self._get_current_time()

        if all((start_time, end_time)):
            GetPriceTimeParams(_start_time, _end_time, _frequency).validate()

        return self.db.get_price(
            security, _frequency, count=count, start_time=_start_time,
            end_time=_end_time,
        )


if __name__ == "__main__":
    db = MySQLDB(
        DATA_USER,
        DATA_PASSWORD,
        DATA_HOST,
        DATA_DB_NAME,
    )
    query_obj = Query(db, dt.datetime.now)
    print(
        query_obj.get_price(
            security="huobi_cny_btc",
            frequency="60m",
            start_time="2015-9-10 0:0:0",
            end_time="2015-10-10 0:0:0",
        )
    )
