#!/usr/bin/env python
# -*- coding: utf-8 -*-

import hashlib
import time
import urllib
import urllib.parse
import urllib.request

import requests

import utils.redisHelper as md

# 在此输入您的Key
KEY_INDEX = "CNY_1"  # 默认的key_index

ACCOUNT_INFO = "get_account_info"
GET_ORDERS = "get_orders"
ORDER_INFO = "order_info"
BUY = "buy"
BUY_MARKET = "buy_market"
CANCEL_ORDER = "cancel_order"
NEW_DEAL_ORDERS = "get_new_deal_orders"
ORDER_ID_BY_TRADE_ID = "get_order_id_by_trade_id"
SELL = "sell"
SELL_MARKET = "sell_market"
SERVICE_API = "https://api.huobi.com/apiv3"


'''
request
'''


def httpRequest(url, params):
    '''
    postdata = urllib.parse.urlencode(params)
    postdata = postdata.encode('utf-8')

    fp = urllib.request.urlopen(url, postdata, timeout = 5)
    if fp.status != 200:
        return None
    else:
        mybytes = fp.read()
        mystr = mybytes.decode("utf8")
        fp.close()
        return mystr
    '''
    headers = {
        "Content-type": "application/x-www-form-urlencoded",
    }

    postdata = urllib.parse.urlencode(params)
    # postdata = postdata.encode('utf-8')
    time.sleep(0.2)
    response = requests.post(url, postdata, headers=headers, timeout=5)
    if response.status_code == 200:
        return response.json()
    else:
        raise Exception("httpPost failed, detail is:%s" % response.text)


class HuobiUtil:
    def __init__(self, acc_id=None):
        if acc_id is None:
            self.access_key = ""
            self.secret_key = ""
        else:
            acc = md.get_account("huobi", acc_id)
            self.access_key = acc.get("ACCESS_KEY")
            self.secret_key = acc.get("SECRET_KEY")

    def send2api(self, params, extra):
        """
        发送信息到api
        :param params:
        :param extra:
        :param key_index:
        :return:
        """
        params['access_key'] = self.access_key
        params['created'] = int(time.time())
        params['secret_key'] = self.secret_key
        sorted_params = sorted(params.items(), key=lambda d: d[0], reverse=False)
        params['sign'] = self.create_sign(sorted_params)
        if extra:
            for k in extra:
                v = extra.get(k)
                if v is not None:
                    params[k] = v
        return httpRequest(SERVICE_API, params)

    @staticmethod
    def create_sign(params):
        """
        生成签名
        :param params:
        :return:
        """
        message = urllib.parse.urlencode(params)
        message = message.encode(encoding='UTF8')
        m = hashlib.md5()
        m.update(message)
        m.digest()
        sig = m.hexdigest()
        return sig

