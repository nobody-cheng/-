#!/usr/bin/env python
# -*- coding: utf-8 -*-

# import accountConfig
from exchangeConnection.okcoin.okcoinFutureAPI import OKCoinFuture
from exchangeConnection.okcoin.okcoinSpotAPI import OKCoinSpot
import utils.redisHelper as md

# 初始化ACCESS_KEY, SECRET_KEY, SERVICE_API
# ACCESS_KEY = accountConfig.OKCOIN["CNY_1"]["ACCESS_KEY"]
# SECRET_KEY = accountConfig.OKCOIN["CNY_1"]["SECRET_KEY"]
# SERVICE_API = accountConfig.OKCOIN["CNY_1"]["SERVICE_API"]
SERVICE_API = "https://www.okcoin.cn"
future_url = "https://www.okex.com"


# 现货API
def getOkcoinSpot(acc_id=None):
    if acc_id is None:
        return OKCoinSpot(SERVICE_API, "", "")
    else:
        acc = md.get_account("okcoin", acc_id)
        return OKCoinSpot(SERVICE_API, acc.get("ACCESS_KEY"), acc.get("SECRET_KEY"))


# 期货API
def getOkcoinFuture(acc_id=None):
    if acc_id is None:
        return OKCoinSpot(SERVICE_API, "", "")
    else:
        acc = md.get_account("okcoin", acc_id)
        return OKCoinFuture(future_url, acc.get("ACCESS_KEY"), acc.get("SECRET_KEY"))


