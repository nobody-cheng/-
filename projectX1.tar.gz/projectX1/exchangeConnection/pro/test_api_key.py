#!/usr/bin/env python
# -*- coding: utf-8 -*-
from exchangeConnection.pro.key_api import *

# print(get_accounts_all())
# print(get_balance("70"))
# print(order('ethbtc',0.19, 10, 'buy-limit', '70'))
# print(active_orders('ethbtc'))
# print(order_info('107909'))
# print(get_depth('ethcny', 'step0'))
# print(get_trade('ethcny'))
# data = orders_info_list('partial-canceled,filled,canceled', 'ethcny', start_date='2017-05-31', record_size=10000)['data']
# print(get_accounts_all())
# print(active_orders('ltcbtc'))
# print(get_kline('ethbtc', '1min'))
# print(get_depth('ethbtc', 'step1'))


from exchangeConnection.pro.proService import init_pro_account

api = init_pro_account('CNY_1')
print(api.get_active_orders('ethbtc'))