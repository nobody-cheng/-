#
# WebsocketClient.py
#
# Template object to receive messages from the gdax Websocket Feed

import json, gzip, io, logging, time, traceback
from threading import Thread
from websocket import create_connection, WebSocketConnectionClosedException

pro_url = "wss://api.huobi.pro/ws"

class ProWebsocketClient(object):
    def __init__(self, logger=None):
        self.stop = False
        self.ws = None
        self.thread = None
        self.sub_trade_list = set([])
        self.sub_depth_list = set([])
        if(logger == None):
            self.logger = logging
        else:
            self.logger = logger
        
    def start(self):
        self._connect()
        self.on_open()
        self.thread = Thread(target=self._listen)
        self.thread.start()
    
    def close(self):
        if not self.stop:
            self.on_close()
            self.stop = True
            self.thread.join()
            if self.ws:
                self.ws.close()

    def on_open(self):
        ## url and products should stay the same
        self.logger.info("Socket started...")
    
    def on_close(self):
        self.logger.info("Socket closed...")
        
    def _connect(self):
        self.ws = create_connection(pro_url)
    
    def conn_recover(self):
        self._connect()
        self.on_open()
        for coin_type in self.sub_trade_list:
            self.sub_trade(coin_type)
        for coin_type in self.sub_depth_list:
            self.sub_depth(coin_type)
        
    def _listen(self):
        self.logger.info("start listening pro ws")
        heartbeat_time = time.time()
        while not self.stop:
            try:
                compressedstream = io.BytesIO(self.ws.recv())  
                gziper = gzip.GzipFile(fileobj=compressedstream)    
                msg = eval(gziper.read().decode('utf-8'))  ## convert str to dict
                if msg.get('ping'):
                    params={"pong":msg.get('ping')}
                    self.ws.send(json.dumps(params))
                elif msg.get('subbed'):
                    self.logger.info(msg)
                else:
                    self.on_message(msg)
                
                if(time.time() - heartbeat_time > 20):
                    self.logger.info("Pro ws heartbeat.")
                    heartbeat_time = time.time()
            except WebSocketConnectionClosedException:
                self.logger.error("WS connection broken, recover connection...")
                self.conn_recover()
            except Exception:
                self.logger.error(traceback.format_exc())
                time.sleep(5)
    
    def coin_type_format(self, symbol):
        if(symbol.startswith('dash')):
            return 'dash_%s' % symbol.replace('dash', '')
        if(symbol.endswith('usdt')):
            return '%s_usdt' % symbol.replace('usdt', '')
        return '%s_%s' % (symbol[:3], symbol[3:])
    
    def sub_trade(self, coin_type):
        params = {"sub":"market.%s.%s" % (coin_type.replace('_', ''), 'trade.detail'),"id": "id_%s_%s" % (coin_type.replace('_', ''), 'trade.detail')}
        self.ws.send(json.dumps(params))
        self.sub_trade_list.add(coin_type)   
    
    def sub_depth(self, coin_type):
        params = {"sub":"market.%s.%s" % (coin_type.replace('_', ''), "depth.step0"),"id": "id_%s_%s" % (coin_type.replace('_', ''), "depth.step0")}
        self.ws.send(json.dumps(params))
        self.sub_depth_list.add(coin_type)
        
    def unsub_trade(self, coin_type):
        params = {"sub":"market.%s.%s" % (coin_type.replace('_', ''), 'trade.detail'),"id": "id_%s_%s" % (coin_type.replace('_', ''), 'trade.detail')}
        self.ws.send(json.dumps(params))
        self.sub_trade_list.remove(coin_type)
    
    def unsub_depth(self, coin_type):
        params = {"sub":"market.%s.%s" % (coin_type.replace('_', ''), "depth.step0"),"id": "id_%s_%s" % (coin_type.replace('_', ''), "depth.step0")}
        self.ws.send(json.dumps(params))
        self.sub_depth_list.remove(coin_type) 

    def on_message(self, msg):
        if('depth.step0' in msg.get("ch")):
            coin_type = self.coin_type_format(msg.get("ch").split('.')[1])
            self.on_depth(coin_type, msg)
        elif('trade.detail' in msg.get('ch')):
            coin_type = self.coin_type_format(msg.get("ch").split('.')[1])
            self.on_trade(coin_type, msg)
        else:
            self.logger.error("Unexpected message: %s" % str(msg))
            raise Exception
    
    def on_trade(self, coin_type, msg):
        raise NotImplementedError()
    
    def on_depth(self, coin_type, msg):
        raise NotImplementedError()

        
