#!/usr/bin/env python
# -*- coding: utf-8 -*-
from exchangeConnection.pro.token_api import *

login_name = "13877778888"
password = "aa471b257eb1053a530957fe0416bb91"
# asset_pwd = "893d51fd295a07d0a832f2b24b0a6ea7"
# auth_data = "%7B%22assetPwd%22%3A%22893d51fd295a07d0a832f2b24b0a6ea7%22%7D"

# print(get_kline('btccny', '5min', pick='["high"]'))
# {'tick': None, 'status': 'ok', 'ts': 1494313683585, 'ch': 'market.btccny.kline.5min'}

# print(get_depth('btccny', 'step3'))
# {'status': 'ok', 'ts': 1494313695528, 'tick': None, 'ch': 'market.btccny.depth.step3'}

# print(get_trade('btccny'))
# {'ts': 1494313663752, 'tick': None, 'status': 'ok', 'ch': 'market.btccny.trade.detail'}

# print(login(login_name, password))
# {'data': {'expire-time': 1494918448912, 'user-id': 112800, 'token': 'ZJcBjcIN8X7F-el49B2cEzbKcmDT51PvvnXyxGORKv8Y-uOP2m0-gvjE57ad1qDF'}, 'status': 'ok'}

# print(verify_token('VsHyrsGR4B9j0I7PkvCgVFvsc3Kp5eQwuHxgY2u3KWsY-uOP2m0-gvjE57ad1qDF'))
# {'data': {'expire-time': 1494918394567, 'app-type': 'WEB', 'status': 'ok', 'user-id': 112800}, 'status': 'ok'}

# print(get_accounts_all('yGJTyjwqXvd9OeLgQ8n2RHDuMqLnIW6yPTIKhuSk1QgY-uOP2m0-gvjE57ad1qDF', 'spot'))
#{"status": "ok", "data": [{"id" : 1,"user­id" : 1000, "type" : "spot", "state" : "working"}, {"id" : 2,"user­id" : 1000, "type" : "loan", "state" : "working"} ]}

# print(get_balance('qTkl4ddppAU1M3mSxp2uvSpZpXhfmsgAtcphlAvjq9cY-uOP2m0-gvjE57ad1qDF', 110))

# print(order("btccny", 1000, 1, "buy-market", 100, 'yGJTyjwqXvd9OeLgQ8n2RHDuMqLnIW6yPTIKhuSk1QgY-uOP2m0-gvjE57ad1qDF', "%7B%22assetPwd%22%3A%22893d51fd295a07d0a832f2b24b0a6ea7%22%7D"))

# print(auth_verify('yGJTyjwqXvd9OeLgQ8n2RHDuMqLnIW6yPTIKhuSk1QgY-uOP2m0-gvjE57ad1qDF', "{\"assetPwd\":\"893d51fd295a07d0a832f2b24b0a6ea7\"}", "TRADE"))
# {'status': 'ok', 'data': {'safety-code': '2272d179-a713-4049-84cd-b5d4d4e6592a', 'user-id': 112800}}

# print(place_order("12334", 'yGJTyjwqXvd9OeLgQ8n2RHDuMqLnIW6yPTIKhuSk1QgY-uOP2m0-gvjE57ad1qDF', "%7B%22assetPwd%22%3A%22893d51fd295a07d0a832f2b24b0a6ea7%22%7D"))

# print(cancel_order("12334", 'yGJTyjwqXvd9OeLgQ8n2RHDuMqLnIW6yPTIKhuSk1QgY-uOP2m0-gvjE57ad1qDF', "%7B%22assetPwd%22%3A%22893d51fd295a07d0a832f2b24b0a6ea7%22%7D"))

# print(order_info("12334", 'yGJTyjwqXvd9OeLgQ8n2RHDuMqLnIW6yPTIKhuSk1QgY-uOP2m0-gvjE57ad1qDF'))

# print(active_orders('yGJTyjwqXvd9OeLgQ8n2RHDuMqLnIW6yPTIKhuSk1QgY-uOP2m0-gvjE57ad1qDF', 'ethcny'))