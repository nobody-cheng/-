#!/usr/bin/env python
# -*- coding: utf-8 -*-

from exchangeConnection.bittrex.Bittrexapi import Bittrex
import utils.redisHelper as rh
import datetime
import pandas as pd


def Bittrex_Service(key_index=None, sub_key=None):
    if key_index is None:
        access_key, secret_key = "", ""
    else:
        acc = rh.get_account("bittrex", key_index)
        access_key = acc[sub_key].get("ACCESS_KEY")
        secret_key = acc[sub_key].get("SECRET_KEY")
    return BittrexServiceAPIKey(access_key=access_key, secret_key=secret_key)


class BittrexServiceAPIKey(object):
    def __init__(self, access_key=None, secret_key=None):
        self._access_key = access_key
        self._secret_key = secret_key

    def set_access_key(self, access_key):
        self._access_key = access_key

    def set_secret_key(self, secret_key):
        self._secret_key = secret_key

    def _check_key(self):
        if self._access_key is None:
            raise ValueError('Missing access_key.')
        if self._secret_key is None:
            raise ValueError('Missing secret_key.')
        return True

    @classmethod
    def create_symbol(cls, coin_type, currency):
        symbol =currency.upper() + '-' + coin_type.upper()
        return symbol

    @classmethod
    def get_trading_market(cls):
        ret = Bittrex(api_key = None, api_secret = None).get_markets()
        results = ret['result']
        if results:
            return results
        else:
            return ret['message']
        
    @classmethod
    def get_active_market(cls, coin_type, currency):
        symbol = cls.create_symbol(coin_type, currency)
        ret = Bittrex(api_key = None, api_secret = None).get_marketsummary(symbol)
        results = ret['result']
        if results:
            return results
        else:
            return ret['message']

    @classmethod
    def get_ticker(cls, coin_type, currency):
        symbol = cls.create_symbol(coin_type, currency)
        ret = Bittrex(api_key = None, api_secret = None).get_ticker(symbol)
        results = ret['result']
        if results:
            return results
        else:
            return ret['message']

    @classmethod
    def get_depth(cls,coin_type, currency, size=None):
        symbol = cls.create_symbol(coin_type, currency)
        ret = Bittrex(api_key = None, api_secret = None).get_orderbook(symbol,depth_type = 'both',depth=size)
        results = ret['result']
        if results:
            return results
        else:
            return ret['message']

    @classmethod
    def get_trades(cls, coin_type, currency, size=None):
        symbol = cls.create_symbol(coin_type, currency)
        ret = Bittrex(api_key = None, api_secret = None).get_market_history(symbol, size)
        results = ret['result']
        if results:
            return results
        else:
            return ret['message']

    def get_last_trades(self, symbol):
        coin_type, currency = symbol.split("_")
        ret = self.get_trades(coin_type, currency)
        db_list = []
        db_list.extend(ret)
        df = pd.DataFrame(db_list)
        df['ts'] = df.apply(lambda x: datetime.datetime.strptime(x['TimeStamp'].split(".")[0], "%Y-%m-%dT%H:%M:%S"),
                            axis=1)
        df = df.set_index('ts')
        return df

    def get_acct_infos(self,access_key=None, secret_key=None):
        if not access_key:
            access_key = self._access_key
        if not secret_key:
            secret_key = self._secret_key
        ret = Bittrex(api_key = access_key, api_secret = secret_key).get_balances()
        if ret:
            return ret
        else:
            return ret['message']
         
    def buy_limit(self, coin_type, currency, price, amount , access_key=None, secret_key=None):
        if not access_key:
            access_key = self._access_key
        if not secret_key:
            secret_key = self._secret_key
        symbol = self.create_symbol(coin_type, currency)
        ret = Bittrex(api_key = access_key, api_secret = secret_key).buy_limit(symbol, amount, price)
        results = ret['result']
        if results:
            return results
        else:
            return ret['message']
         
    def sell_limit(self, coin_type, currency, price, amount,access_key=None, secret_key=None):
        if not access_key:
            access_key = self._access_key
        if not secret_key:
            secret_key = self._secret_key
        symbol = self.create_symbol(coin_type, currency)
        ret = Bittrex(api_key = access_key, api_secret = secret_key).sell_limit(symbol, amount, price)
        results = ret['result']
        if results:
            return results
        else:
            return ret['message']
        
    def get_order_info(self, order_id, access_key=None, secret_key=None):
        if not access_key:
            access_key = self._access_key
        if not secret_key:
            secret_key = self._secret_key
        ret = Bittrex(api_key = access_key, api_secret = secret_key).get_order(order_id)
        results = ret['result']
        if results:
            return results
        else:
            return ret['message']

    def get_orders(self, coin_type, currency, access_key=None, secret_key=None):
        if not access_key:
            access_key = self._access_key
        if not secret_key:
            secret_key = self._secret_key
        symbol = self.create_symbol(coin_type, currency)
        ret = Bittrex(api_key=access_key, api_secret=secret_key).get_order_history(symbol)
        results = ret['result']
        if results:
            return results
        else:
            return ret['message']

    def get_active_orders(self, coin_type, currency, access_key=None, secret_key=None):
        if not access_key:
            access_key = self._access_key
        if not secret_key:
            secret_key = self._secret_key
        symbol = self.create_symbol(coin_type, currency)
        ret = Bittrex(api_key = access_key, api_secret = secret_key).get_open_orders(symbol)
        results = ret['result']
        if results:
            return results
        else:
            return ret['message']
        
    def cancel_order(self, order_id, access_key=None, secret_key=None):
        if not access_key:
            access_key = self._access_key
        if not secret_key:
            secret_key = self._secret_key
        ret = Bittrex(api_key = access_key, api_secret = secret_key).cancel(order_id)
        success = ret['success']
        if success:
            return success
        else:
            return ret['message']

