from exchangeConnection.bittrex.Bittrexapi import Bittrex
from exchangeConnection.bittrex.BittrexService import BittrexServiceAPIKey
import pprint
# Key:9b9d8cce64734f97b5c5dc8d8a1d2d65 
# Secret:ce31363a8e72468c82c6cf43dc958fe0
#pprint.pprint(Bittrex(api_key = '9b9d8cce64734f97b5c5dc8d8a1d2d65', api_secret = 'ce31363a8e72468c82c6cf43dc958fe0').get_markets())
#pprint.pprint(Bittrex(api_key = '9b9d8cce64734f97b5c5dc8d8a1d2d65', api_secret = 'sse31363a8e72468c82c6cf43dc958fe0').get_ticker('BTC-LTC'))
## {'message': '', 'result': {'Ask': 0.01371799, 'Bid': 0.0137, 'Last': 0.01371799}, 'success': True}
#pprint.pprint(Bittrex(api_key = '9b9d8cce64734f97b5c5dc8d8a1d2d65', api_secret = 'ce31363a8e72468c82c6cf43dc958fe0').get_balance('BTC'))
#pprint.pprint(Bittrex(api_key = '9b9d8cce64734f97b5c5dc8d8a1d2d65', api_secret = 'ce31363a8e72468c82c6cf43dc958fe0').get_balances())
access_key = '9b9d8cce64734f97b5c5dc8d8a1d2d65'
secret_key = 'ce31363a8e72468c82c6cf43dc958fe0'
abcde=BittrexServiceAPIKey(access_key, secret_key)
#print(BittrexServiceAPIKey.get_trading_market(access_key, secret_key))
#print(abcde.get_ticker('btc', 'ltc'))
#print(abcde.get_depth( 'btc', 'ltc', 30))
#print(abcde.get_kline('btc', 'ltc', 30))
#print(abcde.get_trades( 'btc', 'ltc'))
#print(abcde.get_trading_market())
#print(BittrexServiceAPIKey.buy_limit(access_key, secret_key, 'btc', 'ltc',1.3,0.025))
#print(abcde.get_acct_infos())
#print(abcde.buy_limit('btc', 'ltc',1.3,0.025))
#print(abcde.sell_limit('btc', 'ltc',1.3,0.025))
#print(abcde.get_order_info('0cb4c4e4-bdc7-4e13-8c13-430e587d2cc1'))
#print(abcde.cancel_order('noid'))
#print(abcde.get_active_orders('btc', 'ltc'))
