#from exchangeConnection.kraken.krakenex.kraken.KrakenService import Kraken_Service

#ACCESS_KEY = '9Ne/dBH2tK7jCbDdAWze+FhoOGVvKpMZB5x2qMc4ZREMLfXz6CrUE0b9'
#SECRET_KEY = 'ik1VTAhOnChsAZQ4so2RLy+6WA+ULfKBfNbN8Pz1wywjWA7n6ib1CVgQQcdC1XeZ2hG4uRglS93v7UpKvAX+FA=='

#kraken = KrakenServiceAPIKey(ACCESS_KEY, SECRET_KEY)
#print (Kraken_Service('kraken.key'))
#print(KrakenServiceAPIKey.create_symbol('eth','usd'))
#print(chbtc.get_acct_info())
# print(chbtc.place_order('eth', 'cny', 1, 0.001, '1'))
#print(kraken.buy_limit('eth', 'usd', 1, 0.001))
from exchangeConnection.kraken.KrakenService import KrakenServiceAPIKey
#from exchangeConnection.kraken.KrakenService import Kraken_Service
#import krakenex
import pprint


# ACCESS_KEY = 'suSaiiy1lLmp5K1KWgey6CT8gS723uGIzwZGGZOT8H2IXFPdbvbu/8qm'
# SECRET_KEY = 'nMPM4kVhruywNfUEz/hpIAUmEnS+x61wOjjg/7zW+ZIsER+v0qHkTe6bcsyvjhhE2BCGiloZDbiUtPPqFSsafg=='
# abcdef=Kraken_Service()
# access_key=None
# secret_key=None
access_key = 'gLJphG27v+ZP+MY+VZFSWTzs9ab0kSVmrmJmUFOAFOZoBiabW1zXOx9t'
secret_key = 'lKcv0JkdvXUgGV68KO1OSuPD8Vb0+AQIQUbi1VzKyPUKcTJ9F1P7cdeD9tRMB3FMul4o9tQiNVUPG/RhIu5e0Q=='

#############  working #################################
abcdef=KrakenServiceAPIKey(access_key, secret_key)
#print(KrakenServiceAPIKey.create_symbol('dash','usd')) 
#print(abcdef.get_trades('etc', 'usd'))
#print(abcdef.get_depth('btc', 'usd', 10 ))
#print(abcdef.get_kline('btc', 'usd', 1, 1502969321, 10))
#print(abcdef.get_ticker('btc', 'usd'))

############    debug    ################################
# access_key='9Ne/dBH2tK7jCbDdAWze+FhoOGVvKpMZB5x2qMc4ZREMLfXz6CrUE0b9' 
# secret_key='ik1VTAhOnChsAZQ4so2RLy+6WA+ULfKBfNbN8Pz1wywjWA7n6ib1CVgQQcdC1XeZ2hG4uRglS93v7UpKvAX+FA=='

  
#abcdef=KrakenServiceAPIKey(access_key, secret_key)
print(abcdef.get_acct_info(access_key, secret_key))
#print(abcdef.get_order_info('btc', 'usd', id, access_key, secret_key)())
#print(abcdef.get_active_orders('btc', 'usd'))
#print(abcdef.get_orders('etc', 'usd'))
#print(abcdef.buy_limit('btc', 'usd', 3999, 1))
#print(abcdef.buy_limit('btc','usd',100 , 10, access_key=None, secret_key=None))
#print(abcdef.get_trades('etc', 'usd'))

#key=krakenex.API(key=access_key, secret=secret_key)
#pprint.pprint(key.query_private('Balance'))
# k=krakenex.API()
# k.load_key('kraken.key')
# pprint.pprint(k.query_private('Balance'))
#pprint.pprint(k.query_public('Depth', {'pair':'XXBTZUSD'}))
# with open('test.txt', 'r') as f:
#     key = f.readline().strip()
#     secret = f.readline().strip()
# print(key,secret)
#key.load_key('test.txt')
#pprint.pprint(key.query_private('OpenOrders'))