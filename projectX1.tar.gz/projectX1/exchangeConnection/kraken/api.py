# This file is part of krakenex.
#
# krakenex is free software: you can redistribute it and/or modify it
# under the terms of the GNU Lesser General Public License as published
# by the Free Software Foundation, either version 3 of the License, or
# (at your option) any later version.
#
# krakenex is distributed in the hope that it will be useful,
# but WITHOUT ANY WARRANTY; without even the implied warranty of
# MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE. See the GNU
# Lesser General Public License for more details.
#
# You should have received a copy of the GNU Lesser
# General Public LICENSE along with krakenex. If not, see
# <http://www.gnu.org/licenses/lgpl-3.0.txt>.


"""Kraken.com cryptocurrency Exchange API."""


import requests
import urllib.parse

# private query nonce
import time

# private query signing
import hashlib
import hmac
import base64

class API(object):
    def __init__(self, key='', secret=''):
        self.key = key
        self.secret = secret
        self.uri = 'https://api.kraken.com'
        self.apiversion = '0'
        return

    def query_public(self, method, req=None, conn=None):
        urlpath = '/' + self.apiversion + '/public/' + method

        if req is None:
            req = {}

        url = self.uri + urlpath
        ret = requests.get(url, req, timeout=10)
        return ret.json()

    def query_private(self, method, req=None):
        if req is None:
            req = {}

        urlpath = '/' + self.apiversion + '/private/' + method

        req['nonce'] = int(1000 * time.time())
        postdata = urllib.parse.urlencode(req)

        encoded = (str(req['nonce']) + postdata).encode()
        message = urlpath.encode() + hashlib.sha256(encoded).digest()

        signature = hmac.new(base64.b64decode(self.secret),
                             message, hashlib.sha512)
        sigdigest = base64.b64encode(signature.digest())

        headers = {
            'API-Key': self.key,
            'API-Sign': sigdigest.decode()
        }

        url = self.uri + urlpath
        ret = requests.post(url, req, headers=headers, timeout=30)
        return ret.json()
