#!/usr/bin/env python
# -*- coding: utf-8 -*-

from exchangeConnection.kraken.api import API
import utils.redisHelper as md
import pandas as pd
import datetime

time_map = {"1min": '1', "5min": '5', "15min": '15', "30min": '30', "60min": '60',
            "1day": '1440', "1week": '10080'}

def kraken_service(key_index=None, sub_key=None):
    if key_index is None:
        access_key, secret_key = "", ""
    else:
        acc = md.get_account("kraken", key_index)
        access_key = acc[sub_key].get("ACCESS_KEY")
        secret_key = acc[sub_key].get("SECRET_KEY")
    return KrakenServiceAPIKey(access_key=access_key, secret_key=secret_key)


class KrakenServiceAPIKey(object):
    def __init__(self, access_key=None, secret_key=None):
        self._api = API(key=access_key, secret=secret_key)
        self._asset_map, self._trade_map, self._disp_map = self._get_avail_assets()
        self._trade_pair_map, self._disp_pair_name = self._get_avail_pairs()

    def _check_key(self):
        if self._access_key is None:
            raise ValueError('Missing access_key.')
        if self._secret_key is None:
            raise ValueError('Missing secret_key.')
        return True

    def _get_avail_assets(self):
        assets = self._api.query_public("Assets")
        asset_list = assets.get('result')
        sys_mapping = {}
        trade_mapping = {}
        disp_mapping = {}
        for k, v in asset_list.items():
            if(k == 'BCH'):
                sys_mapping['bcc'] = {"trade" : k, "display" : v['altname']}
                trade_mapping[k] = {"sys" : 'bcc', "display" : v['altname']}
                disp_mapping[v['altname']] = {"trade" : k, "sys" : 'bcc'}
            elif(k == 'XXBT'):
                sys_mapping['btc'] = {"trade" : k, "display" : v['altname']}
                trade_mapping[k] = {"sys" : 'btc', "display" : v['altname']}
                disp_mapping[v['altname']] = {"trade" : k, "sys" : 'btc'}
            else:
                sys_mapping[v['altname'].lower()] = {"trade" : k, "display" : v['altname']}
                trade_mapping[k] = {'sys' : v['altname'].lower(), "display" : v['altname']}
                disp_mapping[v['altname']] = {"trade" : k, "sys" : v['altname'].lower()}
        return sys_mapping, trade_mapping, disp_mapping
    
    def _get_avail_pairs(self):
        assets = self._api.query_public("AssetPairs")
        asset_list = assets.get('result')
        trade_mapping = {}
        disp_mapping = {}
        for k, v in asset_list.items():
            trade_mapping[k] = v['altname']
            disp_mapping[v['altname']] = k
        return trade_mapping, disp_mapping
    
    def get_symbol(self, coin_type, s_type='display'):
        return self._asset_map[coin_type][s_type]
        
    def get_kline(self, coin_type, currency, freq=None, t_from=None, size=None):
        symbol = "%s%s" % (self.get_symbol(coin_type), self.get_symbol(currency))
        params = dict()
        params['pair'] = symbol
        if freq:
            params['interval'] = time_map[freq]
        if t_from:
            params['since'] = t_from
        if size:
            params['count'] = size
        ret = self._api.query_public('OHLC', params)
        results = ret.get('result')
        if results:
            kline = results.get(self._disp_pair_name[symbol])
            df = pd.DataFrame(kline, columns=['time', 'open', 'high', 'low', 'close', 'vwap', 'volume', 'count'])
            df['time'] = df['time'].apply(datetime.datetime.fromtimestamp)
            df = df.set_index('time')
            return df
        else:
            return {'error' : ret.get('error')}

    def get_ticker(self, coin_type, currency):
        symbol = "%s%s" % (self.get_symbol(coin_type), self.get_symbol(currency))
        params = dict()
        params['pair'] = symbol
        ret = self._api.query_public('Ticker', params)
        results = ret.get('result')
        if results:
            return results.get(self._disp_pair_name[symbol])
        else:
            return {'error' : ret.get('error')}

    def get_depth(self, coin_type, currency, size=None):
        symbol = "%s%s" % (self.get_symbol(coin_type), self.get_symbol(currency))
        params = dict()
        params['pair'] = symbol
        if size:
            params['count'] = size
        ret = self._api.query_public('Depth', params)
        results = ret.get('result')
        if results:
            depth = results.get(self._disp_pair_name[symbol])
            format_depth = {}
            format_depth['bids'] = [[float(x[0]), float(x[1])] for x in depth['bids']]
            format_depth['asks'] = [[float(x[0]), float(x[1])] for x in depth['asks']]
            return format_depth
        else:
            return {'error' : ret.get('error')}
    
    def get_active_orders(self, pair=None, side=None, status=['pending', 'open']):
        params = {}
        params['trades']= True
        ret = self._api.query_private('OpenOrders', params)
        results = ret.get('result')
        if results:
            ord_list = results.get('open')
            if(pair):
                if(isinstance(pair, str)):
                    pair = [pair]
                reformat_pair = ["%s%s" % (self.get_symbol(item.split('_')[0]), self.get_symbol(item.split('_')[1])) for item in pair]
            for k, v in ord_list.copy().items():
                if(v['status'] not in status):
                    ord_list.pop(k)
                    continue
                if(pair):
                    if(v['descr']['pair'] not in reformat_pair):
                        ord_list.pop(k)
                        continue
                if(side):
                    if(v['descr']['type'] != side):
                        ord_list.pop(k)
                        continue
                
            return ord_list
        else:
            return {'error' : ret.get('error')}
        
    def get_acct_info(self):
        """
        :params:
        :return:{'error': [], 'result': {'XETC': '0.4712357300'}}
        """
        ret = self._api.query_private('Balance')
        result = ret.get('result')
        if (result):
            reformat_ret = {}
            for key in result.keys():
                reformat_ret[self._trade_map[key]['sys']] = float(result[key])
            return reformat_ret
        else:
            return {'error' : ret.get('error')}

    def place_order(self, coin_type, currency, price, amount, trade_type, expiretm=0):
        symbol = "%s%s" % (self.get_symbol(coin_type), self.get_symbol(currency))
        params = {}
        params['ordertype'] = 'limit'
        params['price'] = price
        params['volume'] = amount
        params['type'] = trade_type
        params['pair'] = self._disp_pair_name[symbol]
        params['expiretm'] = '+%s' % expiretm
        return self._api.query_private('AddOrder',params)

    def buy_limit(self, coin_type, currency, price, amount, expiretm=0):
        trade_type = 'buy'
        ret = self.place_order(coin_type, currency, price, amount, trade_type, expiretm)
        results = ret.get('result')
        if results:
            return results
        else:
            return {'error' : ret.get('error')}
        
    def sell_limit(self, coin_type, currency, price, amount, expiretm=0):
        trade_type = 'sell'
        ret = self.place_order(coin_type, currency, price, amount, trade_type, expiretm)
        results = ret.get('result')
        if results:
            return results
        else:
            return {'error' : ret.get('error')}

    def get_order_info(self, order_id):
        params = {}
        params['id'] = order_id
        ret = self._api.query_private('QueryOrders', params)
        results = ret.get('result')
        if results:
            return results
        else:
            return {'error' : ret.get('error')}
        
    def cancel_order(self, order_id):
        params = dict()
        params['txid'] = order_id
        ret = self._api.query_private('CancelOrder', params)
        results = ret.get('result')
        if results:
            return results
        else:
            return {'error' : ret.get('error')}
        
    def get_latest_trade(self, coin_type, currency):
        symbol = "%s%s" % (self.get_symbol(coin_type), self.get_symbol(currency))
        params = dict()
        params['pair'] = self._disp_pair_name[symbol]
        ret = self._api.query_public('Trades', params)
        result = ret.get('result')
        if(result):
            trades = result.get(self._disp_pair_name[symbol])
            df = pd.DataFrame(trades, columns=['price', 'volume', 'time', 'side', 'type', 'miscellaneous'])
            df['time'] = df['time'].apply(datetime.datetime.fromtimestamp)
            df = df.set_index('time')
            return df
        else:
            return {'error' : ret.get('error')}