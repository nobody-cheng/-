## AuthenticatedClient.py
#
# For authenticated requests to the gdax exchange

import hmac
import hashlib
import time
import requests
import json


REST_TRADE_URL ="https://www.bitstamp.net/api/v2"

class AuthenticatedClient(object):
    def __init__(self, api_key=None, secret_key=None, username=None):
        self.api_key = api_key
        self.secret_key = secret_key
        self.username = username
        #super(AuthenticatedClient, self).__init__(api_url)
#        self.auth = GdaxAuth(api_key, secret_key, username )

    def get_balance(self, pair):
        """
        Returns dictionary::
            {u'btc_reserved': u'0',
             u'fee': u'0.5000',
             u'btc_available': u'2.30856098',
             u'usd_reserved': u'0',
             u'btc_balance': u'2.30856098',
             u'usd_balance': u'114.64',
             u'usd_available': u'114.64',
             ---If base and quote were specified:
             u'fee': u'',
             ---If base and quote were not specified:
             u'btcusd_fee': u'0.25',
             u'btceur_fee': u'0.25',
             u'eurusd_fee': u'0.20',
             }
            There could be reasons to set base and quote to None (or False),
            because the result then will contain the fees for all currency pairs
            For backwards compatibility this can not be the default however.
        """
        params = dict()
        url = REST_TRADE_URL + '/balance/' +pair+ "/"
        result = secret_request(params, url,self.username,self.api_key,self.secret_key)
        return result

    def get_account_history(self, pair, offset, limit):
        """
        Returns descending list of transactions. Every transaction (dictionary)
        contains::
            {u'usd': u'-39.25',
             u'datetime': u'2013-03-26 18:49:13',
             u'fee': u'0.20',
             u'btc': u'0.50000000',
             u'type': 2,
             u'id': 213642}
        Instead of the keys btc and usd, it can contain other currency codes
        """
        params = {
            'offset': offset,
            'limit': limit,
            'sort': 'desc'# if descending else 'asc',
        }
        url = REST_TRADE_URL + '/user_transactions/' + pair + "/"
        result = secret_request(params, url, self.username,self.api_key,self.secret_key)
        return result
    
    def open_orders(self, pair):
        """
        Returns JSON list of open orders. Each order is represented as a
        dictionary.
        """
        url = REST_TRADE_URL + '/open_orders/' + pair + "/"
        result = secret_request(url,self.username,self.api_key,self.secret_key)
        return result

    def order_status(self, order_id):
        """
        Returns dictionary.
        - status: 'Finished'
          or      'In Queue'
          or      'Open'
        - transactions: list of transactions
          Each transaction is a dictionary with the following keys:
              btc, usd, price, type, fee, datetime, tid
          or  btc, eur, ....
          or  eur, usd, ....
        """
        params = {'id': order_id}
        url = REST_TRADE_URL + '/order_status/' + "/"
        result = secret_request(params, url,self.username,self.api_key,self.secret_key)
        return result
    
    def cancel_order(self, order_id):
        """
        Cancel the order specified by order_id.
        Version 1 (default for backwards compatibility reasons):
        Returns True if order was successfully canceled, otherwise
        raise a BitstampError.
        Version 2:
        Returns dictionary of the canceled order, containing the keys:
        id, type, price, amount
        """
        params = {'id': order_id}
        url = REST_TRADE_URL + '/cancel_order/' + "/"
        result = secret_request(params, url,self.username,self.api_key,self.secret_key)
        return result
    
    def cancel_all_orders(self):
        """
        Cancel all open orders.
        Returns True if it was successful, otherwise raises a
        BitstampError.
        """
        params = dict()
        url = REST_TRADE_URL + "/cancel_all_orders/"
        result = secret_request(params, url,self.username,self.api_key,self.secret_key)
        return result

    def buy_limit_order(self, amount, price,pair):
        """
        Order to buy amount of bitcoins for specified price.
        """
        params = {'amount': amount, 'price': price}
        url = REST_TRADE_URL + '/buy/' + pair + "/"
        result = secret_request(params, url,self.username,self.api_key,self.secret_key)
        return result

    def sell_limit_order(self, amount, price, pair):
        """
        Order to buy amount of bitcoins for specified price.
        """
        params = {'amount': amount, 'price': price}
        url = REST_TRADE_URL + '/buy/' + pair + "/"
        result = secret_request(params, url,self.username,self.api_key,self.secret_key)
        return result



class BitstampError(Exception):
    pass

def http_request(url, params):
    #time.sleep(0.2)
    response = requests.post(url, data=params, timeout=30)
    # Check for error, raising an exception if appropriate.
    response.raise_for_status()
    try:
        json_response = response.json()
    except ValueError:
        json_response = None
    if isinstance(json_response, dict):
        error = json_response.get('error')
        if error:
            raise BitstampError(error)
        elif json_response.get('status') == "error":
            raise BitstampError(json_response.get('reason'))
    return response.json()
    
def create_sign(params,username,api_key,secret_key):
    nonce =int(1000 * (time.time()))
    message = str(nonce) + username + api_key
    signature = hmac.new(secret_key.encode('utf-8'),msg=message.encode('utf-8'),digestmod=hashlib.sha256).hexdigest().upper()
    #print(signature,nonce,api_key)
    params['signature']=signature
    params['nonce']=nonce
    params['key'] = api_key 
    return params


def secret_request(params,url,username,api_key,secret_key):
    if not params:
        params = dict()
    params = create_sign(params,username,api_key,secret_key)
    #data=urllib.parse.urlencode(params) 
    return http_request(url, params)
