#
# PublicClient.py
# For public requests to the GDAX exchange

import requests


class PublicClient(object):
    """GDAX public client API.

    All requests default to the `product_id` specified at object
    creation if not otherwise specified.

    Attributes:
        url (Optional[str]): API URL. Defaults to GDAX API.

    """

    def __init__(self, api_url='https://www.bitstamp.net/api/v2'):
        """Create GDAX API public client.

        Args:
            api_url (Optional[str]): API URL. Defaults to GDAX API.

        """
        self.url = api_url.rstrip('/')

    def get_order_book(self, pair):
        """Get a list of open orders for a product.

        The amount of detail shown can be customized with the `level`
        parameter:
        * 1: Only the best bid and ask
        * 2: Top 50 bids and asks (aggregated)
        * 3: Full order book (non aggregated)

        Level 1 and Level 2 are recommended for polling. For the most
        up-to-date data, consider using the websocket stream.

        **Caution**: Level 3 is only recommended for users wishing to
        maintain a full real-time order book using the websocket
        stream. Abuse of Level 3 via polling will cause your access to
        be limited or blocked.

        Args:
            product_id (str): Product
            level (Optional[int]): Order book level (1, 2, or 3).
                Default is 1.

        Returns:
            dict: Order book. Example for level 1::
                {
                    "sequence": "3",
                    "bids": [
                        [ price, size, num-orders ],
                    ],
                    "asks": [
                        [ price, size, num-orders ],
                    ]
                }

        """
        r = requests.get(self.url + '/order_book/'+pair+'/')
        # r.raise_for_status()
        return r.json()

    def get_product_ticker(self, pair):
        """Snapshot about the last trade (tick), best bid/ask and 24h volume.

        **Caution**: Polling is discouraged in favor of connecting via
        the websocket stream and listening for match messages.

        Args:
            product_id (str): Product

        Returns:
            dict: Ticker info. Example::
                {
                  "trade_id": 4729088,
                  "price": "333.99",
                  "size": "0.193",
                  "bid": "333.98",
                  "ask": "333.99",
                  "volume": "5957.11914015",
                  "time": "2015-11-14T20:46:03.511254Z"
                }

        """
        r = requests.get(self.url + '/ticker/'+pair+'/')
        # r.raise_for_status()
        return r.json()
    
    def get_product_hourly_ticker(self, pair):
        """
        Returns dictionary of the average ticker of the past hour.
        Args:
            pair (str): btcusd.........
 
        Returns:
            dict: Ticker info. Example::
                {
                  'high','last', 'timestamp',
                  'bid', 'vwap', 'volume','low', 'ask', 'open'
                }
        """
        r = requests.get(self.url + '/ticker_hour/'+pair+'/')
        # r.raise_for_status()
        return r.json()

    def get_product_trades(self, pair,time):
        """List the latest trades for a product.

        Args:
            product_id (str): Product

        Returns:
            list: Latest trades. Example::
                [{
                    "time": "2014-11-07T22:19:28.578544Z",
                    "trade_id": 74,
                    "price": "10.00000000",
                    "size": "0.01000000",
                    "side": "buy"
                }, {
                    "time": "2014-11-07T01:08:43.642366Z",
                    "trade_id": 73,
                    "price": "100.00000000",
                    "size": "0.01000000",
                    "side": "sell"
                }]

        """
        params = {'time': time}
        r = requests.get(self.url + '/transactions/'+pair+'/',params=params)
        # r.raise_for_status()
        return r.json()
