from exchangeConnection.bitstamp.private_key import AuthenticatedClient
from exchangeConnection.bitstamp.public_info import PublicClient


#import accountConfig
import utils.redisHelper as md


def bitstamp_service(key_index=None):
    if key_index is None:
        access_key, secret_key, username = "", "", ""
    else:
        acc = md.get_account("bitstamp", key_index)
        access_key = acc.get("ACCESS_KEY")
        secret_key = acc.get("SECRET_KEY")
        username = acc.get("USERNAME")
    return BitstampRestAPI(access_key=access_key, secret_key=secret_key,username=username)


class BitstampRestAPI(object):
    def __init__(self, access_key=None, secret_key=None,username=None):
        self._access_key = access_key
        self._secret_key = secret_key
        self._username = username

    def set_access_key(self, access_key):
        self._access_key = access_key

    def set_secret_key(self, secret_key):
        self._secret_key = secret_key
     
    def set_username(self, username):
        self._username = username
         
    def _check_key(self):
        if self._access_key is None:
            raise ValueError('Missing access_key.')
        if self._secret_key is None:
            raise ValueError('Missing secret_key.')
        if self._username is None:
            raise ValueError('Missing username')
        return True

    @classmethod
    def create_symbol(cls, coin_type, currency):
        symbol = coin_type+currency
        return symbol

    @classmethod
    def get_hourly_ticker(cls, coin_type, currency):
        symbol = cls.create_symbol(coin_type, currency)
        return PublicClient().get_product_hourly_ticker(symbol)

    @classmethod
    def get_ticker(cls, coin_type, currency):
        symbol = cls.create_symbol(coin_type, currency)
        return PublicClient().get_product_ticker(symbol)

    @classmethod
    def get_depth(cls, coin_type, currency):
        symbol = cls.create_symbol(coin_type, currency)
        return PublicClient().get_order_book(symbol)

    @classmethod
    def get_trades(cls, coin_type, currency, t_from=None):
        symbol = cls.create_symbol(coin_type, currency)
        return PublicClient().get_product_trades(symbol, t_from)

    def get_acct_info(self,coin_type, currency, access_key=None, secret_key=None,username=None):
        if not access_key:
            access_key = self._access_key
        if not secret_key:
            secret_key = self._secret_key
        if not username:
            username = self._username
        symbol = self.create_symbol(coin_type, currency)
        return AuthenticatedClient(access_key, secret_key, username).get_balance(symbol)

    def buy_limit(self, coin_type, currency, price, amount, access_key=None, secret_key=None,username=None):
        if not access_key:
            access_key = self._access_key
        if not secret_key:
            secret_key = self._secret_key
        if not username:
            username = self._username
        symbol = self.create_symbol(coin_type, currency)
        return AuthenticatedClient(access_key,secret_key,username).buy_limit_order(amount, price, symbol)

    def sell_limit(self, coin_type, currency, price, amount, access_key=None, secret_key=None,username=None):
        if not access_key:
            access_key = self._access_key
        if not secret_key:
            secret_key = self._secret_key
        if not username:
            username = self._username
        symbol = self.create_symbol(coin_type, currency)
        return AuthenticatedClient(access_key,secret_key,username).sell_limit_order(amount, price, symbol)

    def get_order_info(self, order_id, access_key=None, secret_key=None, username=None):
        if not access_key:
            access_key = self._access_key
        if not secret_key:
            secret_key = self._secret_key
        if not username:
            username = self._username
        return AuthenticatedClient(access_key,secret_key,username).order_status(order_id)

    def get_orders(self, coin_type, currency, access_key=None, secret_key=None, username=None):
        if not access_key:
            access_key = self._access_key
        if not secret_key:
            secret_key = self._secret_key
        if not username:
            username = self._username
        symbol = self.create_symbol(coin_type, currency)
        return AuthenticatedClient(access_key,secret_key,username).get_account_history(symbol, offset=0, limit=100)

    def get_active_orders(self, coin_type, currency, access_key=None, secret_key=None, username=None):
        if not access_key:
            access_key = self._access_key
        if not secret_key:
            secret_key = self._secret_key
        if not username:
            username = self._username
        symbol = self.create_symbol(coin_type, currency)
        return AuthenticatedClient(access_key,secret_key,username).open_orders(symbol)

    def cancel_order(self, order_id, access_key=None, secret_key=None, username=None):
        if not access_key:
            access_key = self._access_key
        if not secret_key:
            secret_key = self.set_secret_key
        if not username:
            username = self._username
        return AuthenticatedClient(access_key,secret_key,username).cancel_order(order_id)
    
    def cancel_all_order(self, access_key=None, secret_key=None, username=None):
        if not access_key:
            access_key = self._access_key
        if not secret_key:
            secret_key = self.set_secret_key
        if not username:
            username = self._username
        return AuthenticatedClient(access_key,secret_key,username).cancel_order()
