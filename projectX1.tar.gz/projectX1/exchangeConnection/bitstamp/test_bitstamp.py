# from exchangeConnection.Bitstamp.public_info import PublicClient
# from exchangeConnection.bitstamp.from_web import Trading
# from exchangeConnection.bitstamp.private_key import AuthenticatedClient
from exchangeConnection.bitstamp.BitstampService import BitstampRestAPI

# print(PublicClient().get_product_ticker('btcusd'))
key = 'tY1vtNdYxO1Xq8F7IusSJmIhvSzHUHIH'
secret = 'ytTs33s5jbYIMXAtfzkXdsn6Jno7nlzA'
username='ihex8379'
# k=AuthenticatedClient(key, secret, username)

# print(k.get_balance('btc','usd'))
# print(k.get_account_history( 0,100,'btc','usd'))
# print(k.buy_limit_order(10, 2300, 'btc', 'usd'))

#print(Trading(username='ihex8379', key='tY1vtNdYxO1Xq8F7IusSJmIhvSzHUHIH', secret='ytTs33s5jbYIMXAtfzkXdsn6Jno7nlzA').account_balance())

#print(BitstampRestAPI().get_hourly_ticker('btc', 'usd'))
#print(BitstampRestAPI(key,secret,username).get_acct_info('btc', 'usd'))
#print(BitstampRestAPI(key,secret,username).sell_limit('btc', 'usd', 4800.0, 1))