# -*- coding: utf-8 -*-

# 用于访问OKCOIN 期货REST API
from exchangeConnection.okcoin.httpMD5Util import buildMySign, httpGet, httpPost
import utils.redisHelper as md
import pandas as pd
import datetime


SERVICE_API = "https://www.okex.com"
future_url = "https://www.okex.com"


def get_okex_spot(acc_id=None):
    if acc_id is None:
        return OkexSpot(SERVICE_API, "", "")
    else:
        acc = md.get_account("okex", acc_id)
        return OkexSpot(SERVICE_API, acc.get("ACCESS_KEY"), acc.get("SECRET_KEY"))


# 期货API
def get_okex_future(acc_id=None):
    if acc_id is None:
        return OkexFuture(SERVICE_API, "", "")
    else:
        acc = md.get_account("okex", acc_id)
        return OkexFuture(future_url, acc.get("ACCESS_KEY"), acc.get("SECRET_KEY"))


convert_dict = {"bcc": "bch"}


def convert_symbol(symbol):
    a, b = symbol.split("_")
    if convert_dict.get(a):
        a = convert_dict.get(a)
    if convert_dict.get(b):
        b = convert_dict.get(b)
    return "_".join((a, b))

class OkexSpot:
    def __init__(self, url, apikey, secretkey):
        self.__url = url
        self.__apikey = apikey
        self.__secretkey = secretkey

    # 获取OKCOIN现货行情信息
    def ticker(self, symbol):
        TICKER_RESOURCE = "/api/v1/ticker.do"
        params = 'symbol=%(symbol)s' % {'symbol': convert_symbol(symbol)}
        return httpGet(self.__url, TICKER_RESOURCE, params)

    # 获取OKCOIN现货市场深度信息
    def depth(self, symbol, size=1):
        DEPTH_RESOURCE = "/api/v1/depth.do"
        params = 'symbol=%(symbol)s&size=%(size)d' % {'symbol': convert_symbol(symbol), 'size': size}
        return httpGet(self.__url, DEPTH_RESOURCE, params)

    # 获取OKCOIN现货历史交易信息
    def trades(self, symbol, since=None):
        """
        获取OKEx现货交易信息(600条)
        :param symbol:ltc_btc eth_btc etc_btc bcc_btc
        :param since: tid:交易记录ID（返回数据不包括当前tid值,最多返回600条数据）
        :return:
        """
        TRADES_RESOURCE = "/api/v1/trades.do"
        params = 'symbol=%(symbol)s' % {'symbol': convert_symbol(symbol)}
        if since:
            params += "&since={0}".format(since)
        return httpGet(self.__url, TRADES_RESOURCE, params)

    def get_last_trades(self, symbol):
        ret = self.trades(convert_symbol(symbol))
        db_list = []
        db_list.extend(ret)
        df = pd.DataFrame(db_list)
        df['ts'] = (df['date_ms'] / 1000).apply(datetime.datetime.fromtimestamp)
        df = df.set_index('ts')
        return df

    def kline(self, symbol, frequency, size=None, since=None):
        """
        获取OKEx现货K线数据
        :param symbol:      ltc_btc eth_btc etc_btc bcc_btc
        :param frequency:   1min : 1分钟
                            3min : 3分钟
                            5min : 5分钟
                            15min : 15分钟
                            30min : 30分钟
                            1day : 1日
                            3day : 3日
                            1week : 1周
                            1hour : 1小时
                            2hour : 2小时
                            4hour : 4小时
                            6hour : 6小时
                            12hour : 12小时
        :param size:        指定获取数据的条数
        :param since:       时间戳，返回该时间戳以后的数据(例如1417536000000)
        :return:
        """
        KLINE_RESOURCE = "/api/v1/kline.do"
        params = 'symbol={0}&type={1}'.format(convert_symbol(symbol), frequency)
        if size:
            params += "&size={0}".format(size)
        if since:
            params += "&since={0}".format(since)
        return httpGet(self.__url, KLINE_RESOURCE, params)

    def get_klines(self, symbol, freq, length=300):
        """
        支持{1min, 5min, 15min, 30min, 60min, 1day, 1mon, 1week }频率的信息
        返回一个 pandas.DataFrame 对象，结构为
                    open    high    low    close    volume
        bar_time

        :param symbol:
        :param freq:
        :param length:
        :return:
        """
        prices = pd.DataFrame(self.kline(symbol, freq, size=length),
                              columns=["ts", "open", "high", "low", "close", "volume"])
        prices = prices.set_index('ts')
        return prices

    # 获取用户现货账户信息
    def userInfo(self):
        USERINFO_RESOURCE = "/api/v1/userinfo.do"
        params = {}
        params['api_key'] = self.__apikey
        params['sign'] = buildMySign(params, self.__secretkey)
        return httpPost(self.__url, USERINFO_RESOURCE, params)

    # 现货交易
    def trade(self, symbol, tradeType, price='', amount=''):
        TRADE_RESOURCE = "/api/v1/trade.do"
        params = {
            'api_key': self.__apikey,
            'symbol': convert_symbol(symbol),
            'type': tradeType
        }
        if price:
            params['price'] = price
        if amount:
            params['amount'] = amount

        params['sign'] = buildMySign(params, self.__secretkey)
        return httpPost(self.__url, TRADE_RESOURCE, params)

    def batchTrade(self, symbol, tradeType, orders_data):
        """
        现货批量下单
        :param symbol:
        :param tradeType:  买卖类型： 限价单（buy/sell）
        :param orders_data:   最大下单量为5， price和amount参数参考trade接口中的说明，最终买卖类型由orders_data 中type 为准，
                              如orders_data不设定type 则由上面type设置为准。
        :return:
        """
        BATCH_TRADE_RESOURCE = "/api/v1/batch_trade.do"
        params = {
            'api_key': self.__apikey,
            'symbol': convert_symbol(symbol),
            'type': tradeType,
            'orders_data': orders_data
        }
        params['sign'] = buildMySign(params, self.__secretkey)
        return httpPost(self.__url, BATCH_TRADE_RESOURCE, params)

    def cancelOrder(self, symbol, order_id):
        """
        现货取消订单
        :param symbol:
        :param order_id:     订单ID(多个订单ID中间以","分隔,一次最多允许撤消3个订单)
        :return:
        """
        CANCEL_ORDER_RESOURCE = "/api/v1/cancel_order.do"
        params = {
            'api_key': self.__apikey,
            'symbol': convert_symbol(symbol),
            'order_id': order_id
        }
        params['sign'] = buildMySign(params, self.__secretkey)
        return httpPost(self.__url, CANCEL_ORDER_RESOURCE, params)

    def orderInfo(self, symbol, order_id):
        """
        现货订单信息查询
        :param symbol:
        :param order_id:    订单ID -1:未完成订单，否则查询相应订单号的订单 
        :return:
        """
        ORDER_INFO_RESOURCE = "/api/v1/order_info.do"
        params = {
            'api_key': self.__apikey,
            'symbol': convert_symbol(symbol),
            'order_id': order_id
        }
        params['sign'] = buildMySign(params, self.__secretkey)
        return httpPost(self.__url, ORDER_INFO_RESOURCE, params)

    def ordersInfo(self, symbol, order_id, trade_type):
        """
        现货批量订单信息查询
        :param symbol: 
        :param order_id:    订单ID(多个订单ID中间以","分隔,一次最多允许查询50个订单)
        :param trade_type:  查询类型 0:未完成的订单 1:已经完成的订单
        :return: 
        """
        ORDERS_INFO_RESOURCE = "/api/v1/orders_info.do"
        params = {
            'api_key': self.__apikey,
            'symbol': convert_symbol(symbol),
            'order_id': order_id,
            'type': trade_type
        }
        params['sign'] = buildMySign(params, self.__secretkey)
        return httpPost(self.__url, ORDERS_INFO_RESOURCE, params)

    def orderHistory(self, symbol, status, current_page, page_length):
        """
        现货获得历史订单信息
        :param symbol:
        :param status:        查询状态 0：未完成的订单 1：已经完成的订单 （最近两天的数据） 
        :param current_page:  当前页数 
        :param page_length:   每页数据条数，最多不超过200
        :return:
        """
        ORDER_HISTORY_RESOURCE = "/api/v1/order_history.do"
        params = {
            'api_key': self.__apikey,
            'symbol': convert_symbol(symbol),
            'status': status,
            'current_page': current_page,
            'page_length': page_length
        }
        params['sign'] = buildMySign(params, self.__secretkey)
        return httpPost(self.__url, ORDER_HISTORY_RESOURCE, params)

    def account_records(self, symbol, records_type, current_page, page_length):
        """
        获取用户提现/充值记录
        :param symbol:
        :param records_type:    0：充值 1 ：提现
        :param current_page:
        :param page_length:     每页数据条数，最多不超过50条
        :return:
        """
        ORDER_HISTORY_RESOURCE = "/api/v1/account_records.do"
        params = {
            'api_key': self.__apikey,
            'symbol': convert_symbol(symbol),
            'type': records_type,
            'current_page': current_page,
            'page_length': page_length
        }
        params['sign'] = buildMySign(params, self.__secretkey)
        return httpPost(self.__url, ORDER_HISTORY_RESOURCE, params)


class OkexFuture:
    def __init__(self, url, apikey, secretkey):
        self.__url = url
        self.__apikey = apikey
        self.__secretkey = secretkey

    # OKCOIN期货行情信息
    def future_ticker(self, symbol, contract_type):
        FUTURE_TICKER_RESOURCE = "/api/v1/future_ticker.do"
        params = ''
        if symbol:
            params += '&symbol=' + symbol if params else 'symbol=' + symbol
        if contract_type:
            params += '&contract_type=' + contract_type if params else 'contract_type=' + symbol
        return httpGet(self.__url, FUTURE_TICKER_RESOURCE, params)

    # OKCoin期货市场深度信息
    def future_depth(self, symbol, contract_type, size, merge=None):
        FUTURE_DEPTH_RESOURCE = "/api/v1/future_depth.do"
        params = ''
        if symbol:
            params += '&symbol=' + symbol if params else 'symbol=' + symbol
        if contract_type:
            params += '&contract_type=' + contract_type if params else 'contract_type=' + symbol
        if size:
            params += '&size=' + str(size) if params else 'size=' + str(size)
        if merge:
            params += '&merge=' + merge
        return httpGet(self.__url, FUTURE_DEPTH_RESOURCE, params)

    # OKCoin期货交易记录信息
    def future_trades(self, symbol, contract_type):
        FUTURE_TRADES_RESOURCE = "/api/v1/future_trades.do"
        params = ''
        if symbol:
            params += '&symbol=' + symbol if params else 'symbol=' + symbol
        if contract_type:
            params += '&contract_type=' + contract_type if params else 'contract_type=' + symbol
        return httpGet(self.__url, FUTURE_TRADES_RESOURCE, params)

    # OKCoin期货指数
    def future_index(self, symbol):
        FUTURE_INDEX = "/api/v1/future_index.do"
        params = 'symbol=' + symbol
        return httpGet(self.__url, FUTURE_INDEX, params)

    # 获取美元人民币汇率
    def exchange_rate(self):
        EXCHANGE_RATE = "/api/v1/exchange_rate.do"
        return httpGet(self.__url, EXCHANGE_RATE, '')

    # 获取预估交割价
    def future_estimated_price(self, symbol):
        FUTURE_ESTIMATED_PRICE = "/api/v1/future_estimated_price.do"
        params = 'symbol=' + symbol
        return httpGet(self.__url, FUTURE_ESTIMATED_PRICE, params)

    def future_kline(self, symbol, kline_type, contract_type, size=None, since=None):
        """
        获取虚拟合约的K线数据
        :param symbol:              btc_usd：比特币， ltc_usd：莱特币
        :param kline_type:          1min : 1分钟
                                    3min : 3分钟
                                    5min : 5分钟
                                    15min : 15分钟
                                    30min : 30分钟
                                    1day : 1日
                                    3day : 3日
                                    1week : 1周
                                    1hour : 1小时
                                    2hour : 2小时
                                    4hour : 4小时
                                    6hour : 6小时
                                    12hour : 12小时
        :param contract_type:
        :param size:
        :param since:
        :return:
        """
        FUTURE_KLINE = "/api/v1/future_estimated_price.do"
        params = 'symbol={0}&type={1}&contract_type={2}'.format(symbol, kline_type, contract_type)
        if size:
            params += "&size={0}".format(size)
        if since:
            params += "&since={0}".format(since)
        return httpGet(self.__url, FUTURE_KLINE, params)

    def future_hold_amount(self, symbol, contract_type):
        """
        获取当前可用合约总持仓量
        :param symbol:
        :param contract_type:  合约类型。this_week：当周；next_week：下周；quarter：季度
        :return:
        """
        FUTURE_HOLD_AMOUNT = "/api/v1/future_hold_amount.do"
        params = 'symbol={0}&contract_type={1}'.format(symbol, contract_type)
        return httpGet(self.__url, FUTURE_HOLD_AMOUNT, params)

    def future_price_limit(self, symbol, contract_type):
        """
        获取合约最高买价和最低卖价
        :param symbol:
        :param contract_type:  合约类型。this_week：当周；next_week：下周；quarter：季度
        :return:
        """
        FUTURE_PRICE_LIMIT = "/api/v1/future_price_limit.do"
        params = 'symbol={0}&contract_type={1}'.format(symbol, contract_type)
        return httpGet(self.__url, FUTURE_PRICE_LIMIT, params)

    # 期货全仓账户信息
    def future_userinfo(self):
        FUTURE_USERINFO = "/api/v1/future_userinfo.do"
        params = {}
        params['api_key'] = self.__apikey
        params['sign'] = buildMySign(params, self.__secretkey)
        return httpPost(self.__url, FUTURE_USERINFO, params)

    # 期货全仓持仓信息
    def future_position(self, symbol, contractType):
        FUTURE_POSITION = "/api/v1/future_position.do"
        params = {
            'api_key': self.__apikey,
            'symbol': symbol,
            'contract_type': contractType
        }
        params['sign'] = buildMySign(params, self.__secretkey)
        return httpPost(self.__url, FUTURE_POSITION, params)

    # 期货下单
    def future_trade(self, symbol, contractType, price='', amount='', tradeType='', matchPrice='', leverRate=''):
        """

        :param symbol:
        :param contractType:
        :param price:
        :param amount:
        :param tradeType:   1:开多   2:开空   3:平多   4:平空
        :param matchPrice:  是否为对手价 0:不是    1:是   ,当取值为1时,price无效
        :param leverRate:   杠杆倍数 value:10\20 默认10
        :return:
        """
        FUTURE_TRADE = "/api/v1/future_trade.do"
        params = {
            'api_key': self.__apikey,
            'symbol': symbol,
            'contract_type': contractType,
            'amount': amount,
            'type': tradeType,
            'match_price': matchPrice,
            'lever_rate': leverRate
        }
        if price:
            params['price'] = price
        params['sign'] = buildMySign(params, self.__secretkey)
        return httpPost(self.__url, FUTURE_TRADE, params)

    def future_trades_history(self, symbol, date, since):
        """
        获取OKEX合约交易历史（非个人）
        :param symbol:
        :param date:    合约交割时间，格式yyyy-MM-dd
        :param since:   交易Id起始位置
        :return:
        """
        FUTURE_TRADES_HISTORY="/api/v1/future_trades_history.do?"
        params = {
            'api_key': self.__apikey,
            'symbol': symbol,
            "date": date,
            "since": since,
        }
        params['sign'] = buildMySign(params, self.__secretkey)
        return httpPost(self.__url, FUTURE_TRADES_HISTORY, params)

    # 期货批量下单
    def future_batchTrade(self, symbol, contractType, orders_data, leverRate):
        """

        :param symbol:
        :param contractType:
        :param orders_data: JSON类型的字符串 例：[{price:5,amount:2,type:1,match_price:1},{price:2,amount:3,type:1,match_price:1}]
                            最大下单量为5，price,amount,type,match_price参数参考future_trade接口中的说明
        :param leverRate:   杠杆倍数 value:10\20 默认10
        :return:
        """
        FUTURE_BATCH_TRADE = "/api/v1/future_batch_trade.do"
        params = {
            'api_key': self.__apikey,
            'symbol': symbol,
            'contract_type': contractType,
            'orders_data': orders_data,
            'lever_rate': leverRate
        }
        params['sign'] = buildMySign(params, self.__secretkey)
        return httpPost(self.__url, FUTURE_BATCH_TRADE, params)

    def future_cancel(self, symbol, contractType, orderId):
        """
        期货取消订单
        :param symbol:
        :param contractType: 合约类型: this_week:当周   next_week:下周   quarter:季度
        :param orderId:      订单ID(多个订单ID中间以","分隔,一次最多允许撤消3个订单)
        :return:
        """
        FUTURE_CANCEL = "/api/v1/future_cancel.do?"
        params = {
            'api_key': self.__apikey,
            'symbol': symbol,
            'contract_type': contractType,
            'order_id': orderId
        }
        params['sign'] = buildMySign(params, self.__secretkey)
        return httpPost(self.__url, FUTURE_CANCEL, params)

    # 期货获取订单信息
    def future_order_info(self, symbol, contract_type, orderId, status=None, current_page=None, page_length=None):
        """
        期货获取订单信息
        :param symbol:
        :param contract_type:
        :param orderId:    订单ID -1:查询指定状态的订单，否则查询相应订单号的订单
        :param status:     查询状态 1:未完成的订单 2:已经完成的订单
        :param current_page:
        :param page_length:
        :return:
        """
        FUTURE_ORDERINFO = "/api/v1/future_order_info.do?"
        params = {
            'api_key': self.__apikey,
            'symbol': symbol,
            'contract_type': contract_type,
            'order_id': orderId,
        }
        if status:
            params["status"] = str(status)
        if current_page:
            params["current_page"] = str(current_page)
        if page_length:
            params["page_length"] = str(page_length)
        params['sign'] = buildMySign(params, self.__secretkey)
        return httpPost(self.__url, FUTURE_ORDERINFO, params)

    def future_orders_info(self, symbol, contract_type, order_id):
        """
        批量获取合约订单信息
        :param symbol: 
        :param contract_type: 
        :param order_id:        订单ID(多个订单ID中间以","分隔,一次最多允许查询50个订单)
        :return: 
        """
        FUTURE_ORDERINFO = "/api/v1/future_order_info.do?"
        params = {
            'api_key': self.__apikey,
            'symbol': symbol,
            'contract_type': contract_type,
            'order_id': order_id,
        }
        params['sign'] = buildMySign(params, self.__secretkey)
        return httpPost(self.__url, FUTURE_ORDERINFO, params)

    # 期货逐仓账户信息
    def future_userinfo_4fix(self):
        FUTURE_INFO_4FIX = "/api/v1/future_userinfo_4fix.do"
        params = {'api_key': self.__apikey}
        params['sign'] = buildMySign(params, self.__secretkey)
        return httpPost(self.__url, FUTURE_INFO_4FIX, params)

    def future_position_4fix(self, symbol, contract_type, type1):
        """
        期货逐仓持仓信息
        :param symbol:
        :param contract_type:
        :param type1:             默认返回10倍杠杆持仓 type=1 返回全部持仓数据
        :return:
        """
        FUTURE_POSITION_4FIX = "/api/v1/future_position_4fix.do"
        params = {
            'api_key': self.__apikey,
            'symbol': symbol,
            'contract_type': contract_type,
            'type': type1
        }
        params['sign'] = buildMySign(params, self.__secretkey)
        return httpPost(self.__url, FUTURE_POSITION_4FIX, params)

    def future_explosive(self, symbol, contract_type, status, current_page, page_number, page_length):
        """
        获取合约爆仓单
        :param symbol:
        :param contract_type:
        :param status:          状态 0：最近7天未成交 1:最近7天已成交
        :param current_page:    当前页数索引值
        :param page_number:     当前页数(使用page_number时current_page失效，current_page无需传)
        :param page_length:     每页获取条数，最多不超过50
        :return:
        """
        FUTURE_EXPLOSIVE = "/api/v1/future_explosive.do"
        params = {
            'api_key': self.__apikey,
            'symbol': symbol,
            'contract_type': contract_type,
            'status': status,
        }
        if current_page:
            params["current_page"] = current_page
        if page_number:
            params["page_number"] = page_number
        if page_length:
            params["page_length"] = page_length
        params['sign'] = buildMySign(params, self.__secretkey)
        return httpPost(self.__url, FUTURE_EXPLOSIVE, params)

    def withdraw(self, symbol, chargefee, trade_pwd, withdraw_address, withdraw_amount, target):
        """
        提币BTC/LTC
        :param symbol:
        :param chargefee:           网络手续费 >=0
                                    BTC默认范围 [0.002，0.005]
                                    LTC默认范围 [0.001，0.2]
                                    手续费越高，网络确认越快，OKCoin内部提币设置0
        :param trade_pwd:           交易密码
        :param withdraw_address:    认证的地址、邮箱 或手机号码
        :param withdraw_amount:     提币数量 BTC>=0.01 LTC>=0.1
        :param target:              地址类型 okcn：国内站 okcom：国际站 okex：OKEX address：外部地址
        :return:
        """
        WITHDRAW = "/api/v1/withdraw.do"
        params = {
            'api_key': self.__apikey,
            'symbol': symbol,
            'chargefee': chargefee,
            'trade_pwd': trade_pwd,
            'withdraw_address': withdraw_address,
            'withdraw_amount': withdraw_amount,
            'target': target,
        }
        params['sign'] = buildMySign(params, self.__secretkey)
        return httpPost(self.__url, WITHDRAW, params)

    def cancel_withdraw(self, symbol, withdraw_id):
        """
        取消提币BTC/LTC
        :param symbol:
        :param withdraw_id:   提币申请Id
        :return:
        """
        CANCEL_WITHDRAW = "/api/v1/cancel_withdraw.do"
        params = {
            'api_key': self.__apikey,
            'symbol': symbol,
            'withdraw_id': withdraw_id,
        }
        params['sign'] = buildMySign(params, self.__secretkey)
        return httpPost(self.__url, CANCEL_WITHDRAW, params)

    def withdraw_info(self, symbol, withdraw_id):
        """
        查询提币BTC/LTC信息
        :param symbol:
        :param withdraw_id:   提币申请Id
        :return:
        """
        WITHDRAW_INFO = "/api/v1/withdraw_info.do"
        params = {
            'api_key': self.__apikey,
            'symbol': symbol,
            'withdraw_id': withdraw_id,
        }
        params['sign'] = buildMySign(params, self.__secretkey)
        return httpPost(self.__url, WITHDRAW_INFO, params)

    def future_devolve(self, symbol, type1, amount):
        """
         个人账户资金划转
        :param symbol:
        :param type1:     划转类型。1：现货转合约 2：合约转现货
        :param amount:
        :return:
        """
        FUTURE_DEVOLVE = "/api/v1/future_devolve.do"
        params = {
            'api_key': self.__apikey,
            'symbol': symbol,
            'type': type1,
            'amount': amount,
        }
        params['sign'] = buildMySign(params, self.__secretkey)
        return httpPost(self.__url, FUTURE_DEVOLVE, params)

