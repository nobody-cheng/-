import json
import base64
import hmac
import hashlib
from functools import wraps
import requests
import utils.redisHelper as rh
import logging
log = logging.getLogger(__name__)
import time


def bitfinex_service(key_index=None, sub_key=None, proxy=False):
    if key_index is None:
        access_key, secret_key = "", ""
    else:
        acc = rh.get_account("bitfinex", key_index)
        access_key = acc[sub_key].get("ACCESS_KEY")
        secret_key = acc[sub_key].get("SECRET_KEY")
    return BitfinexREST(key=access_key, secret=secret_key, proxy=proxy)


convert_dict = {"bcc": "bch", "dash": "dsh"}


def convert_symbol(symbol):
    a, b = symbol.split("_")
    if convert_dict.get(a):
        a = convert_dict.get(a)
    if convert_dict.get(b):
        b = convert_dict.get(b)
    return "_".join((a, b))


class BitfinexREST:
    def __init__(self, key='', secret='', api_version='v1', timeout=5, proxy=False):
        url = 'https://api.bitfinex.com'
        self.key = key
        self.secret = secret
        self.url = url
        self.version = api_version if api_version else ''
        self.timeout = timeout
        self.proxy = proxy
        self.proxies = {"http": "http://squid-proxy.aws-jp1.huobiidc.com:9527",
                        "https": "squid-proxy.aws-jp1.huobiidc.com:9527",}

    @staticmethod
    def create_symbol(symbol):
        return convert_symbol(symbol).replace("_", "")

    def public_query(self, endpoint, **kwargs):
        return self.query('GET', endpoint, **kwargs)

    def private_query(self, endpoint, **kwargs):
        return self.query('POST', endpoint, authenticate=True, **kwargs)

    """
    BitEx Standardized Methods
    """

    def order_book(self, pair, **kwargs):
        return self.public_query('book/%s' % pair, params=kwargs)


    def ticker(self, pair, **kwargs):
        return self.public_query('pubticker/%s' % pair, params=kwargs)


    def trades(self, pair, **kwargs):
        return self.public_query('trades/%s' % pair, params=kwargs)

    def _place_order(self, pair, size, price, side, replace, **kwargs):
        q = {'symbol': pair, 'amount': size, 'price': price, 'side': side,
             'type': 'exchange limit'}
        q.update(kwargs)
        if replace:
            return self.private_query('order/cancel/replace', params=q)
        else:
            return self.private_query('order/new', params=q)

    def bid(self, pair, price, size, replace=False, **kwargs):
        return self._place_order(pair, size, price, 'buy', replace=replace,
                                 **kwargs)

    def ask(self, pair, price, size, replace=False, **kwargs):
        return self._place_order(pair, str(size), str(price), 'sell',
                                 replace=replace, **kwargs)

    def cancel_order(self, order_id, all=False, **kwargs):
        q = {'order_id': int(order_id)}
        q.update(kwargs)
        if not all:
            return self.private_query('order/cancel', params=q)
        else:
            endpoint = 'order/cancel/all'
            return self.private_query(endpoint)

    def order(self, order_id, **kwargs):
        q = {'order_id': order_id}
        q.update(kwargs)
        return self.private_query('order/status', params=q)

    def balance(self, **kwargs):
        return self.private_query('balances', params=kwargs)

    def withdraw(self, size, tar_addr, **kwargs):
        q = {'withdraw_type': kwargs.pop('withdraw_type'),
             'walletselected': kwargs.pop('walletselected'),
             'amount': size, 'address': tar_addr}
        q.update(kwargs)
        return self.private_query('withdraw', params=q)

    def deposit_address(self, **kwargs):
        q = {}
        q.update(kwargs)
        return self.private_query('deposit/new', params=kwargs)

    """
    Exchange Specific Methods
    """

    def statistics(self, pair):
        return self.public_query('stats/%s' % pair)

    def funding_book(self, currency, **kwargs):
        return self.public_query('lendbook/%s' % currency, params=kwargs)

    def lends(self, currency, **kwargs):
        return self.public_query('lends/%s' % currency, params=kwargs)

    def pairs(self, details=False):
        if details:
            return self.public_query('symbols_details')
        else:
            return self.public_query('symbols')

    def fees(self):
        return self.private_query('account_infos')

    def orders(self):
        return self.private_query('orders')

    def balance_history(self, currency, **kwargs):
        q = {'currency': currency}
        q.update(kwargs)
        return self.private_query('history/movements', params=q)

    def trade_history(self, pair, since, **kwargs):
        q = {'symbol': pair, 'timestamp': since}
        q.update(kwargs)
        return self.private_query('mytrades', params=q)

    def positions(self):
        return self.private_query('positions')

    def credits(self):
        return self.private_query('credits')

    def nonce(self):
        """
        Creates a Nonce value for signature generation
        :return:
        """
        return str(int(1000 * time.time()))

    def sign(self, url, endpoint, endpoint_path, method_verb, *args, **kwargs):
        try:
            req = kwargs['params']
        except KeyError:
            req = {}
        req['request'] = endpoint_path
        req['nonce'] = self.nonce()

        js = json.dumps(req)
        data = base64.standard_b64encode(js.encode('utf8'))

        h = hmac.new(self.secret.encode('utf8'), data, hashlib.sha384)
        signature = h.hexdigest()
        headers = {"X-BFX-APIKEY": self.key,
                   "X-BFX-SIGNATURE": signature,
                   "X-BFX-PAYLOAD": data}

        return url, {'headers': headers}

    def query(self, method_verb, endpoint, authenticate=False,
              *args, **kwargs):
        """
        Queries exchange using given data. Defaults to unauthenticated query.
        :param method_verb: valid request type (PUT, GET, POST etc)
        :param endpoint: endpoint path for the resource to query, sans the url &
                         API version (i.e. '/btcusd/ticker/').
        :param authenticate: Bool to determine whether or not a signature is
                             required.
        :param args: Optional args for requests.request()
        :param kwargs: Optional Kwargs for self.sign() and requests.request()
        :return: request.response() obj
        """
        if self.version:
            endpoint_path = '/' + self.version + '/' + endpoint
        else:
            endpoint_path = '/' + endpoint

        url = self.url + endpoint_path
        if authenticate:  # sign off kwargs and url before sending request
            url, request_kwargs = self.sign(url, endpoint, endpoint_path,
                                            method_verb, *args, **kwargs)
        else:
            request_kwargs = kwargs
        r = self.api_request(method_verb, url, timeout=self.timeout,
                             **request_kwargs)

        if r.status_code == 200:
            return r.json()
        else:
            raise Exception("httpGet failed, detail is:%s" % r.text)

    def api_request(self, *args, **kwargs):
        """
        Wrapper which converts a requests.Response into our custom APIResponse
        object
        :param args:
        :param kwargs:
        :return:
        """
        if self.proxy:
            r = requests.request(proxies=self.proxies, *args, **kwargs)
        else:
            r = requests.request(*args, **kwargs)
        return r

