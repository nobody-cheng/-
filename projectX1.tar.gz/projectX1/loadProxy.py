from utils import redisHelper as rh


proxy_dict = {"bitfinex": ["127.0.0.1:8000", "10.0.0.1:8333"]}

for ex in proxy_dict:
    ex_proxy_set = rh.get_proxy(ex)
    new_proxy_set = set(proxy_dict[ex]) - ex_proxy_set
    rh.set_proxy(ex, new_proxy_set)
    rh.del_proxy(ex, ex_proxy_set - set(proxy_dict[ex]))
