import logging
import time
import traceback
from queue import Empty
from exchangeConnection.bitfinex.btfxwss import client
from utils import redisHelper
from threading import Thread
import datetime
from exchangeConnection.pro.websocket_api import ProWebsocketClient

logging.basicConfig(level=logging.INFO,
                    format='%(asctime)s %(filename)s[line:%(lineno)d] %(levelname)s %(message)s',
                    datefmt='%a, %d %b %Y %H:%M:%S',
                    filename='websocket_market_dat' + datetime.datetime.now().strftime("%Y%m%d-%H%M%S") + '.log',
                    filemode='w'
                   )
logging.getLogger("requests").setLevel(logging.WARNING)
logging.getLogger("urllib3").setLevel(logging.WARNING)

market_dict = {
    # "bitfinex": ["ltc_btc", "eth_btc", "etc_btc", "bcc_btc", "dash_btc", "btc_usd", "dash_usd"],
    "pro": ["ltc_btc", "eth_btc", "etc_btc", "bcc_btc", "bt1_btc", "bt2_btc",
                     "eos_btc", "knc_btc", "ast_btc", "zrx_btc", "tnt_btc",
                     "omg_btc", "storj_btc","snt_btc", "rdn_btc","qsp_btc", "rcn_btc",
                     "pay_btc", "mtl_btc", "dash_btc",
                     "btc_usdt", "eth_usdt", "ltc_usdt", "bcc_usdt", "etc_usdt","dash_usdt",
                     "omg_eth", "eos_eth", "rdn_eth", "qsp_eth", "rcn_eth"],
}

convert_dict = {"bcc": "bch", "dash": "dsh"}


def convert_symbol(symbol):
    a, b = symbol.split("_")
    if convert_dict.get(a):
        a = convert_dict.get(a)
    if convert_dict.get(b):
        b = convert_dict.get(b)
    return "_".join((a, b))


class ProWss(ProWebsocketClient):
    def __init__(self, symbols):
        super(ProWss, self).__init__(logging)
        self.start()
        for symbol in symbols:
            self.sub_depth(symbol.replace("_", ""))

    def on_depth(self, coin_type, msg):
        item = msg.get('tick')
        logging.info("{0} get data {1}".format(coin_type, item))
        bids = item.get("bids")
        asks = item.get("asks")
        ts = item.get("ts") / 1000
        redisHelper.set_marketdata("pro_%s" % coin_type, {"bids": bids, "asks": asks, "time": ts})



def bitfinex_depth(symbol):
    wss_symbol = convert_symbol(symbol).replace("_", "").upper()
    time.sleep(1)
    bitfinex_wss.subscribe_to_order_book(wss_symbol, prec="P1", len="100")
    subscribe_time = time.time()
    time.sleep(10)
    bid_list = []
    # empty = 0
    while True:
        try:
            # if time.time() - subscribe_time > 60:
            #     bitfinex_wss.unsubscribe_from_order_book(wss_symbol)
            #     time.sleep(2)
            #     bitfinex_wss.subscribe_to_order_book(wss_symbol, prec="P1", len="100")
            #     subscribe_time = time.time()
            #     time.sleep(2)
            #     continue
            books = bitfinex_wss.books(wss_symbol).get(block=False)
            logging.warning(books)
            # empty = 0
            if isinstance(books[0][0][0], list):    # 初始化
                bids, asks = [], []
                for bid in books[0][0]:
                    if bid[2] > 0:
                        bids.append([bid[0], bid[2]])
                    else:
                        asks.append([bid[0], -bid[2]])
                redisHelper.set_marketdata("bitfinex_%s" % symbol, {"bids": bids, "asks": asks, "time": books[1]})
            else:
                bid = books[0][0]
                bid_list.append(bid)
                if len(bid_list) >= 10:
                    try:
                        origin_data = redisHelper.get_depth("bitfinex", symbol)
                        for bid in bid_list:
                            if bid[1] == 0:  # 需要remove这个price level
                                if bid[2] > 0:
                                    new_bids = [ori_bid for ori_bid in origin_data["bids"] if ori_bid[0] != bid[0]]
                                    origin_data.update({"bids": new_bids, "time": time.time()})
                                else:
                                    new_asks = [ori_ask for ori_ask in origin_data["asks"] if ori_ask[0] != bid[0]]
                                    origin_data.update({"asks": new_asks, "time": time.time()})
                            else:
                                if bid[2] > 0:
                                    if len(origin_data["bids"]) == 0 or origin_data["bids"][0][0] < bid[0]:
                                        origin_data["bids"].insert(0, [bid[0], bid[2]])
                                    elif origin_data["bids"][-1][0] > bid[0]:
                                        origin_data["bids"].append([bid[0], bid[2]])
                                    else:
                                        for i in range(0, len(origin_data["bids"])):
                                            if origin_data["bids"][i][0] == bid[0]:
                                                origin_data["bids"][i][1] = bid[2]
                                                break
                                            elif origin_data["bids"][i][0] < bid[0]:
                                                origin_data["bids"].insert(i, [bid[0], bid[2]])
                                                break
                                else:
                                    if len(origin_data["asks"]) == 0 or origin_data["asks"][0][0] > bid[0]:
                                        origin_data["asks"].insert(0, [bid[0], -bid[2]])
                                    elif origin_data["asks"][-1][0] < bid[0]:
                                        origin_data["asks"].append([bid[0], -bid[2]])
                                    else:
                                        for i in range(0, len(origin_data["asks"])):
                                            if origin_data["asks"][i][0] == bid[0]:
                                                origin_data["asks"][i][1] = -bid[2]
                                                break
                                            elif origin_data["asks"][i][0] > bid[0]:
                                                origin_data["asks"].insert(i, [bid[0], -bid[2]])
                                                break
                        bid_list = []
                        origin_data.update({"time": books[1]})
                        redisHelper.set_marketdata("bitfinex_%s" % symbol, origin_data)
                    except Exception:
                        logging.error(traceback.format_exc())
                        bitfinex_wss.unsubscribe_from_order_book(wss_symbol)
                        time.sleep(10)
                        bitfinex_wss.subscribe_to_order_book(wss_symbol, prec="P1", len="100")  # 数据出错 需要重新订阅
                        subscribe_time = time.time()
                        time.sleep(10)
            time.sleep(0.0)
        except Empty:
            # logging.error("No book data arrived!")
            # empty += 1
            # if empty > 1000:
            #     logging.error("bitfinex_wss.conn.reconnect()")
            #     bitfinex_wss.conn.reconnect()
            #     time.sleep(10)
            time.sleep(0.1)
        except KeyError:
            bitfinex_wss.subscribe_to_order_book(wss_symbol, prec="P1", freq="F1", len="100")
            subscribe_time = time.time()
            logging.error("KeyError!")
            time.sleep(10)
        except Exception:
            logging.error(traceback.format_exc())
            time.sleep(10)

if __name__ == "__main__":
    proc_list = []
    bitfinex_wss = None
    for k in market_dict:
        logging.info(str([k, market_dict[k]]))
        if k == "pro":
            pro_wss = ProWss(market_dict[k])

        # if k == "bitfinex":
        #     bitfinex_wss = client.BtfxWss(log_level=logging.INFO, url='wss://api.bitfinex.com/ws/2')
        #     bitfinex_wss.start()
        # for market in market_dict[k]:
        #     getmarket_thread = Thread(target=bitfinex_depth, args=(market,))
        #     getmarket_thread.setDaemon(True)
        #     proc_list.append(getmarket_thread)
        # for getmarket_thread in proc_list:
        #     getmarket_thread.start()
        # for getmarket_thread in proc_list:
        #     getmarket_thread.join()

