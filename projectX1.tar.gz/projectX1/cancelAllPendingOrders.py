# !/usr/bin/python3
# -*- coding: utf-8 -*-

# @Author : hyfwin

import sys
from utils import redisHelper as md
import time
from signalGenerator import strategy
import traceback
if len(sys.argv) < 2:
    print("参数错误!")
    exit()

strategy_name = sys.argv[1]

accounts = md.get_strategy_account(strategy_name)
print(accounts)

for ex in accounts:
    for acc in accounts[ex]:
        print(accounts[ex])
        try:
            chbtc_accid, okcoin_accid, pro_accid, polo_accid, kraken_accid, okex_accid, bittrex_accid, bitfinex_accid = \
                None, None, None, None, None, None, None, None
            if ex == "chbtc":
                chbtc_accid = acc
            elif ex == "okcoin":
                okcoin_accid = acc
            elif ex == "pro":
                pro_accid = acc
            elif ex == "polo":
                polo_accid = acc
            elif ex == "kraken":
                kraken_accid = acc
            elif ex == "okex":
                okex_accid = acc
            elif ex == "bittrex":
                bittrex_accid = acc
            elif ex == "bitfinex":
                bitfinex_accid = acc
            if(isinstance(accounts[ex][acc], list)):
                coin_types = accounts[ex][acc]
            elif(isinstance(accounts[ex][acc], str)):
                coin_types = [accounts[ex][acc]]
            for coin_type in coin_types:
                strat = strategy.Strategy(time.time(), chbtc_accid=chbtc_accid, okcoin_accid=okcoin_accid,
                                          pro_accid=pro_accid, polo_accid=polo_accid, kraken_accid=kraken_accid,
                                          okex_accid=okex_accid, bittrex_accid=bittrex_accid,
                                          bitfinex_accid=bitfinex_accid)
                print('cancelling [%s %s] active orders' % (ex, coin_type))
                strat.cancel_pending_orders(exchange=ex.lower(), pair=coin_type)
        except Exception as e:
            print(traceback.format_exc())
            continue




