#!/usr/bin/env python
# -*- coding: utf-8 -*-

class positionRecordSpot(object):
    cash = 0
    btc = 0
    ltc = 0
    cash_loan = 0
    btc_loan = 0
    ltc_loan = 0
    cash_frozen = 0
    btc_frozen = 0
    ltc_frozen = 0
    total = 0
    net = 0
    prefix = None

    def account_info(self):
        info = {}
        info[self.prefix + 'cash'] = self.cash
        info[self.prefix + 'btc'] = self.btc
        info[self.prefix + 'ltc'] = self.ltc
        info[self.prefix + 'cash_loan'] = self.cash_loan
        info[self.prefix + 'btc_loan'] = self.btc_loan
        info[self.prefix + 'ltc_loan'] = self.ltc_loan
        info[self.prefix + 'cash_frozen'] = self.cash_frozen
        info[self.prefix + 'btc_frozen'] = self.btc_frozen
        info[self.prefix + 'ltc_frozen'] = self.ltc_frozen
        info[self.prefix + 'total'] = self.total
        info[self.prefix + 'net'] = self.net
        return info


class huobi_cny(positionRecordSpot):
    prefix = 'huobi_cny_'


class huobi_usd(positionRecordSpot):
    prefix = 'huobi_usd_'


class okcoin_cny(positionRecordSpot):
    prefix = 'okcoin_cny_'


class okcoin_usd(positionRecordSpot):
    prefix = 'okcoin_usd_'


class btcc_cny(positionRecordSpot):
    prefix = 'btcc_cny_'


class btcc_usd(positionRecordSpot):
    prefix = 'btcc_usd_'
