#!/usr/bin/env python
# -*- coding: utf-8 -*-

import redis
# import accountConfig
import json
import pandas as pd
import time

r = redis.Redis(host="marketdata.jjdqat.ng.0001.apne1.cache.amazonaws.com", port=6379, db=0)
hash_name = "market_data"
acc_name = "account"
acc_info_name = "acc_info"
acc_future = "acc_future_info"
acc_pnl = "acc_pnl"
strategy_acc = "strategy_acc"
acc_ord = "acc_ord"
sub_acc_status = "sub_acc_status"
acc_balance = "acc_balance"
strategy_cfg = "strategy_config"
last_trade = "last_trade"
kline = "kline"
proxy = "proxy"


def get_depth(exchange, coin_type):
    return json.loads(r.hget(hash_name, "%s_%s" % (exchange, coin_type)).decode('utf-8').replace("'", "\""))


def get_account(exchange, account_id):
    '''
    获取账号key之类的信息
    :param exchange: 市场
    :param account_id: 账户id
    :return:
    '''
    ret = r.hget(acc_name, "%s_%s" % (exchange, account_id))
    if ret is None:
        return ret
    return json.loads(ret.decode('utf-8').replace("'", "\""))


def set_account(exchange, account_id, key_obj):
    """
    设置账号key
    :param exchange:
    :param account_id:
    :param key_obj:
    :return:
    """
    return r.hset(acc_name, "%s_%s" % (exchange, account_id), key_obj)


def has_account(exchange, account_id):
    """
    判断是否存在
    :param exchange:
    :param account_id:
    :return:
    """
    return r.hexists(acc_name, "%s_%s" % (exchange, account_id))


def get_account_info(exchange, account_id):
    """
    获取账户持仓等信息
    :param exchange: 市场
    :param account_id: 账户id
    :return:
    """
    ret = r.hget(acc_info_name, "%s_%s" % (exchange, account_id))
    if ret is None:
        print(exchange, account_id)
    return json.loads(ret.decode('utf-8').replace("'", "\""))


def get_account_future_info(exchange, account_id):
    """
    获取账户期货持仓等信息
    :param exchange: 市场
    :param account_id: 账户id
    :return:
    """
    ret = r.hget(acc_future, "%s_%s" % (exchange, account_id))
    if ret is None:
        print(exchange, account_id)
    return json.loads(ret.decode('utf-8').replace("'", "\""))


def set_account_pnl(strategy_name, value):
    """
    写入当前pnl
    :param strategy_name:
    :param value:
    :return:
    """
    return r.hset(acc_pnl, strategy_name, json.dumps(value))


def set_strategy_account(strategy_name, accounts):
    """
    把策略用的account写入redis
    :param strategy_name:
    :param accounts:
    :return:
    """
    return r.hset(strategy_acc, strategy_name, json.dumps(accounts))


def get_strategy_account(strategy_name):
    """
    获取策略用的accounts
    :param strategy_name:
    :return:
    """
    ret = r.hget(strategy_acc, strategy_name)
    if ret is None:
        return None
    else:
        return json.loads(ret.decode('utf-8').replace("'", "\""))


def get_strategy_config(strategy_name):
    """
    读取策略对应的config
    :param strategy_name:
    :return:
    """
    ret = r.hget(strategy_cfg, strategy_name)
    if ret is None:
        return {}
    else:
        return json.loads(ret.decode('utf-8').replace("'", "\""))


def set_strategy_config(strategy_name, cfg):
    ret = r.hset(strategy_cfg, strategy_name, cfg)
    return ret


def get_acc_key(exchange, acc_id):
    ret = r.hget(acc_name, "_".join([exchange, acc_id]))
    if ret is None:
        return None
    else:
        ret = json.loads(ret.decode("utf-8").replace("'", "\""))
        return ret


def set_redis_acc_info(exchange, acc_id, ret):
    return r.hset(acc_info_name, "_".join([exchange, acc_id]), json.dumps(ret))


def set_redis_acc_future_info(exchange, acc_id, ret):
    return r.hset(acc_future, "_".join([exchange, acc_id]), json.dumps(ret))


def account_alllist():
    return r.hkeys(acc_name)


def set_marketdata(key, data):
    r.hset(hash_name, key, json.dumps(data))


def set_last_trade(exchange, coin_type, data):
    return r.hset(last_trade, "{0}_{1}".format(exchange, coin_type), json.dumps(data))


def get_last_trade(exchange, coin_type):
    result = r.hget(last_trade, "{0}_{1}".format(exchange, coin_type))
    if not result:
        return None
    else:
        return pd.read_json(json.loads(result.decode('utf-8')), orient="split").sort_index()


def set_kline(exchange, coin_type, frequency, data):
    return r.hset(kline, "{0}_{1}_{2}".format(exchange, coin_type, frequency), json.dumps(data))


def get_kline(exchange, coin_type, frequency):
    result = r.hget(kline, "{0}_{1}_{2}".format(exchange, coin_type, frequency))
    if not result:
        return None
    else:
        return pd.read_json(json.loads(result.decode('utf-8')), orient="split").sort_index()


def redis_lock(lock_key, key_value, expire_time):
    return r.set(lock_key, key_value, nx=True, ex=expire_time)


def redis_unlock(lock_key, key_value):
    if r.get(lock_key) is None:
        return
    elif r.get(lock_key).decode("utf8") == str(key_value):
        return r.delete(lock_key)
    else:
        return


def get_proxy(ex, all=True):
    if all:
        return r.smembers("_".join([proxy, ex]))
    else:
        return r.srandmember("_".join([proxy, ex]), 1)


def set_proxy(ex, proxy_addr_list):
    return r.sadd("_".join([proxy, ex]), *proxy_addr_list)


def del_proxy(ex, proxy_addr_list):
    return r.srem("_".join([proxy, ex]), *proxy_addr_list)




if __name__ == "__main__":
    # print(get_depth("huobi", "btc_cny"))
    # print(get_depth("bitvc", "btc_cny", "week"))
    # print(set_account("huobi", "test1", accountConfig.HUOBI))
    # print(get_account("huobi", "test1"))
    # json.loads(get_account("huobi", "test1"))
    with open("../account.json","r") as file:
        load_dict = json.load(file)
        print(load_dict)
        for exchange in load_dict:
            for acc in load_dict[exchange]:
                if has_account(exchange, acc):
                    print("已存在，请先删除")
                    continue
                set_account(exchange, acc, load_dict[exchange][acc])
    # print(get_account("huobi", "huobi-bincytest3"))
    # acc = json.loads(get_account("huobi", "huobi-18513953462"))
    # print(acc.get("ACCESS_KEY"))

