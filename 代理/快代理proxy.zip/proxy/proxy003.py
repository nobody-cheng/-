import requests
import json
from lxml import etree


class proxy002:
    def __init__(self):
        self.start_urls = 'http://www.kuaidaili.com/free/inha/{}/'
        cookies = "yd_cookie=8a30451e-d084-4d23a79198f99a90b14271bab6dd6ee333fe; Hm_lvt_7ed65b1cc4b810e9fd37959c9bb51b31=1513602692; _ga=GA1.2.227259048.1513602692; _gid=GA1.2.146967798.1513602692; channelid=0; sid=1513665018301216; Hm_lpvt_7ed65b1cc4b810e9fd37959c9bb51b31=1513665890; _ydclearance=6d85dd7c0189fdda0042c69e-6862-42e9-84a4-303d0f238f13-1513680769"
        self.cookies_dict ={i.split("=")[0]:i.split("=")[-1] for i in cookies.split("; ")}
        self.headers = {"User-Agent":"Mozilla/5.0 (X11; Linux x86_64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/63.0.3239.84 Safari/537.36",
                        "Referer":"http://www.kuaidaili.com/free/inha/1/"}






    def parse_item(self):
        response = requests.get(self.start_urls, cookies=self.cookies_dict, headers=self.headers)
        print(response .status_code)
        response = response.content.decode()
        print(response)
        html = etree.HTML(response)
        content_list = html.xpath(".//table[@class='table table-bordered table-striped']//tbody/tr")
        print("="*100)
        # 总页数
        total = html.xpath(".//div[@id='listnav']/ul//text()")
        print(html)
        print(total)
        # total = int(total)
        # print(type(total))

        # for i in content_list:
        #     item = {}
        #     item["ip"] = i.xpath(".//td[1]/text()").extract_first()
        #     item["prot"] = i.xpath(".//td[2]/text()").extract_first()
        #     item["匿名度"] = i.xpath(".//td[3]/text()").extract_first()
        #     item["类型"] = i.xpath(".//td[4]/text()").extract_first()
        #     # item["位置"] = i.xpath(".//td[5]/text()").extract_first()
        #     # item["响应速度"] = i.xpath(".//td[6]/text()").extract_first()
        #     # item["最后验证时间"] = i.xpath(".//td[7]/text()").extract_first()
        #     item_json = json.dumps(item, ensure_ascii=False, indent=2)
        #     print(item)
        #     with open("proxy.txt", "a") as f:
        #         f.write(item_json)
        #     proxy_list.append(item)
        #     if i < total+1:
        #         global i
        #         i +=1
        #         self.headers["Referer"] = "http://www.kuaidaili.com/free/inha/{}/".format(i-1)


if __name__ == '__main__':
    p =proxy002()
    p.parse_item()