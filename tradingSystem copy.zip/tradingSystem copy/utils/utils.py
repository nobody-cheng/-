#!/usr/bin/env python
# -*- coding: utf-8 -*-
# @Time    : 20/10/2017 12:07 PM
# @Author  : Lloyd Lee
# @File    : utils.py

import time


class DotDict(dict):
    """dot.notation access to dictionary attributes"""
    __getattr__ = dict.get
    __setattr__ = dict.__setitem__
    __delattr__ = dict.__delitem__


def http_get(url, params, headers=None, timeout=10):
    import urllib.parse
    import requests
    if not headers:
        headers = {
            "Content-type": "application/x-www-form-urlencoded",
        }
    if params:
        payload = urllib.parse.urlencode(params)
    else:
        payload = None
    response = requests.get(url, payload, headers=headers, timeout=timeout)
    if response.status_code == 200:
        return response.json()
    else:
        raise Exception("HTTP GET failed, detail is:%s" % response.text)


def http_post(url, params, headers=None, timeout=10):
    import requests
    response = requests.post(url, params, headers=headers, timeout=timeout)
    if response.status_code == 200:
        return response.json()
    else:
        raise Exception("HTTP GET failed, detail is:%s" % response.text)


class APIRetStatus(object):
    SUCCESS = 0
    REQUEST_ERROR = 1
    OTHER = 2
    PARAMETER_ERROR = 3


class OrderStatus(object):
    SUBMITTED = 0  # no filled
    PARTIAL_FILLED = 1  # partially filled, not cancelled
    PARTIAL_FILLED_CANCELLED = 2  # partially filled, cancelled
    FULLY_FILLED = 3  # fully filled
    CANCELLED = 4  # no filled, cancelled


class DataKeyWords(object):
    STATUS = 'status'
    SERVER_TIME = 's_ts'
    CLIENT_TIME = 'c_ts'
    ERROR_MSG = 'error_msg'
    BASE = 'base'
    QUOTE = 'quote'


class MarketDataKeyWords(DataKeyWords):
    BIDS = 'bids'
    ASKS = 'asks'


class AccountDataKeyWords(DataKeyWords):
    AVAILABLE = 'available'
    FROZEN = 'frozen'
    TOTAL = 'total'
    BORROW = 'borrow'
    BALANCE = 'balance'
    FUTURE_RIGHTS_TOTAL = 'rights_total'
    FUTURE_PROFIT_REAL = 'profit_real'
    FUTURE_PROFIT_UNREAL = 'profit_unreal'
    FUTURE_RISK_RATE = 'risk_rate'


class OrderDataKeyWords(DataKeyWords):
    ORDER_CREATE_TIME = 'order_create_time'
    ORDER_FINISH_TIME = 'finish_time'
    ORDER_ID = 'order_id'
    ORDER_STATUS = 'order_status'
    ORDER_PRICE = 'order_price'
    ORDER_QTY = 'order_qty'
    ORDER_CASH_AMOUNT = 'order_cash_amt'
    DEAL_AVG_PRICE = 'deal_avg_price'
    DEAL_QTY = 'deal_qty'
    DEAL_AMT = 'deal_cash_amount'
    ORDER_TYPE = 'order_type'
    ORDER_SIDE = 'order_side'
    FEES = 'fees'


class OrderType(object):
    LIMIT_ORDER = 0
    MARKET_ORDER = 1


class OrderSide(object):
    BUY = 0
    SELL = 1




