#!/usr/bin/env python
# -*- coding: utf-8 -*-
# @Time    : 14/11/2017 11:55 PM
# @Author  : Lloyd Lee
# @File    : order.py


class Order(object):
    def __init__(
            self,
            instmt
    ):
        """
        :type instmt: Instrument
        """
        self.instmt = instmt
        self.order_id = None
