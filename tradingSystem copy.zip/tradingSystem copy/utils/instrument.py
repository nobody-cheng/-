#!/usr/bin/env python
# -*- coding: utf-8 -*-
# @Time    : 02/12/2017 6:09 PM
# @Author  : Lloyd Lee
# @File    : instrument.py


from enum import Enum, unique


@unique
class InstmtType(Enum):
    SPOT = 0
    FUTURE = 1


class Instrument(object):
    def __init__(
            self,
            base,
            quote,
            instmt_type=InstmtType.SPOT
    ):
        self.base = base
        self.quote = quote
        self.instmt_type = instmt_type




