#!/usr/bin/env python
# -*- coding: utf-8 -*-
# @Time    : 01/12/2017 3:27 PM
# @Author  : Lloyd Lee
# @File    : coinmarketcap.py

import pandas as pd

from utils import http_get

def get_coin_market_cap_ticker():
    data = http_get('https://api.coinmarketcap.com/v1/ticker/?limit=0&convert=CNY', None)
    return data


