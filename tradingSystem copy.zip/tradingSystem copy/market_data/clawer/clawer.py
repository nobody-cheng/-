#!/usr/bin/env python
# -*- coding: utf-8 -*-
# @Time    : 20/10/2017 12:07 PM
# @Author  : Lloyd Lee
# @File    : clawer.py

import time
import gevent
from threading import Thread

from ex_api.exchange import Exchange
from database.redisdb import RedisDB


class DataServiceRest(object):
    def __init__(self):
        self.__redis = RedisDB()

    def redis_alive(self):
        return self.__redis.is_connected()

    def redis_reconnect(self):
        return self.__redis.reconnect()

    def get_redis(self):
        return self.__redis

    def get_depth_sub(self):
        return self.__redis.get_depth_sub()

    def add_depth_sub(self, ex_name, base, quote):
        return self.__redis.set_depth_sub(ex_name, base, quote, value=1)

    def remove_depth_sub(self, ex_name, base, quote):
        return self.__redis.set_depth_sub(ex_name, base, quote, value=0)

    def get_account_sub(self):
        return self.__redis.get_account_sub()

    def add_account_sub(self, ex_name, account_name):
        return self.__redis.set_account_sub(ex_name, account_name, value=1)

    def remove_account_sub(self, ex_name, account_name):
        return self.__redis.set_account_sub(ex_name, account_name, value=0)

    def get_account_cfg_info(self, ex_name, account_name):
        return self.__redis.get_account_info(ex_name, account_name)

    def set_account_cfg_info(self, ex_name, account_name, account_cfg=None):
        return self.__redis.set_account_cfg_info(ex_name, account_name, acct_cfg=account_cfg)

    def set_account_attribute(self, ex_name, account_name, attribute_name, attribute_value):
        return self.__redis.set_account_attribute(ex_name, account_name, attribute_name, attribute_value)
    
    def set_account_access_key(self, ex_name, account_name, access_key):
        return self.__redis.set_account_access_key(ex_name, account_name, access_key)
    
    def set_account_secret_key(self, ex_name, account_name, secret_key):
        return self.__redis.set_account_secret_key(ex_name, account_name, secret_key)
    
    def get_account_attribute(self, ex_name, account_name, attribute_name):
        return self.__redis.get_account_attribute(ex_name, account_name, attribute_name)

    def get_account_access_key(self, ex_name, account_name):
        return self.__redis.get_account_access_key(ex_name, account_name)
    
    def get_account_secret_key(self, ex_name, account_name):
        return self.__redis.get_account_secret_key(ex_name, account_name)
    
    def get_kline_sub(self):
        return self.__redis.get_kline_sub()

    def add_kline_sub(self, ex_name, base, quote, period='1min'):
        return self.__redis.set_kline_sub(ex_name, base, quote, period=period, value=1)

    def remove_kline_sub(self, ex_name, base, quote):
        return self.__redis.set_kline_sub(ex_name, base, quote, value=0)
    
    def get_trades_sub(self):
        return self.__redis.get_trades_sub()

    def add_trades_sub(self, ex_name, base, quote):
        return self.__redis.set_trades_sub(ex_name, base, quote, value=1)

    def remove_trades_sub(self, ex_name, base, quote):
        return self.__redis.set_trades_sub(ex_name, base, quote, value=0)
    
    def get_ticker_sub(self):
        return self.__redis.get_ticker_sub()

    def add_ticker_sub(self, ex_name, base, quote):
        return self.__redis.set_ticker_sub(ex_name, base, quote, value=1)

    def remove_ticker_sub(self, ex_name, base, quote):
        return self.__redis.set_ticker_sub(ex_name, base, quote, value=0)

    def update_depth_data(self, ex, base, quote):
        """
        :type ex: Exchange
        :type base: str
        :type quote: str
        :return:
        """
        api = ex.get_api()
        data = api.get_depth(base, quote)
        ex_name = ex.get_name()
        self.__redis.set_depth_data(ex_name, base, quote, value=data)
    
    def update_ticker_data(self, ex, base, quote):
        """
        :type ex: Exchange
        :type base: str
        :type quote: str
        :return:
        """
        api = ex.get_api()
        try:
            data = api.get_ticker(base, quote)
        except Exception:
            return
        ex_name = ex.get_name()
        self.__redis.set_ticker_data(ex_name, base, quote, value=data)
    
    def update_kline_data(self, ex, base, quote, period):
        """
        :type ex: Exchange
        :type base: str
        :type quote: str
        :return:
        """
        api = ex.get_api()
        try:
            data = api.get_kline(base, quote, period=period, size=None)
        except Exception:
            return
        ex_name = ex.get_name()
        self.__redis.set_kline_data(ex_name, base, quote, period, value=data)

    def update_account_data(self, ex, account_name):
        """
        :type ex: Exchange
        :type account_name: str
        :return:
        """
        api = ex.get_api()
        try:
            data = api.get_balances()
        except Exception:
            return
        ex_name = ex.get_name()
        self.__redis.set_account_data(ex_name, account_name, data)

    # TODO: 重试机制
    def depth_service(self, timeout=5):
        depth_sub = self.get_depth_sub()
        event_list = list()
        for ex_name, pair_list in depth_sub.items():
            ex = Exchange(ex_name)
            for pair in pair_list:
                base, quote = pair.split('_')
                event_list.append(
                    gevent.spawn(
                        self.update_depth_data,
                        ex,
                        base,
                        quote
                    )
                )
        gevent.joinall(event_list, timeout=timeout)
        
    def ticker_service(self, timeout=5):
        ticker_sub = self.get_ticker_sub()
        event_list = list()
        for ex_name, pair_list in ticker_sub.items():
            ex = Exchange(ex_name)
            for pair in pair_list:
                base, quote = pair.split('_')
                event_list.append(
                    gevent.spawn(
                        self.update_ticker_data,
                        ex,
                        base,
                        quote
                    )
                )
        gevent.joinall(event_list, timeout=timeout)
        
    def kline_service(self, timeout=5):
        kline_sub = self.get_kline_sub()
        event_list = list()
        for ex_name, data in kline_sub.items():
            for period, pair_list in data.items():
                ex = Exchange(ex_name)
                for pair in pair_list:
                    base, quote = pair.split('_')
                    event_list.append(
                        gevent.spawn(
                            self.update_kline_data,
                            ex,
                            base,
                            quote,
                            period
                        )
                    )
        gevent.joinall(event_list, timeout=timeout)

    def account_data_service(self, timeout=10):
        account_sub = self.get_account_sub()
        event_list = list()
        for ex_name, accounts in account_sub.items():
            for account_name in accounts:
                access_key = self.get_account_access_key(ex_name, account_name)
                secret_key = self.get_account_secret_key(ex_name, account_name)
                if not isinstance(access_key, str) or not isinstance(secret_key, str):
                    continue
                ex = Exchange(ex_name, access_key=access_key, secret_key=secret_key)
                event_list.append(
                    gevent.spawn(
                        self.update_account_data,
                        ex,
                        account_name
                    )
                )
        gevent.joinall(event_list, timeout=timeout)


class AccountDataClawerThread(Thread):
    def __init__(self, sleep_time=1, api_timeout=10):
        Thread.__init__(self)
        self.__sleep_time = sleep_time
        self.__data_service = DataServiceRest()
        self.__api_timeout = api_timeout

    def run(self):
        while True:
            time.sleep(self.__sleep_time)
            try:
                self.__data_service.account_data_service(timeout=self.__api_timeout)
            except Exception:
                continue


class DepthDataClawerThread(Thread):
    def __init__(self, sleep_time=1, api_timeout=5):
        Thread.__init__(self)
        self.__sleep_time = sleep_time
        self.__data_service = DataServiceRest()
        self.__api_timeout = api_timeout

    def run(self):
        while True:
            time.sleep(self.__sleep_time)
            try:
                self.__data_service.depth_service(timeout=self.__api_timeout)
            except Exception:
                continue


# acct_thread = AccountDataThread()
# acct_thread.start()
# while True:
#     time.sleep(2)
#     from market_data.reader.reader import DataReader
#     dr = DataReader()
#     print(dr.get_account_data('huobipro', 'lloyd'))

a = DataServiceRest()
a.account_data_service()
# a.add_kline_sub('huobipro','ltc','usdt')
# a.add_kline_sub('huobipro','btc','usdt')
# a.add_kline_sub('binance','btc','usdt')
# # print(a.get_depth_sub())
# # a.depth_service()
# # print(a.get_kline_sub())
# a.kline_service()
