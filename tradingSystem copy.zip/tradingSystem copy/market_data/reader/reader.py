#!/usr/bin/env python
# -*- coding: utf-8 -*-
# @Time    : 14/12/2017 2:41 PM
# @Author  : Lloyd Lee
# @File    : reader.py
from threading import Thread

import time

from database.redisdb import RedisDB


class DataReader(object):
    def __init__(self):
        self.__redis = RedisDB()

    def redis_alive(self):
        return self.__redis.is_connected()

    def redis_reconnect(self):
        return self.__redis.reconnect()

    def get_redis(self):
        return self.__redis

    def get_depth_data_all(self):
        return self.__redis.get_depth_data_all()

    def get_depth_data(self, ex_name, base, quote):
        return self.__redis.get_depth_data(ex_name, base, quote)

    def get_account_data_all(self):
        return self.__redis.get_account_data_all()

    def get_account_data(self, ex_name, account_name):
        return self.__redis.get_account_data(ex_name, account_name)

    def get_depth_sub(self):
        return self.__redis.get_depth_sub()

    def get_account_sub(self):
        return self.__redis.get_account_sub()

    def get_account_cfg_info(self, ex_name, account_name):
        return self.__redis.get_account_info(ex_name, account_name)

    def get_account_attribute(self, ex_name, account_name, attribute_name):
        return self.__redis.get_account_attribute(ex_name, account_name, attribute_name)

    def get_account_access_key(self, ex_name, account_name):
        return self.__redis.get_account_access_key(ex_name, account_name)

    def get_account_secret_key(self, ex_name, account_name):
        return self.__redis.get_account_secret_key(ex_name, account_name)

    def get_kline_sub(self):
        return self.__redis.get_kline_sub()

    def get_trades_sub(self):
        return self.__redis.get_trades_sub()

    def get_ticker_sub(self):
        return self.__redis.get_ticker_sub()


class AccountDataReaderTread(Thread):
    def __init__(self, sleep_time=1):
        Thread.__init__(self)
        self.__sleep_time = sleep_time
        self.__reader_service = DataReader()

    def run(self):
        while True:
            time.sleep(self.__sleep_time)
            try:
                print(self.__reader_service.get_account_data_all())
            except Exception:
                continue

# from market_data.clawer.clawer import AccountDataClawerThread
#
# feeder_thread = AccountDataClawerThread()
# reader_thread = AccountDataReaderTread()
#
# feeder_thread.start()
# reader_thread.start()

