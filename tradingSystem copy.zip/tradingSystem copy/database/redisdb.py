#!/usr/bin/env python
# -*- coding: utf-8 -*-
# @Time    : 30/11/2017 8:48 PM
# @Author  : Lloyd Lee
# @File    : redisdb.py


import configparser
import redis
from ast import literal_eval


def get_config_path():
    import os
    path = os.path.split(os.path.realpath(__file__))[0]
    return path + '/redisdb.conf'


def get_sub_kline_name():
    return 'sub:kline'


def get_sub_ticker_name():
    return 'sub:ticker'


def get_sub_depth_name():
    return 'sub:depth'


def get_sub_trades_name():
    return 'sub:trades'


def get_sub_account_name():
    return 'sub:accounts'


def get_kline_data_name():
    return 'data:kline'


def get_ticker_data_name():
    return 'data:ticker'


def get_depth_data_name():
    return 'data:depth'


def get_trades_data_name():
    return 'data:trades'


def get_account_data_name():
    return 'data:account'


def get_account_config_name():
    return 'config:accounts'


def get_config():
    config = configparser.ConfigParser()
    config.read(get_config_path())
    cfg = config['db']
    return {
        'host': cfg['host'],
        'port': cfg['port'],
    }


def get_redis_conn():
    cfg = get_config()
    r = redis.StrictRedis(
        host=cfg['host'],
        port=cfg['port'],
        decode_responses=True
    )
    return r


def get_sub_info(r, sub_name):
    info = r.hgetall(sub_name)
    sub_info = dict()
    for key, value in info.items():
        if value == 1 or value == '1':
            try:
                param_list = key.split(':')
                ex_name, base, quote = param_list[:3]
                if ex_name not in sub_info.keys():
                    sub_info.update({ex_name: set()})
                pair = '{base}_{quote}'.format(base=base, quote=quote)
                sub_info[ex_name].add(pair)
            except Exception:
                continue
    return sub_info


def set_value(r, hash_name, ex_name, base, quote, value, extras=None):
    """
    :type extra: list
    :return:
    """
    pair = '{base}:{quote}'.format(base=base, quote=quote)
    key = '{ex_name}:{pair}'.format(ex_name=ex_name, pair=pair)
    if extras:
        for extra in extras:
            key = '{key}:{extra}'.format(key=key, extra=extra)
    r.hset(hash_name, key, value)


def get_kline_sub(r=None):
    if not r:
        r = get_redis_conn()
    info = r.hgetall(get_sub_kline_name())
    sub_info = dict()
    for key, value in info.items():
        if value == 1 or value == '1':
            try:
                param_list = key.split(':')
                ex_name, base, quote, period = param_list[:4]
                if ex_name not in sub_info.keys():
                    sub_info.update({ex_name: dict()})
                if period not in sub_info[ex_name].keys():
                    sub_info[ex_name].update({period: set()})
                pair = '{base}_{quote}'.format(base=base, quote=quote)
                sub_info[ex_name][period].add(pair)
            except Exception:
                continue
    return sub_info


def get_account_sub(r=None):
    """
    get all the accounts sub info,
    {
        <ex_name>:
            {
                <account_a_name>,
                <account_b_name>,
                ...
            }
        ...
    }
    :param r:
    :return:
    """
    if not r:
        r = get_redis_conn()
    info = r.hgetall(get_sub_account_name())
    sub_info = dict()
    for key, value in info.items():
        if value == 1 or value == '1':
            try:
                ex_name, acct_name = key.split(':')
                if ex_name not in sub_info.keys():
                    sub_info.update({ex_name: set()})
                sub_info[ex_name].add(acct_name)
            except Exception:
                continue
    return sub_info


def set_account_sub(ex_name, account_name, value=1, r=None):
    if not r:
        r = get_redis_conn()
    key = '{ex_name}:{account_name}'.format(ex_name=ex_name, account_name=account_name)
    r.hset(
        get_sub_account_name(),
        key,
        value
    )


def get_account_cfg_all(r=None):
    """
    get account cfg info,
    {
        <ex_a_name>:
            <account_a_name>:
                {
                    <access_key>: xxx,
                    <secret_key>: xxx,
                    <other_attribute>: xxx,
                    ...
                },
                <account_b_name>:
                {
                    <access_key>: xxx,
                    <secret_key>: xxx,
                    <other_attribute>: xxx,
                    ...
                }
                ...
        <ex_a_name>:
            ...
    }
    :param r:
    :return:
    """
    if not r:
        r = get_redis_conn()
    info = r.hgetall(get_account_config_name())
    accounts = dict()
    for key, value in info.items():
        try:
            ex_name, acct_name, param = key.split(':')
            if ex_name not in accounts.keys():
                accounts.update({ex_name: dict()})
            if acct_name not in accounts[ex_name]:
                accounts[ex_name].update({acct_name: dict()})
            accounts[ex_name][acct_name].update({param: value})
        except Exception:
            continue
    return accounts


def get_account_cfg(ex_name, acct_name, r=None):
    data = get_account_cfg_all(r)
    info = dict()
    try:
        info = data[ex_name][acct_name]
    except Exception:
        pass
    return info


def set_account_cfg(ex_name, acct_name, params=None, r=None):
    """
    :type params: dict
    """
    if not r:
        r = get_redis_conn()
    hname = get_account_config_name()
    if not params:
        params = dict()
    for key, value in params.items():
        new_key = '{ex_name}:{acct_name}:{key}'.format(ex_name=ex_name, acct_name=acct_name, key=key)
        r.hset(hname, new_key, value)


def set_kline_sub(ex_name, base, quote, period, value=1, r=None):
    if not r:
        r = get_redis_conn()
    return set_value(
        r,
        get_sub_kline_name(),
        ex_name,
        base,
        quote,
        value,
        extras=[period]
    )


def set_kline_data(ex_name, base, quote, period, value=None, r=None):
    if not r:
        r = get_redis_conn()
    if not value:
        value = dict()
    return set_value(
        r,
        get_kline_data_name(),
        ex_name,
        base,
        quote,
        value,
        extras=[period]
    )


def get_depth_sub(r=None):
    if not r:
        r = get_redis_conn()
    return get_sub_info(
        r,
        get_sub_depth_name()
    )


def set_depth_sub(ex_name, base, quote, value=1, r=None):
    if not r:
        r = get_redis_conn()
    return set_value(
        r,
        get_sub_depth_name(),
        ex_name,
        base,
        quote,
        value
    )


def set_depth_data(ex_name, base, quote, value=None, r=None):
    if not r:
        r = get_redis_conn()
    if not value:
        value = dict()
    return set_value(
        r,
        get_depth_data_name(),
        ex_name,
        base,
        quote,
        value
    )


def get_data_all(name, r=None):
    if not r:
        r= get_redis_conn()
    data = r.hgetall(name)
    for key, value in data.items():
        if isinstance(value, str):
            data[key] = literal_eval(value)
    return data


def get_depth_data_all(r=None):
    return get_data_all(
        get_depth_data_name(),
        r=r
    )


def get_depth_data(ex_name, base, quote, r=None):
    if not r:
        r = get_redis_conn()
    key = '{ex_name}:{base}:{quote}'.format(ex_name=ex_name, base=base, quote=quote)
    data = r.hget(get_depth_data_name(), key)
    if isinstance(data, str):
        data = literal_eval(data)
    return data


def get_account_data_all(r=None):
    return get_data_all(
        get_account_data_name(),
        r=r
    )


def get_account_data(ex_name, account_name, r=None):
    if not r:
        r = get_redis_conn()
    key = '{ex_name}:{account_name}'.format(ex_name=ex_name, account_name=account_name)
    data = r.hget(get_account_data_name(), key)
    if isinstance(data, str):
        data = literal_eval(data)
    return data


def get_ticker_sub(r=None):
    if not r:
        r = get_redis_conn()
    return get_sub_info(
        r,
        get_sub_ticker_name()
    )


def set_ticker_sub(ex_name, base, quote, value=1, r=None):
    if not r:
        r = get_redis_conn()
    return set_value(
        r,
        get_sub_ticker_name(),
        ex_name,
        base,
        quote,
        value
    )


def set_ticker_data(ex_name, base, quote, value=None, r=None):
    if not r:
        r = get_redis_conn()
    if not value:
        value = dict()
    return set_value(
        r,
        get_ticker_data_name(),
        ex_name,
        base,
        quote,
        value
    )


def get_trades_sub(r=None):
    if not r:
        r = get_redis_conn()
    return get_sub_info(
        r,
        get_sub_trades_name()
    )


def set_trades_sub(ex_name, base, quote, value=1, r=None):
    if not r:
        r = get_redis_conn()
    return set_value(
        r,
        get_sub_trades_name(),
        ex_name,
        base,
        quote,
        value
    )


def set_trades_data(ex_name, base, quote, value=None, r=None):
    if not r:
        r = get_redis_conn()
    if not value:
        value = dict()
    return set_value(
        r,
        get_trades_data_name(),
        ex_name,
        base,
        quote,
        value
    )


def set_account_data(ex_name, account_name, value=None, r=None):
    if not r:
        r = get_redis_conn()
    if not value:
        value = dict()
    key = '{ex_name}:{account_name}'.format(ex_name=ex_name, account_name=account_name)
    r.hset(
        get_account_data_name(),
        key,
        value
    )


class RedisDB(object):
    def __init__(self):
        self.__r = get_redis_conn()

    def is_connected(self):
        if isinstance(self.__r, redis.client.StrictRedis):
            if self.__r.ping():
                return True
        return False

    def get_connection(self):
        return self.__r

    def reconnect(self):
        self.__r = get_redis_conn()

    def __get_sub_info(self, sub_name):
        return get_sub_info(self.__r, sub_name)

    def set_value(self, sub_name, ex_name, base, quote, value):
        return set_value(self.__r, sub_name, ex_name, base, quote, value)

    def get_kline_sub(self):
        return get_kline_sub(self.__r)

    def set_kline_sub(self, ex_name, base, quote, period, value=1):
        return set_kline_sub(ex_name, base, quote, period, value=value, r=self.__r)

    def set_kline_data(self, ex_name, base, quote, period, value=None):
        return set_kline_data(ex_name, base, quote, period, value=value, r=self.__r)

    def get_depth_sub(self):
        return get_depth_sub(self.__r)

    def set_depth_sub(self, ex_name, base, quote, value=1):
        return set_depth_sub(ex_name, base, quote, value=value, r=self.__r)

    def set_depth_data(self, ex_name, base, quote, value=None):
        return set_depth_data(ex_name, base, quote, value=value, r=self.__r)

    def get_ticker_sub(self):
        return get_ticker_sub(self.__r)

    def set_ticker_sub(self, ex_name, base, quote, value=1):
        return set_ticker_sub(ex_name, base, quote, value=value, r=self.__r)

    def set_ticker_data(self, ex_name, base, quote, value=None):
        return set_ticker_data(ex_name, base, quote, value=value, r=self.__r)

    def get_trades_sub(self):
        return get_trades_sub(self.__r)

    def set_trades_sub(self, ex_name, base, quote, value=1):
        return set_trades_sub(ex_name, base, quote, value=value, r=self.__r)

    def set_trades_data(self, ex_name, base, quote, value=None):
        return set_trades_data(ex_name, base, quote, value=value, r=self.__r)

    def get_account_sub(self):
        return get_account_sub(self.__r)

    def set_account_sub(self, ex_name, account_name, value=1):
        return set_account_sub(ex_name, account_name, value=value, r=self.__r)

    def set_account_data(self, ex_name, account_name, value):
        return set_account_data(ex_name, account_name, value=value, r=self.__r)

    def get_account_info(self, ex_name, account_name):
        return get_account_cfg(ex_name=ex_name, acct_name=account_name, r=self.__r)

    def set_account_attribute(self, ex_name, account_name, attribute_name, attribute_value):
        acct_cfg = self.get_account_info(ex_name, account_name)
        acct_cfg.update({attribute_name: attribute_value})
        set_account_cfg(ex_name, account_name, acct_cfg, r=self.__r)

    def get_account_attribute(self, ex_name, account_name, attribute_name):
        data = get_account_cfg(ex_name, account_name, r=self.__r)
        if attribute_name in data.keys():
            return data[attribute_name]
        else:
            return {}

    def set_account_access_key(self, ex_name, account_name, access_key):
        self.set_account_attribute(
            ex_name, account_name,
            attribute_name='access_key',
            attribute_value=access_key
        )

    def set_account_secret_key(self, ex_name, account_name, secret_key):
        self.set_account_attribute(
            ex_name, account_name,
            attribute_name='secret_key',
            attribute_value=secret_key
        )

    def get_account_access_key(self, ex_name, account_name):
        return self.get_account_attribute(ex_name, account_name, 'access_key')

    def get_account_secret_key(self, ex_name, account_name):
        return self.get_account_attribute(ex_name, account_name, 'secret_key')

    def set_account_cfg_info(self, ex_name, account_name, acct_cfg=None):
        return set_account_cfg(ex_name, account_name, acct_cfg, r=self.__r)

    def get_account_data_all(self):
        return get_account_data_all(r=self.__r)

    def get_account_data(self, ex_name, account_name):
        return get_account_data(ex_name, account_name, r=self.__r)

    def get_depth_data_all(self):
        return get_depth_data_all(r=self.__r)

    def get_depth_data(self, ex_name, base, quote):
        return get_depth_data(ex_name, base, quote, r=self.__r)

    def get_account_cfg_all(self):
        return get_account_cfg_all(r=self.__r)




#
from pprint import pprint
# set_depth_sub('huobipro', 'btc', 'usdt', 1)
# pprint(get_depth_sub())
# print(sys.argv[0])
# print(os.path.abspath(os.path.curdir))
#
# r = get_redis_conn()
# r.set('name', 'lloyg')
# print(r.get('name'))