#!/usr/bin/env python
# -*- coding: utf-8 -*-
# @Time    : 15/11/2017 12:39 AM
# @Author  : Lloyd Lee
# @File    : restful.py

import time
import urllib.parse
import urllib.request
import base64
import datetime
import hashlib
import hmac
import urllib
import urllib.parse
import urllib.request
import json

from ex_api.rest_api import *


REST_MARKET_DATA_URL = "https://api.huobi.pro"  # restful api market data url
REST_AUTH_URL = "https://api.huobi.pro"  # restful api authenticated url

COIN_NAME_CONVERTER = {
    'bch': 'bcc',
}


class RestAPI(RestBaseAPI):
    ALL_MARKETS = {'ast': {'btc': {'amount_precision': 0, 'price_precision': 8}},
                     'bat': {'btc': {'amount_precision': 0, 'price_precision': 8},
                             'eth': {'amount_precision': 0, 'price_precision': 8}},
                     'bcd': {'btc': {'amount_precision': 4, 'price_precision': 6}},
                     'bch': {'btc': {'amount_precision': 4, 'price_precision': 6},
                             'usdt': {'amount_precision': 4, 'price_precision': 2}},
                     'bcx': {'btc': {'amount_precision': 4, 'price_precision': 8}},
                     'bt1': {'btc': {'amount_precision': 4, 'price_precision': 6}},
                     'bt2': {'btc': {'amount_precision': 4, 'price_precision': 6}},
                     'btc': {'usdt': {'amount_precision': 4, 'price_precision': 2}},
                     'btg': {'btc': {'amount_precision': 4, 'price_precision': 6}},
                     'btm': {'btc': {'amount_precision': 0, 'price_precision': 8},
                             'eth': {'amount_precision': 0, 'price_precision': 8}},
                     'cmt': {'btc': {'amount_precision': 0, 'price_precision': 8},
                             'eth': {'amount_precision': 0, 'price_precision': 8}},
                     'cvc': {'btc': {'amount_precision': 0, 'price_precision': 8},
                             'eth': {'amount_precision': 0, 'price_precision': 8}},
                     'dash': {'btc': {'amount_precision': 4, 'price_precision': 6},
                              'usdt': {'amount_precision': 4, 'price_precision': 2}},
                     'dgd': {'btc': {'amount_precision': 4, 'price_precision': 6},
                             'eth': {'amount_precision': 4, 'price_precision': 6}},
                     'elf': {'btc': {'amount_precision': 0, 'price_precision': 8},
                             'eth': {'amount_precision': 0, 'price_precision': 8}},
                     'eos': {'btc': {'amount_precision': 2, 'price_precision': 8},
                             'eth': {'amount_precision': 2, 'price_precision': 8},
                             'usdt': {'amount_precision': 4, 'price_precision': 2}},
                     'etc': {'btc': {'amount_precision': 4, 'price_precision': 6},
                             'usdt': {'amount_precision': 4, 'price_precision': 2}},
                     'eth': {'btc': {'amount_precision': 4, 'price_precision': 6},
                             'usdt': {'amount_precision': 4, 'price_precision': 2}},
                     'gnt': {'btc': {'amount_precision': 0, 'price_precision': 8},
                             'eth': {'amount_precision': 0, 'price_precision': 8}},
                     'hsr': {'btc': {'amount_precision': 4, 'price_precision': 6},
                             'eth': {'amount_precision': 4, 'price_precision': 6},
                             'usdt': {'amount_precision': 4, 'price_precision': 2}},
                     'itc': {'btc': {'amount_precision': 0, 'price_precision': 8},
                             'eth': {'amount_precision': 0, 'price_precision': 8}},
                     'knc': {'btc': {'amount_precision': 0, 'price_precision': 8}},
                     'ltc': {'btc': {'amount_precision': 4, 'price_precision': 6},
                             'usdt': {'amount_precision': 4, 'price_precision': 2}},
                     'mana': {'btc': {'amount_precision': 0, 'price_precision': 8},
                              'eth': {'amount_precision': 0, 'price_precision': 8}},
                     'mco': {'btc': {'amount_precision': 4, 'price_precision': 6},
                             'eth': {'amount_precision': 4, 'price_precision': 6}},
                     'mtl': {'btc': {'amount_precision': 4, 'price_precision': 6}},
                     'omg': {'btc': {'amount_precision': 4, 'price_precision': 6},
                             'eth': {'amount_precision': 4, 'price_precision': 6},
                             'usdt': {'amount_precision': 4, 'price_precision': 2}},
                     'pay': {'btc': {'amount_precision': 4, 'price_precision': 6},
                             'eth': {'amount_precision': 4, 'price_precision': 6}},
                     'qash': {'btc': {'amount_precision': 4, 'price_precision': 8},
                              'eth': {'amount_precision': 4, 'price_precision': 6}},
                     'qsp': {'btc': {'amount_precision': 0, 'price_precision': 8},
                             'eth': {'amount_precision': 0, 'price_precision': 8}},
                     'qtum': {'btc': {'amount_precision': 4, 'price_precision': 6},
                              'eth': {'amount_precision': 4, 'price_precision': 6},
                              'usdt': {'amount_precision': 4, 'price_precision': 2}},
                     'rcn': {'btc': {'amount_precision': 0, 'price_precision': 8},
                             'eth': {'amount_precision': 0, 'price_precision': 8}},
                     'rdn': {'btc': {'amount_precision': 0, 'price_precision': 8},
                             'eth': {'amount_precision': 0, 'price_precision': 8}},
                     'salt': {'btc': {'amount_precision': 4, 'price_precision': 6},
                              'eth': {'amount_precision': 4, 'price_precision': 6}},
                     'sbtc': {'btc': {'amount_precision': 4, 'price_precision': 6}},
                     'smt': {'btc': {'amount_precision': 0, 'price_precision': 8},
                             'eth': {'amount_precision': 0, 'price_precision': 8}},
                     'snt': {'btc': {'amount_precision': 0, 'price_precision': 8}},
                     'storj': {'btc': {'amount_precision': 2, 'price_precision': 8}},
                     'tnb': {'btc': {'amount_precision': 0, 'price_precision': 8},
                             'eth': {'amount_precision': 0, 'price_precision': 8}},
                     'tnt': {'btc': {'amount_precision': 0, 'price_precision': 8},
                             'eth': {'amount_precision': 0, 'price_precision': 8}},
                     'ven': {'btc': {'amount_precision': 2, 'price_precision': 8},
                             'eth': {'amount_precision': 2, 'price_precision': 8}},
                     'wax': {'btc': {'amount_precision': 4, 'price_precision': 8},
                             'eth': {'amount_precision': 4, 'price_precision': 6}},
                     'xrp': {'btc': {'amount_precision': 0, 'price_precision': 8},
                             'usdt': {'amount_precision': 0, 'price_precision': 4}},
                     'zec': {'btc': {'amount_precision': 4, 'price_precision': 6},
                             'usdt': {'amount_precision': 4, 'price_precision': 2}},
                     'zrx': {'btc': {'amount_precision': 0, 'price_precision': 8}}}

    def __init__(self,
                 access_key=None,
                 secret_key=None
                 ):
        super(RestAPI, self).__init__(
            access_key=access_key,
            secret_key=secret_key
        )
        self.__market_data_url = REST_MARKET_DATA_URL
        self.__auth_url = REST_AUTH_URL
        self.__spot_acct_id = None

    @classmethod
    def to_symbol(cls, base, quote):
        base = cls.convert_coin_name(base.lower())
        quote = cls.convert_coin_name(quote.lower())
        symbol = base.lower() + quote.lower()
        return symbol

    @classmethod
    def convert_coin_name(cls, name):
        if name in COIN_NAME_CONVERTER.keys():
            return COIN_NAME_CONVERTER[name]
        else:
            return name

    @classmethod
    def get_kline(
            cls,
            base,
            quote,
            period=None,
            size=None,
            **kwargs
    ):
        """
        :type base: str
        :type quote: str
        :type period: str
        :type size: int
        :return:
        """
        symbol = cls.to_symbol(base, quote)
        period = period or '1min'
        size = size or '150'
        params = {'symbol': symbol, 'period': period, 'size': size}
        url = REST_MARKET_DATA_URL + '/market/history/kline'
        return http_get(url, params)

    @classmethod
    def get_all_markets(cls):
        url = REST_MARKET_DATA_URL + '/v1/common/symbols'
        params = dict()
        data = http_get(url, params)
        parsed_data = dict()
        if isinstance(data, dict) and 'status' in data.keys() and data['status'] == 'ok':
            for market in data['data']:
                base = market['base-currency']
                quote = market['quote-currency']
                if base not in parsed_data.keys():
                    parsed_data.update(
                        {
                            base: dict()
                        }
                    )
                parsed_data[base].update(
                    {
                        quote: {
                            'price_precision': market['price-precision'],
                            'amount_precision': market['amount-precision']
                        }
                    }
                )
        return parsed_data

    @classmethod
    def get_depth(
            cls,
            base,
            quote,
            size=None,
            **kwargs
    ):
        symbol = cls.to_symbol(base, quote)
        precision = 'step0'
        params = {'symbol': symbol, 'type': precision}
        url = REST_MARKET_DATA_URL + '/market/depth'
        request_time = int(round(time.time() * 1000))
        data = http_get(url, params)
        parsed_data = dict()
        if isinstance(data, dict) and 'status' in data.keys() and data['status'] == 'ok':
            parsed_data.update({md_kw.STATUS: APIRetStatus.SUCCESS})
            parsed_data.update({md_kw.SERVER_TIME: data['ts']})
            parsed_data.update({md_kw.CLIENT_TIME: request_time})
            bids = data['tick']['bids']
            asks = data['tick']['asks']
            if size:
                bids = bids[:size]
                asks = asks[:size]
            parsed_data.update({md_kw.ASKS: asks})
            parsed_data.update({md_kw.BIDS: bids})
        else:
            parsed_data.update({md_kw.STATUS: APIRetStatus.OTHER})
            parsed_data.update({md_kw.ERROR_MSG: data})
        return parsed_data

    @classmethod
    def get_last_trade(
            cls,
            base,
            quote,
    ):
        """
        :type base: str
        :type quote: str
        :return:
        """
        symbol = cls.to_symbol(base, quote)
        params = {'symbol': symbol}
        url = REST_MARKET_DATA_URL + '/market/trade'
        return http_get(url, params)

    @classmethod
    def get_trades(
            cls,
            base,
            quote,
            size=None,
            **kwargs
    ):
        """
        :type base: str
        :type quote: str
        :type size: int
        :return:
        """
        symbol = cls.to_symbol(base, quote)
        size = size or '100'
        params = {'symbol': symbol, 'size': size}
        url = REST_MARKET_DATA_URL + '/market/history/trade'
        return http_get(url, params)

    @classmethod
    def get_price_precision(cls, base, quote):
        base = base.lower()
        quote = quote.lower()
        if base in cls.ALL_MARKETS.keys() and quote in cls.ALL_MARKETS[base].keys():
            return int(cls.ALL_MARKETS[base][quote]['price_precision'])
        else:
            cls.ALL_MARKETS = cls.get_all_markets()
            if base in cls.ALL_MARKETS.keys() and quote in cls.ALL_MARKETS[base].keys():
                return int(cls.ALL_MARKETS[base][quote]['price_precision'])
            else:
                raise Exception('Pair {base}-{quote} not exist'.format(base=base, quote=quote))

    @classmethod
    def get_qty_precision(cls, base, quote):
        pass

    @staticmethod
    def create_sign(param, method, host_url, request_path, secret_key):
        encode_params = urllib.parse.urlencode(param)
        payload = [method, host_url, request_path, encode_params]
        payload = '\n'.join(payload)
        payload = payload.encode(encoding='UTF8')
        secret_key = secret_key.encode(encoding='UTF8')
        digest = hmac.new(secret_key, payload, digestmod=hashlib.sha256).digest()
        signature = base64.b64encode(digest)
        signature = signature.decode()
        return signature

    def api_key_get(self, params, request_path):
        if not self._check_key():
            return
        method = 'GET'
        params['AccessKeyId'] = self.get_access_key()
        params['SignatureMethod'] = 'HmacSHA256'
        params['SignatureVersion'] = '2'
        params['Timestamp'] = datetime.datetime.utcnow().strftime('%Y-%m-%dT%H:%M:%S')
        host_name = urllib.parse.urlparse(self.__auth_url).hostname
        host_name = host_name.lower()
        sorted_params = sorted(params.items(), key=lambda d: d[0], reverse=False)
        params['Signature'] = self.create_sign(sorted_params, method, host_name, request_path, self.get_secret_key())
        url = self.__auth_url + request_path
        return http_get(url, params)

    def api_key_post(self, params, request_path):
        if not self._check_key():
            return
        method = 'POST'
        params_to_sign = dict()
        params_to_sign['AccessKeyId'] = self.get_access_key()
        params_to_sign['SignatureMethod'] = 'HmacSHA256'
        params_to_sign['SignatureVersion'] = '2'
        params_to_sign['Timestamp'] = datetime.datetime.utcnow().strftime('%Y-%m-%dT%H:%M:%S')
        host_url = self.__auth_url
        host_name = urllib.parse.urlparse(host_url).hostname
        host_name = host_name.lower()
        sorted_params = sorted(params_to_sign.items(), key=lambda d: d[0], reverse=False)
        params_to_sign['Signature'] = self.create_sign(sorted_params, method, host_name, request_path, self.get_secret_key())
        url = host_url + request_path + '?' + urllib.parse.urlencode(params_to_sign)
        headers = {
            "Accept": "application/json",
            'Content-Type': 'application/json',
            'User-agent': 'Mozilla 5.10',
        }
        params = json.dumps(params)
        return http_post(url, params, headers=headers)

    def get_accounts_all(self, acct_type="spot"):
        if not self._check_key():
            return
        path = "/v1/account/accounts"
        params = dict()
        if acct_type:
            params["type"] = acct_type
        return self.api_key_get(params, path)

    def get_spot_acct_id(self):
        if not self.__spot_acct_id:
            data = self.get_accounts_all()
            spot_id = data['data'][0]['id']
            self.__spot_acct_id = str(spot_id)
        return self.__spot_acct_id

    def get_balances(
            self,
            acct_id=None
    ):
        if not self._check_key():
            return
        if not acct_id:
            acct_id = self.get_spot_acct_id()
        else:
            acct_id = str(acct_id)
        url = "/v1/account/accounts/" + acct_id + "/balance"
        params = dict()
        params["account-id"] = acct_id
        request_time = int(round(time.time() * 1000))
        data = self.api_key_get(params, url)
        parsed_data = dict()
        if isinstance(data, dict) and data['status'] == 'ok':
            parsed_data.update({au_kw.STATUS: APIRetStatus.SUCCESS})
            parsed_data.update({au_kw.SERVER_TIME: request_time})
            parsed_data.update({au_kw.CLIENT_TIME: int(round(time.time() * 1000))})
            balance_data = dict()
            for balance in data['data']['list']:
                coin_type = balance['currency']
                if coin_type == 'bcc':
                    coin_type = 'bch'
                qty = float(balance['balance'])
                if balance['type'] == 'trade':
                    type_name = au_kw.AVAILABLE
                elif balance['type'] == 'frozen':
                    type_name = au_kw.FROZEN
                else:
                    type_name = balance['type']
                if coin_type not in balance_data.keys():
                    balance_data.update({coin_type: dict()})
                balance_data[coin_type].update({type_name: qty})
            for currency, info in balance_data.items():
                total = balance_data[currency][au_kw.AVAILABLE] + balance_data[currency][au_kw.FROZEN]
                balance_data[currency].update({au_kw.TOTAL: total})
            parsed_data.update({au_kw.BALANCE: balance_data})
        return parsed_data

    @classmethod
    def to_order_status_code(cls, status):
        if status in ['pre-submitted', 'submitted']:
            return OrderStatus.SUBMITTED
        elif status == 'partial-filled':
            return OrderStatus.PARTIAL_FILLED
        elif status == 'partial-canceled':
            return OrderStatus.PARTIAL_FILLED_CANCELLED
        elif status == 'filled':
            return OrderStatus.FULLY_FILLED
        elif status == 'canceled':
            return OrderStatus.CANCELLED

    @classmethod
    def symbol_to_base_quote(cls, symbol):
        base = symbol[:3]
        quote = symbol[3:]
        return base, quote

    @classmethod
    def order_type_side(cls, order_type):
        o_side, o_type = order_type.split('-')
        if o_side == 'buy':
            o_side = OrderSide.BUY
        elif o_side == 'sell':
            o_side = OrderSide.SELL
        if o_type == 'limit':
            o_type = OrderType.LIMIT_ORDER
        elif o_type == 'market':
            o_type = OrderType.MARKET_ORDER
        return o_side, o_type

    def format_order(self, data):
        parsed_data = dict()
        parsed_data.update({o_kw.ORDER_CREATE_TIME: data['created-at']})
        parsed_data.update({o_kw.FEES: float(data['field-fees'])})
        order_status = self.to_order_status_code(data['state'])
        parsed_data.update({o_kw.ORDER_STATUS: order_status})
        if order_status in [OrderStatus.CANCELLED, OrderStatus.PARTIAL_FILLED_CANCELLED]:
            parsed_data.update({o_kw.ORDER_FINISH_TIME: data['canceled-at']})
        elif order_status in [OrderStatus.FULLY_FILLED]:
            parsed_data.update({o_kw.ORDER_FINISH_TIME: data['finished-at']})
        base, quote = self.symbol_to_base_quote(data['symbol'])
        parsed_data.update({au_kw.BASE: base})
        parsed_data.update({au_kw.QUOTE: quote})
        parsed_data.update({o_kw.ORDER_ID: str(data['id'])})
        order_type, order_side = self.order_type_side(data['type'])
        parsed_data.update({o_kw.ORDER_TYPE: order_type})
        parsed_data.update({o_kw.ORDER_SIDE: order_side})
        parsed_data.update({o_kw.ORDER_PRICE: float(data['price'])})
        if order_type is OrderType.MARKET_ORDER and order_side is OrderSide.BUY:
            parsed_data.update({o_kw.ORDER_CASH_AMOUNT: float(data['amount'])})
        else:
            parsed_data.update({o_kw.ORDER_QTY: float(data['amount'])})
        parsed_data.update({o_kw.DEAL_QTY: float(data['field-amount'])})
        parsed_data.update({o_kw.DEAL_AMT: float(data['field-cash-amount'])})
        return parsed_data

    def get_order_info(
            self,
            order_id,
            base=None,
            quote=None,
            **kwargs
    ):
        if not self._check_key():
            return
        url = "/v1/order/orders/" + str(order_id)
        params = dict()
        request_time = int(round(time.time() * 1000))
        data = self.api_key_get(params, url)
        parsed_data = dict()
        if isinstance(data, dict) and data['status'] == 'ok':
            parsed_data.update({au_kw.STATUS: APIRetStatus.SUCCESS})
            parsed_data.update({au_kw.SERVER_TIME: request_time})
            parsed_data.update({au_kw.CLIENT_TIME: int(round(time.time() * 1000))})
            parsed_data.update(
                self.format_order(data['data'])
            )
        return parsed_data

    def place_order(
            self,
            base,
            quote,
            order_type,
            qty,
            price=None,
            source='api'
    ):
        if not self._check_key():
            return
        url = "/v1/order/orders/place"
        params = dict()
        symbol = self.to_symbol(base, quote)
        if source is 'api':
            params.update({'account-id': self.get_spot_acct_id()})
        else:
            raise ValueError
        params.update({'symbol': symbol})
        params.update({'amount': str(qty)})
        if price:
            params.update({'price': str(price)})
        params.update({'type': order_type})
        params.update({'source': source})
        request_time = int(round(time.time() * 1000))
        ret = self.api_key_post(params, url)
        parsed_data = dict()
        if isinstance(ret, dict) and 'status' in ret.keys() and ret['status'] == 'ok':
            parsed_data.update({au_kw.STATUS: APIRetStatus.SUCCESS})
            parsed_data.update({o_kw.ORDER_CREATE_TIME: request_time})
            parsed_data.update({o_kw.ORDER_STATUS: OrderStatus.SUBMITTED})
            parsed_data.update({au_kw.SERVER_TIME: request_time})
            parsed_data.update({au_kw.CLIENT_TIME: int(round(time.time() * 1000))})
            parsed_data.update({au_kw.BASE: base})
            parsed_data.update({au_kw.QUOTE: quote})
            parsed_data.update({o_kw.ORDER_ID: int(ret['data'])})
        return parsed_data

    def cancel_order(
            self,
            order_id
    ):
        params = dict()
        if not isinstance(order_id, str):
            order_id = str(order_id)
        url = "/v1/order/orders/" + order_id + "/submitcancel"
        try:
            ret = self.api_key_post(params, url)
            if ret['status'] == 'ok':
                return True
            else:
                order_info = self.get_order_info(order_id)
                if order_info['order_status'] in [OrderStatus.CANCELLED,
                                                  OrderStatus.FULLY_FILLED,
                                                  OrderStatus.PARTIAL_FILLED_CANCELLED]:
                    return True
                else:
                    return False
        except Exception:
            return False

    def cancel_all_orders(self, order_id_list):
        params = dict()
        params["order-ids"] = order_id_list
        url = "/v1/order/orders/batchcancel"
        return self.api_key_post(params, url)

    def get_orders_info_list(
            self,
            base,
            quote,
            states,
            order_type=None,
            start_date=None,
            end_date=None,
            id_from=None,
            record_size=None,
    ):
        """

        :param base:
        :param quote:
        :param states:  str, 查询的订单状态组合，使用','分割
                        pre-submitted 准备提交, submitted 已提交, partial-filled 部分成交,
                        partial-canceled 部分成交撤销, filled 完全成交, canceled 已撤销
        :param order_type:
        :param start_date:
        :param end_date:
        :param id_from:
        :param record_size:
        :return:
        """
        params = dict()
        params['symbol'] = self.to_symbol(base, quote)
        params['states'] = states
        if order_type:
            params['type'] = order_type
        if start_date:
            params['start-date'] = start_date
        if end_date:
            params['end-date'] = end_date
        if id_from:
            params['from'] = id_from
        if record_size:
            params['size'] = record_size
        url = '/v1/order/orders'
        request_time = int(round(time.time() * 1000))
        data = self.api_key_get(params, url)
        parsed_data = list()
        if isinstance(data, dict) and data['status'] == 'ok':
            for order_info in data['data']:
                order_data = dict()
                order_data.update({au_kw.STATUS: APIRetStatus.SUCCESS})
                order_data.update({au_kw.SERVER_TIME: request_time})
                order_data.update({au_kw.CLIENT_TIME: int(round(time.time() * 1000))})
                order_data.update(
                    self.format_order(order_info)
                )
                parsed_data.append(order_data)
        return parsed_data

    def get_active_orders(
            self,
            base,
            quote,
            order_type=None,
            start_date=None,
            end_date=None,
            id_from=None,
            record_size=None,
    ):
        return self.get_orders_info_list(
            base,
            quote,
            states='pre-submitted,submitted,partial-filled',
            order_type=order_type,
            start_date=start_date,
            end_date=end_date,
            id_from=id_from,
            record_size=record_size
        )

    def cancel_all_active_orders(
            self,
            base,
            quote,
            order_type=None,
            start_date=None,
            end_date=None,
            id_from=None,
            record_size=None,
    ):
        order_info_list = self.get_active_orders(
            base,
            quote,
            order_type=order_type,
            start_date=start_date,
            end_date=end_date,
            id_from=id_from,
            record_size=record_size,
        )
        id_list = list()
        for order_info in order_info_list:
            id_list.append(order_info[o_kw.ORDER_ID])
        return self.cancel_all_orders(id_list)










api = RestAPI()
from pprint import pprint
# # print(api.get_kline('btc', 'usdt'))
# # pprint(api.get_depth('btc', 'usdt'))
# # print(api.get_trades('btc', 'usdt'))
# # pprint(api.get_orders_info_list('btc', 'usdt', 'canceled'))
# # pprint(api.get_order_info('313035575', 'btc', 'usdt'))
# # b=api.get_balances()['balance']
# # print(b)
# # print(api.place_order('btc', 'usdt', 'buy-limit', 0.001, price=1))
# # print(api.place_order('btc', 'usdt', 'buy-limit', 0.001, price=1))
# # print(api.get_spot_acct_id())
# # for coin_type in b.keys():
# #     if b[coin_type]['total'] > 0:
# #         print(coin_type, '：', b[coin_type]['total'])
# # order = api.place_order('btc', 'usdt', 'buy-limit', 0.001, price=1)
# # pprint(len(api.get_active_orders('btc', 'usdt')))
# # pprint(api.get_order_info(381684613))
# # print(api.cancel_order(381684613))
# # print(api.place_order('btc', 'usdt', 'buy-limit', 0.001, price=1))
# active_orders = api.get_active_orders('btc', 'usdt')
# pprint(active_orders)
# order_ids = [order['order_id'] for order in active_orders]
# api.cancel_all_orders(order_ids)
# active_orders = api.get_active_orders('btc', 'usdt')
# pprint(active_orders)
# pprint(api.get_balances())
# pprint(api.get_all_markets())
# pprint(api.get_price_precision('xrp', 'usdt'))
# pprint(api.cancel_all_active_orders('btc', 'usdt'))