#!/usr/bin/env python
# -*- coding: utf-8 -*-
# @Time    : 15/11/2017 1:45 AM
# @Author  : Lloyd Lee
# @File    : format.py


depth = {
    'ex_name': 'huobi_pro',
    'base': 'btc',
    'quote': 'usdt',
    'bids': [[], []],  # 高到低
    'asks': [[], []],  # 低到高
}