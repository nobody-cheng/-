#!/usr/bin/env python
# -*- coding: utf-8 -*-
# @Time    : 20/10/2017 12:07 PM
# @Author  : Lloyd Lee
# @File    : rest_api.py


from abc import ABCMeta, abstractmethod

from utils.utils import http_get, http_post
from utils.utils import MarketDataKeyWords as md_kw
from utils.utils import AccountDataKeyWords as au_kw
from utils.utils import APIRetStatus
from utils.utils import OrderStatus
from utils.utils import OrderDataKeyWords as o_kw
from utils.utils import OrderType, OrderSide


class RestBaseAPI(object):
    metaclass = ABCMeta

    def __init__(
            self,
            access_key=None,
            secret_key=None
    ):
        self.__access_key = access_key
        self.__secret_key = secret_key

    def set_access_key(
            self,
            access_key
    ):
        self.__access_key = access_key

    def set_secret_key(
            self,
            secret_key
    ):
        self.__secret_key = secret_key

    def get_access_key(self):
        return self.__access_key

    def get_secret_key(self):
        return self.__secret_key

    def _check_key(self):
        if self.__access_key is None:
            raise ValueError('Missing access_key.')
        if self.__secret_key is None:
            raise ValueError('Missing secret_key.')
        return True

    @classmethod
    def get_kline(
            cls,
            base,
            quote,
            period=None,
            size=None,
            dataframe=False,
            **kwargs
    ):
        """
        Get k-line info of base/quote pair
        :param base:
        :param quote:
        :param period: '1min', '5min', '15min', '30min', '1h', '3h', '6h', '12h', '1d',
        :param size:
        :param kwargs:
        :return:
        """
        raise NotImplementedError

    @classmethod
    def get_depth(
            cls,
            base,
            quote,
            size=None,
            **kwargs
    ):
        raise NotImplementedError

    @classmethod
    def get_ticker(
            cls,
            base,
            quote,
            **kwargs
    ):
        raise NotImplementedError

    @classmethod
    def get_trades(
            cls,
            base,
            quote,
            size=None,
            **kwargs
    ):
        raise NotImplementedError

    @classmethod
    def get_latest_price(
            cls,
            base,
            quote,
            **kwargs
    ):
        raise NotImplementedError

    def get_balances(
            self
    ):
        raise NotImplementedError

    def get_order_info(
            self,
            order_id,
            base=None,
            quote=None,
            **kwargs
    ):
        raise NotImplementedError
