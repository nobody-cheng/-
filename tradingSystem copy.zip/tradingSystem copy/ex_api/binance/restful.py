#!/usr/bin/env python
# -*- coding: utf-8 -*-
# @Time    : 25/11/2017 5:24 PM
# @Author  : Lloyd Lee
# @File    : restful.py
import hmac
import time
from urllib.parse import urlencode

import pandas as pd
import hashlib
import requests

from ex_api.rest_api import *
# from utils.utils import http_post


REST_MARKET_DATA_URL = "https://api.binance.com"  # restful api market data url
REST_AUTH_URL = "https://api.binance.com"  # restful api authenticated url


COIN_NAME_CONVERTER = {

}


class RestAPI(RestBaseAPI):
    PRIVATE_API_VERSION = 'v3'
    PUBLIC_API_VERSION = 'v1'

    def __init__(self,
                 access_key=None,
                 secret_key=None):
        super(RestAPI, self).__init__(access_key=access_key, secret_key=secret_key)
        self.__market_data_url = REST_MARKET_DATA_URL
        self.__auth_url = REST_AUTH_URL
        self.session = self._init_session()

    def _init_session(self):

        session = requests.session()
        session.headers.update({'Accept': 'application/json',
                                'User-Agent': 'binance/python',
                                'X-MBX-APIKEY': self.get_access_key()})
        return session

    @classmethod
    def to_symbol(cls, base, quote):
        symbol = base.upper() + quote.upper()
        return symbol

    @classmethod
    def get_kline(
            cls,
            base,
            quote,
            period=None,
            size=None,
            **kwargs
    ):
        """
        :type base: str
        :type quote: str
        :type period: str
        :type size: int
        :return:
        """
        symbol = cls.to_symbol(base, quote)
        period_str = {
            '1min': '1m',
            '5min': '5m',
            '15min': '15m',
            '30min': '30m',
            '1h': '1h',
            '2h': '2h',
            '4h': '4h',
            '6h': '6h',
            '8h': '8h',
            '12h': '12h',
            '1d': '1d'
        }
        size = size or '500'
        params = {'symbol': symbol, 'limit': size}
        if not period:
            params.update({'interval': '1m'})
        elif period in period_str.keys():
            params.update({'interval': period_str[period]})
        else:
            raise ValueError(
                "Parameter Error: [period] can only be "
                "'1min', '5min', '15min', '30min', '1h', '3h', '6h', '12h', '1d'"
            )
        if 'start' in kwargs.keys():
            params.update({'startTime': int(kwargs['start'])})
        if 'end' in kwargs.keys():
            params.update({'endTime': int(kwargs['end'])})
        url = REST_MARKET_DATA_URL + '/api/v1/klines'
        data = http_get(url, params)
        parsed_data = dict()
        # if isinstance()

        return data

    # TODO: only complete get_kline function

    @classmethod
    def get_depth(
            cls,
            base,
            quote,
            size=None,
            dataframe=False,
            **kwargs
    ):
        """
        :type base: str
        :type quote: str
        :return:
        """
        symbol = cls.to_symbol(base, quote)
        if not size:
            size = 100
        params = {'symbol': symbol, 'limit': size}
        url = REST_MARKET_DATA_URL + '/api/v1/depth'
        server_time = int(round(time.time() * 1000))
        data = http_get(url, params)
        parsed_data = dict()
        if isinstance(data, dict) and 'asks' in data.keys():
            parsed_data.update({md_kw.STATUS: APIRetStatus.SUCCESS})
            parsed_data.update({md_kw.SERVER_TIME: server_time})
            parsed_data.update({md_kw.CLIENT_TIME: int(round(time.time() * 1000))})
            bids = [[float(bid[0]), float(bid[1])] for bid in data['bids']]
            asks = [[float(ask[0]), float(ask[1])] for ask in data['asks']]
            parsed_data.update({md_kw.ASKS: asks})
            parsed_data.update({md_kw.BIDS: bids})
        return parsed_data

    @classmethod
    def get_last_trade(
            cls,
            base,
            quote,
    ):
        """
        :type base: str
        :type quote: str
        :return:
        """
        symbol = cls.to_symbol(base, quote)
        params = {'symbol': symbol}
        url = REST_MARKET_DATA_URL + '/market/trade'
        return http_get(url, params)

    @classmethod
    def get_trades(
            cls,
            base,
            quote,
            size=None,
            **kwargs
    ):
        """
        :type base: str
        :type quote: str
        :type size: int
        :return:
        """
        symbol = cls.to_symbol(base, quote)
        size = size or '100'
        params = {'symbol': symbol, 'size': size}
        url = REST_MARKET_DATA_URL + '/market/history/trade'
        return http_get(url, params)

    def _auth_get(self, params):
        pass

    def _generate_signature(self, data):
        query_string = urlencode(data)
        m = hmac.new(self.get_secret_key().encode('utf-8'), query_string.encode('utf-8'), hashlib.sha256)
        return m.hexdigest()

    def _request(self, method, uri, signed, force_params=False, **kwargs):
        data = kwargs.get('data', None)
        if data and isinstance(data, dict):
            kwargs['data'] = data
        if signed:
            kwargs['data']['timestamp'] = int(time.time() * 1000)
            kwargs['data']['signature'] = self._generate_signature(kwargs['data'])
        if data and (method == 'get' or force_params):
            kwargs['params'] = self._order_params(kwargs['data'])
            del(kwargs['data'])
        response = getattr(self.session, method)(uri, **kwargs)
        return self._handle_response(response)

    def _handle_response(self, response):
        """Internal helper for handling API responses from the Binance server.
        Raises the appropriate exceptions when necessary; otherwise, returns the
        response.
        """
        if not str(response.status_code).startswith('2'):
            raise Exception(response)
        try:
            return response.json()
        except ValueError:
            raise Exception('Invalid Response: %s' % response.text)

    def _order_params(self, data):
        """Convert params to list with signature as last element

        :param data:
        :return:

        """
        has_signature = False
        params = []
        for key, value in data.items():
            if key == 'signature':
                has_signature = True
            else:
                params.append((key, value))
        if has_signature:
            params.append(('signature', data['signature']))
        return params

    def _sign(self, params=None):
        if not params:
            params = dict()
        data = params.copy()
        ts = str(int(1000 * time.time()))
        data.update({"timestamp": ts})
        query_string = urlencode(data)
        signature = hmac.new(self.get_secret_key().encode('utf-8'), query_string.encode('utf-8'), hashlib.sha256)
        data.update({"signature": signature.hexdigest()})
        return data

    def _get(self, path, params=None):
        if not params:
            params = dict()
        params.update({"recvWindow": 120000})
        query = urlencode(self._sign(params))
        url = "%s?%s" % (path, query)
        header = {"X-MBX-APIKEY": self.get_access_key()}
        response = requests.get(url, headers=header, timeout=5, verify=True)
        if response.status_code == 200:
            return response.json()
        else:
            raise Exception("HTTP GET failed, detail is:%s" % response.text)

    def _post(self, path, params=None):
        if not params:
            params = dict()
        params.update({"recvWindow": 120000})
        query = urlencode(self._sign(params))
        url = "%s?%s" % (path, query)
        header = {"X-MBX-APIKEY": self.get_access_key()}
        response = requests.post(url, headers=header, timeout=5, verify=True)
        if response.status_code == 200:
            return response.json()
        else:
            raise Exception("HTTP POST failed, detail is:%s" % response.text)

    def _delete(self, path, params=None):
        if not params:
            params = dict()
        params.update({"recvWindow": 120000})
        query = urlencode(self._sign(params))
        url = "%s?%s" % (path, query)
        header = {"X-MBX-APIKEY": self.get_access_key()}
        response = requests.delete(url, headers=header, timeout=5, verify=True)
        if response.status_code == 200:
            return response.json()
        else:
            raise Exception("HTTP DELETE failed, detail is:%s" % response.text)

    def get_balances(
            self
    ):
        path = "%s/api/v3/account" % self.__auth_url
        data = self._get(path, {})
        request_time = int(round(time.time() * 1000))
        parsed_data = dict()
        if isinstance(data, dict) and 'balances' in data.keys():
            parsed_data.update({au_kw.STATUS: APIRetStatus.SUCCESS})
            parsed_data.update({au_kw.SERVER_TIME: request_time})
            parsed_data.update({au_kw.CLIENT_TIME: int(data['updateTime'])})
            balance_data = dict()
            for balance in data['balances']:
                coin_type = balance['asset'].lower()
                qty_available = float(balance['free'])
                qty_frozen = float(balance['locked'])
                qty_total = qty_available + qty_frozen
                balance_data.update(
                    {
                        coin_type: {
                            au_kw.AVAILABLE: qty_available,
                            au_kw.FROZEN: qty_frozen,
                            au_kw.TOTAL: qty_total
                        }
                    }
                )
            parsed_data.update({au_kw.BALANCE: balance_data})
        return parsed_data

    class OrderType(object):
        LIMIT = 'LIMIT'
        MARKET = 'MARKET'
        STOP_LOSS = 'STOP_LOSS'
        STOP_LOSS_LIMIT = 'STOP_LOSS_LIMIT'
        TAKE_PROFIT = 'TAKE_PROFIT'
        TAKE_PROFIT_LIMIT = 'TAKE_PROFIT_LIMIT'
        LIMIT_MAKER = 'LIMIT_MAKER'

    def place_order(
            self,
            base,
            quote,
            side,
            order_type,
            qty,
            price=None,
            *kwargs
    ):
        symbol = self.to_symbol(base, quote)
        path = '%s/api/v3/order' % self.__auth_url
        params = dict()
        params.update(kwargs)
        params.update(
            {
                'symbol': symbol,
                'side': side,
                'type': order_type,
                'quantity': qty
            }
        )
        if price:
            params.update({'price': price})
        return self._post(path, params)







api = RestAPI()
from pprint import pprint
# pprint(api.get_kline('btc', 'usdt'))
# pprint(api.get_depth('btc', 'usdt'))
# print(api.get_access_key())
# pprint(api.get_balances())
pprint(api.place_order('btc', 'usdt', 'SELL', 'MARKET', 0.001))