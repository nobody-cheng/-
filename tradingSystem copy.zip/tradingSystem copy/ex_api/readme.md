#Wrapper of Exchanges


##How to Use

###Example

`````python
from ex_api.exchange import Exchange
huobipro = Exchange('huobipro')
huobipro_api = huobipro.get_api()
print(huobipro_api.get_kline('btc', 'usdt'))

`````

##How to Add A New Wrapper

1. Set Exchange Name  
Add new exchange name key-value pair in `ex_api.exchange.ExchangeNames`. For example: `OKEX = 'okex'`.  
_Key_ must be the same with _Value_.
2. Add New Package  
Add a new package in `ex_api`.   
The package name must the same with the exchange name value set in previous step.
3. Implementation of Wrapper  
There must be a python file named `restful.py`, and a class named `RestAPI`, which extends `RestBaseAPI`. Implement the wrapper in this class.


##API 

###1.Get Depth
Get most recent order book information - including bid and ask price and volume.
```python
    def get_depth(
            cls,
            base,
            quote,
            size=None,
            **kwargs
    ):
```
####Parameters
| Parameter   |  Description | Type   |
| ---- | ---- | ---- |
 | base | base currency | str |
 | quote | quote currency | str |
 |size| size of return bid/asks data|int
 ####Return
Return a dict data like:
 ```python
{
 'c_ts': 17365,
 's_ts': 1512726900831,
 'status': 0
 'bids': [
    [100, 0.1],
    [99.8, 0.05],
    ...
 ],
 'asks': [
    [101, 2.3],
    [102, 3.4],
    ...
 ]
}
```
In the returned data,

 | Name   |  Description | Type   |
| ---- | ---- | ---- |
| c_ts | client timestamp, in millisecond | int |
| s_ts | server timestamp, in millisecond | int |
| bids | bids list, descending order by price| list, like [[price, volume], ...] |
| askds | asks list, ascending order by price| list, like [[price, volume], ...] |
 

 



###2.Get Kline
###3.Get Ticker
###4.Get Trades
###5.Get Account Balance