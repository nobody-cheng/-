#!/usr/bin/env python
# -*- coding: utf-8 -*-
# @Time    : 25/11/2017 3:04 PM
# @Author  : Lloyd Lee
# @File    : restful.py


import urllib
import urllib.parse
import time
import hmac
import hashlib

import requests
import pandas as pd

from utils.utils import http_get

from ex_api.rest_api import RestBaseAPI


REST_MARKET_DATA_URL = 'https://poloniex.com/public'
REST_AUTH_URL = 'https://poloniex.com/tradingApi'


# def http_get(url, params, headers=None):
#     if not headers:
#         headers = {
#             "Content-type": "application/x-www-form-urlencoded",
#         }
#     payload = urllib.parse.urlencode(params)
#     response = requests.get(url, payload, headers=headers, timeout=10)
#     if response.status_code == 200:
#         return response.json()
#     else:
#         raise Exception("httpGet failed, detail is:%s" % response.text)


def create_sign(params, secret_key):
    secret_key = secret_key.encode(encoding='utf-8')
    params = urllib.parse.urlencode(params).encode(encoding='utf-8')
    sign = hmac.new(secret_key, params, hashlib.sha512).hexdigest()
    return sign


def post_headers(params, access_key, secret_key):
    sign = create_sign(params, secret_key)
    headers = {
        'Sign': sign,
        'Key': access_key
    }
    return headers


def http_post(url, params, access_key, secret_key, nonce=None):
    nonce = nonce or int(time.time() * 150000000)
    params['nonce'] = nonce
    headers = post_headers(params, access_key, secret_key)
    response = requests.post(url, params, headers=headers, timeout=10)
    if response.status_code == 200:
        return response.json()
    else:
        raise Exception("httpPost failed, detail is:%s" % response.text)


def generate_symbol(coin_type, currency):
    coin_type = coin_type.upper()
    currency = currency.upper()
    symbol = currency + '_' + coin_type
    return symbol


def get_ticker():
    params = dict()
    params['command'] = 'returnTicker'
    return http_get(REST_MARKET_DATA_URL, params)


def get_depth(coin_type=None, currency=None, depth=10000):
    if not coin_type or not currency:
        symbol = 'all'
    else:
        symbol = generate_symbol(coin_type, currency)
    params = dict()
    params['command'] = 'returnOrderBook'
    params['currencyPair'] = symbol
    if depth:
        params['depth'] = depth
    return http_get(REST_MARKET_DATA_URL, params)


def get_24volume():
    params = dict()
    params['command'] = 'return24hVolume'
    return http_get(REST_MARKET_DATA_URL, params)


def get_market_trade_history(coin_type, currency):
    symbol = generate_symbol(coin_type, currency)
    params = dict()
    params['command'] = 'returnTradeHistory'
    params['currencyPair'] = symbol
    return http_get(REST_MARKET_DATA_URL, params)


def get_kline(coin_type, currency, freq, start_time=None, end_time=None):
    """
    :param freq: valid: 300(5min), 900(15min), 1800(30min), 7200(2hour), 14400(4hour), and 86400(1day)
    """
    symbol = generate_symbol(coin_type, currency)
    params = dict()
    params['command'] = 'returnChartData'
    params['currencyPair'] = symbol
    params['start'] = start_time or time.time()
    params['end'] = end_time or '9999999999'
    params['period'] = freq
    return http_get(REST_MARKET_DATA_URL, params)


def balances(access_key, secret_key):
    """
    :return: Returns all of your available balances
    """
    params = dict()
    params['command'] = 'returnBalances'
    return http_post(REST_AUTH_URL, params, access_key, secret_key)


def complete_balances(access_key, secret_key, account=None):
    """
    :return: Returns all of your balances, including available balance, balance on orders, and the estimated BTC value
        of your balance. By default, this call is limited to your exchange account; set the "account" POST parameter
        to "all" to include your margin and lending accounts.
    """
    params = dict()
    params['command'] = 'returnCompleteBalances'
    if account:
        params['account'] = account
    return http_post(REST_AUTH_URL, params, access_key, secret_key)


def get_active_orders(access_key, secret_key, coin_type=None, currency=None):
    if not coin_type or not currency:
        symbol = 'all'
    else:
        symbol = generate_symbol(coin_type, currency)
    params = dict()
    params['command'] = 'returnOpenOrders'
    params['currencyPair'] = symbol
    return http_post(REST_AUTH_URL, params, access_key, secret_key)


def get_trade_history(access_key, secret_key, coin_type=None, currency=None, start=None, end=None):
    """
    Returns your trade history for a given market, specified by the "currencyPair" POST parameter. You may specify
        "all" as the currencyPair to receive your trade history for all markets. You may optionally specify a range
        via "start" and/or "end" POST parameters, given in UNIX timestamp format; if you do not specify a range,
        it will be limited to one day.
    """
    if not coin_type or not currency:
        symbol = 'all'
    else:
        symbol = generate_symbol(coin_type, currency)
    params = dict()
    params['command'] = 'returnTradeHistory'
    params['currencyPair'] = symbol
    if start:
        params['start'] = start
    if end:
        params['end'] = end
    return http_post(REST_AUTH_URL, params, access_key, secret_key)


def get_order_trades_info(access_key, secret_key, order_number):
    """
    只查询有成交的order记录。未成交的，不会有信息
    """
    params = dict()
    params['command'] = 'returnOrderTrades'
    params['orderNumber'] = order_number
    return http_post(REST_AUTH_URL, params, access_key, secret_key)


def buy(access_key, secret_key, coin_type, currency, rate, amount):
    """
    limit buy
    """
    symbol = generate_symbol(coin_type, currency)
    params = dict()
    params['command'] = 'buy'
    params['currencyPair'] = symbol
    params['rate'] = rate
    params['amount'] = amount
    return http_post(REST_AUTH_URL, params, access_key, secret_key)


def sell(access_key, secret_key, coin_type, currency, rate, amount):
    """
    limit sell
    """
    symbol = generate_symbol(coin_type, currency)
    params = dict()
    params['command'] = 'sell'
    params['currencyPair'] = symbol
    params['rate'] = rate
    params['amount'] = amount
    return http_post(REST_AUTH_URL, params, access_key, secret_key)


def cancel_order(access_key, secret_key, order_number):
    params = dict()
    params['command'] = 'cancelOrder'
    params['orderNumber'] = order_number
    return http_post(REST_AUTH_URL, params, access_key, secret_key)


class RestAPI(RestBaseAPI):
    def __init__(self,
                 access_key=None,
                 secret_key=None):
        super(RestAPI, self).__init__(access_key=access_key, secret_key=secret_key)
        self.__market_data_url = REST_MARKET_DATA_URL
        self.__auth_url = REST_AUTH_URL

    @classmethod
    def to_symbol(cls, base, quote):
        base = base.upper()
        quote = quote.upper()
        symbol = quote + '_' + base
        return symbol

    @classmethod
    def coin_type_currency_from_symbol(cls, symbol):
        """
        return cointype, currency
        :param symbol: string like 'BTC_ETH'
        :return: tuple like 'eth', 'btc'
        """
        coin_type, currency = symbol.split('_')
        return coin_type.lower(), currency.lower()

    @classmethod
    def get_kline(
            cls,
            base,
            quote,
            period=None,
            size=None,
            dataframe=False,
            **kwargs
    ):
        """

        :return: [[mts, open, close, high, low, volume], ..., ...]
        """

        period_str = {
            '5min': 300,
            '15min': 900,
            '2h': 7200,
            '4h': 14400,
            '1d': 86400
        }
        symbol = cls.to_symbol(base, quote)
        params = dict()
        params['command'] = 'returnChartData'
        params['currencyPair'] = symbol
        if not period:
            params.update({'period': 300})
        elif period in period_str.keys():
            params.update({'period': period_str[period]})
        else:
            raise ValueError(
                "Parameter Error: [period] can only be "
                "[300, 900, 7200, 14400, 86400]"
            )
        if 'start' in kwargs.keys():
            params.update({'start': int(kwargs['start']/1000)})
        else:
            params.update({'start': time.time() - 60*60*24*30})
        if 'end' in kwargs.keys():
            params.update({'end': int(kwargs['end']/1000)})
        else:
            params.update({'end': 9999999999})
        ret = http_get(REST_MARKET_DATA_URL, params)
        if isinstance(ret, list):
            ret = pd.DataFrame(ret)
            ret['date'] = ret['date'] * 1000
            ret = ret.set_index('date')
            ret.index.names = ['time']
        return ret


    # TODO: only complete get_kline function

    @classmethod
    def get_ticker(cls):
        return get_ticker()

    @classmethod
    def get_market_trade_history(cls, coin_type, currency):
        return get_market_trade_history(coin_type, currency)

    # @classmethod
    # def get_depth(cls, coin_type, currency):
    #     return get_depth(coin_type=coin_type, currency=currency)