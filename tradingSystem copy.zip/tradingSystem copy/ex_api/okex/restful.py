#!/usr/bin/env python
# -*- coding: utf-8 -*-
# @Time    : 28/11/2017 8:29 PM
# @Author  : Lloyd Lee
# @File    : restful.py
import hashlib

import pandas as pd
import time

from ex_api.rest_api import RestBaseAPI
from utils.utils import http_get, APIRetStatus
from utils.utils import http_post
from utils.utils import MarketDataKeyWords as md_kw
from utils.utils import AccountDataKeyWords as au_kw


REST_MARKET_DATA_URL = "https://www.okex.com/api/v1"  # restful api market data url
REST_AUTH_URL = "https://www.okex.com/api/v1"  # restful api authenticated url


class RestAPI(RestBaseAPI):
    def __init__(self,
                 access_key=None,
                 secret_key=None):
        super(RestAPI, self).__init__(access_key=access_key, secret_key=secret_key)
        self.__market_data_url = REST_MARKET_DATA_URL
        self.__auth_url = REST_AUTH_URL

    @classmethod
    def to_symbol(cls, base, quote):
        symbol = base.lower() + '_' + quote.lower()
        return symbol

    @classmethod
    def get_kline(
            cls,
            base,
            quote,
            period=None,
            size=None,
            dataframe=False,
            **kwargs
    ):
        symbol = cls.to_symbol(base, quote)
        period_str = {
            '1min': '1min',
            '3min': '3min',
            '5min': '5min',
            '30min': '30min',
            '1h': '1hour',
            '2h': '2hour',
            '4h': '4hour',
            '6h': '6hour',
            '12h': '12h',
            '1d': '1day',
            '3d': '3day',
            '1w': '1week',
        }
        params = {'symbol': symbol}
        if not period:
            params.update({'type': '1min'})
        elif period in period_str.keys():
            params.update({'type': period_str[period]})
        else:
            raise ValueError(
                "Parameter Error: [period] can only be "
                "'1min', '5min', '15min', '30min', '1h', '3h', '6h', '12h', '1d'"
            )
        if 'start' in kwargs.keys():
            params.update({'since': int(kwargs['start'])})
        if 'szie' in kwargs.keys():
            params.update({'size': int(kwargs['size'])})
        url = REST_MARKET_DATA_URL + '/kline.do'
        ret = http_get(url, params)
        if isinstance(ret, list):
            ret = pd.DataFrame(ret,
                               columns=['time', 'open', 'high', 'low', 'close', 'volume'],
                               dtype=float
                               )
            ret = ret.set_index('time')
        return ret

    @classmethod
    def get_depth(
            cls,
            base,
            quote,
            size=None,
            dataframe=False,
            **kwargs
    ):
        symbol = cls.to_symbol(base, quote)
        params = {'symbol': symbol}
        if 'szie' in kwargs.keys():
            params.update({'size': int(kwargs['size'])})
        url = REST_MARKET_DATA_URL + '/depth.do'
        ret = http_get(url, params)
        if isinstance(ret, dict) and 'asks' in ret.keys():
            bids = pd.DataFrame(ret['bids'], columns=['price', 'volume'], dtype=float)
            asks = pd.DataFrame(ret['asks'], columns=['price', 'volume'], dtype=float)
            ret = bids, asks
        return ret

    @classmethod
    def create_sign(cls, params, secretKey):
        sign = ''
        for key in sorted(params.keys()):
            sign += key + '=' + str(params[key]) + '&'
        data = sign + 'secret_key=' + secretKey
        return hashlib.md5(data.encode("utf8")).hexdigest().upper()

    def get_balances(
            self
    ):
        url = self.__auth_url + "/userinfo.do"
        params = dict()
        params['api_key'] = self.get_access_key()
        params['sign'] = self.create_sign(params, self.get_secret_key())
        data = http_post(url, params)
        request_time = int(round(time.time() * 1000))
        parsed_data = dict()
        if isinstance(data, dict) and data['result']:
            parsed_data.update({au_kw.STATUS: APIRetStatus.SUCCESS})
            parsed_data.update({au_kw.SERVER_TIME: request_time})
            parsed_data.update({au_kw.CLIENT_TIME: int(round(time.time() * 1000))})
            balance_data = dict()
            for acct_type, coin_list in data['info']['funds'].items():
                if acct_type == 'borrow':
                    acct_type = au_kw.BORROW
                elif acct_type == 'free':
                    acct_type = au_kw.AVAILABLE
                elif acct_type == 'freezed':
                    acct_type = au_kw.FROZEN
                for coin_type, qty in coin_list.items():
                    if coin_type not in balance_data.keys():
                        balance_data.update({coin_type: dict()})
                    balance_data[coin_type].update({acct_type: float(qty)})
            for currency, info in balance_data.items():
                total = balance_data[currency][au_kw.AVAILABLE] + balance_data[currency][au_kw.FROZEN]
                balance_data[currency].update({au_kw.TOTAL: total})
            parsed_data.update({au_kw.BALANCE: balance_data})
        return parsed_data
