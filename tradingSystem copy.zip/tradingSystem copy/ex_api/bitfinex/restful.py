#!/usr/bin/env python
# -*- coding: utf-8 -*-
# @Time    : 25/11/2017 1:28 PM
# @Author  : Lloyd Lee
# @File    : restful.py

import pandas as pd

from ex_api.rest_api import RestBaseAPI
from utils.utils import http_get


REST_MARKET_DATA_URL = "https://api.bitfinex.com/v2"  # restful api market data url
REST_AUTH_URL = ""  # restful api authenticated url

COIN_NAME_CONVERTER = {
    'dash': 'dsh'
}


class RestAPI(RestBaseAPI):
    def __init__(self,
                 access_key=None,
                 secret_key=None):
        super(RestAPI, self).__init__(access_key=access_key, secret_key=secret_key)
        self.__market_data_url = REST_MARKET_DATA_URL
        self.__auth_url = REST_AUTH_URL

    @classmethod
    def to_symbol(cls, base, quote, trading=True):
        base = cls.convert_coin_name(base.lower())
        quote = cls.convert_coin_name(quote.lower())
        symbol = base.upper() + quote.upper()
        if trading:
            symbol = 't{symbol}'.format(symbol=symbol)
        else:
            symbol = 'f{symbol}'.format(symbol=symbol)
        return symbol

    @classmethod
    def convert_coin_name(cls, name):
        if name in COIN_NAME_CONVERTER.keys():
            return COIN_NAME_CONVERTER[name]
        else:
            return name

    @classmethod
    def get_kline(
            cls,
            base,
            quote,
            period=None,
            size=None,
            dataframe=False,
            **kwargs
    ):
        """
        :type base: str
        :type quote: str
        :type period: str
        :type size: int
        :return:
        """
        # '1m', '5m', '15m', '30m', '1h', '3h', '6h', '12h', '1D',
        symbol = cls.to_symbol(base, quote)
        period_str = {
            '1min': '1m',
            '5min': '5m',
            '15min': '15m',
            '30min': '30m',
            '1h': '1h',
            '3h': '3h',
            '6h': '6h',
            '12h': '12h',
            '1d': '1D'
        }
        if not period:
            period = '1m'
        elif period in period_str.keys():
            period = period_str[period]
        else:
            raise ValueError(
                "Parameter Error: [period] can only be "
                "['1min', '5min', '15min', '30min', '1h', '3h', '6h', '12h', '1d']"
            )
        size = size or '150'
        params = {
            'limit': size,
            'sort': 1
        }
        if 'start' in kwargs.keys():
            params.update(
                {'start': kwargs['start']}
            )
        if 'end' in kwargs.keys():
            params.update(
                {'end': kwargs['end']}
            )
        url = '{url}/candles/trade:{period}:{symbol}/hist'.format(url=REST_MARKET_DATA_URL,
                                                                  period=period,
                                                                  symbol=symbol)
        ret = http_get(url, params)
        if dataframe and isinstance(ret, list) and len(ret)>0:
            ret = pd.DataFrame(ret, columns=['time', 'open', 'close', 'high', 'low', 'volume'])
            ret = ret.set_index('time')
        return ret

    # TODO: only complete get_kline function

    @classmethod
    def get_depth(
            cls,
            base,
            quote,
            size=None,
            dataframe=False,
            **kwargs
    ):
        """
        :type base: str
        :type quote: str
        :return:
        """
        symbol = cls.to_symbol(base, quote)
        precision = 'step0'
        params = {'symbol': symbol, 'type': precision}
        url = REST_MARKET_DATA_URL + '/market/depth'
        return http_get(url, params)

    @classmethod
    def get_last_trade(
            cls,
            base,
            quote,
    ):
        """
        :type base: str
        :type quote: str
        :return:
        """
        symbol = cls.to_symbol(base, quote)
        params = {'symbol': symbol}
        url = REST_MARKET_DATA_URL + '/market/trade'
        return http_get(url, params)

    @classmethod
    def get_trades(
            cls,
            base,
            quote,
            size=None,
            **kwargs
    ):
        """
        :type base: str
        :type quote: str
        :type size: int
        :param kwargs:
            start: start timestamp (ms)
            end: end timestamp (ms)
        :return:
        """
        symbol = cls.to_symbol(base, quote)
        size = size or '100'
        params = {
            'symbol': symbol,
            'size': size
        }
        url = REST_MARKET_DATA_URL + '/market/history/trade'
        return http_get(url, params)




# api = HuobiRestAPI()

# print(api.get_kline('btc', 'usdt'))
# print(api.get_depth('btc', 'usdt'))
# print(api.get_trades('btc', 'usdt'))
