#!/usr/bin/env python
# -*- coding: utf-8 -*-
# @Time    : 19/11/2017 2:54 AM
# @Author  : Lloyd Lee
# @File    : exchange.py

import importlib
from enum import Enum, unique

from ex_api.rest_api import RestBaseAPI


@unique
class ExchangeNames(Enum):
    HUOBIPRO = 'huobipro'
    OKEX = 'okex'
    OKEXFUTURE = 'okexfuture'
    BITFINEX = 'bitfinex'
    POLONIEX = 'poloniex'
    ZB = 'zb'
    BINANCE = 'binance'


class Exchange(object):
    def __init__(self,
                 ex_name,
                 access_key=None,
                 secret_key=None
                 ):
        self.__ex_name = ex_name
        self.__ex_name_verify()
        self.__access_key = access_key
        self.__secret_key = secret_key
        self.__api = None
        self.__auth_api = None

    def __ex_name_verify(self):
        if isinstance(self.__ex_name, ExchangeNames):
            return True
        if isinstance(self.__ex_name, str):
            ex_name = str.upper(self.__ex_name)
            try:
                self.__ex_name = getattr(ExchangeNames, ex_name).value
                return True
            except AttributeError:
                raise ValueError("ex_name value error: [%s]" % self.__ex_name)
        raise TypeError("ex_name value type error: must be str or ex_api.ExchangeNames")

    def __set_api(self):
        if not self.__api:
            imp_module = importlib.import_module("ex_api.%s.restful" % self.__ex_name)
            self.__api = imp_module.RestAPI(self.__access_key, self.__secret_key)

    def get_api(self):
        self.__set_api()
        if isinstance(self.__api, RestBaseAPI):
            return self.__api
        else:
            raise ValueError("No api for exchange: [%s]" % str(self.__ex_name))

    def get_name(self):
        return self.__ex_name

# ex_name = 'huobipro'
# huobi = Exchange(ex_name)
# api = huobi.get_api()
# # print(api.get_kline('btc', 'usdt'))
# print(api.get_depth('btc', 'usdt'))
# # print(type(api))


# ex_name = 'bitfinex'
# ex = Exchange(ex_name)
# api = ex.get_api()
# print(api.get_kline('btc', 'usd', size=2))
# print(api.get_depth('btc', 'usdt'))
# print(type(api))
#
# ex_name = 'poloniex'
# ex = Exchange(ex_name)
# api = ex.get_api()
# print(api.get_kline('btc', 'usdt'))

# ex_name = 'binance'
# ex = Exchange(ex_name)
# api = ex.get_api()
# print(api.get_kline('btc', 'usdt'))
# print(api.get_depth('btc', 'usdt'))

# ex_name = 'zb'
# ex = Exchange(ex_name)
# api = ex.get_api()
# print(api.get_kline('btc', 'usdt'))

# ex_name = 'okex'
# ex = Exchange(ex_name)
# api = ex.get_api()
# # print(api.get_kline('btc', 'usdt'))
# print(api.get_depth('btc', 'usdt', size=1))

# ex_name = 'okexfuture'
# ex = Exchange(ex_name)
# api = ex.get_api()
# # print(api.get_kline('btc', 'usdt'))
# print(api.get_depth('btc', 'usd', size=2))

