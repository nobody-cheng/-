#!/usr/bin/env python
# -*- coding: utf-8 -*-
# @Time    : 27/11/2017 12:38 PM
# @Author  : Lloyd Lee
# @File    : restful.py


import hashlib
import hmac
import time
import urllib
import urllib.parse
from collections import OrderedDict

import requests
import pandas as pd

from ex_api.rest_api import RestBaseAPI

REST_MARKET_DATA_URL = "http://api.zb.com/data/v1"
REST_AUTH_URL = "https://trade.zb.com/api"


class RestAPI(RestBaseAPI):
    def __init__(self,
                 access_key=None,
                 secret_key=None):
        super(RestAPI, self).__init__(access_key=access_key, secret_key=secret_key)
        self.__market_data_url = REST_MARKET_DATA_URL
        self.__auth_url = REST_AUTH_URL

    @classmethod
    def get_kline(
            cls,
            base,
            quote,
            period=None,
            size=None,
            dataframe=False,
            **kwargs
    ):
        symbol = cls.to_symbol(base, quote)
        period_str = {
            '1min': '1min',
            '5min': '5min',
            '15min': '15min',
            '30min': '30min',
            '1h': '1hour',
            '2h': '2hour',
            '4h': '4hour',
            '6h': '6hour',
            '12h': '12hour',
            '1d': '1day'
        }

        params = dict()
        params['market'] = symbol
        if not period:
            params.update({'type': '1min'})
        elif period in period_str.keys():
            params.update({'type': period_str[period]})
        if 'start' in kwargs.keys():
            params.update({'since': int(kwargs['start'])})
        if 'end' in kwargs.keys():
            params.update({'endTime': int(kwargs['end'])})
        if size:
            params['size'] = size
        url = REST_MARKET_DATA_URL + '/kline'
        ret = http_request(url, params)
        if isinstance(ret, dict) and 'data' in ret.keys():
            ret = pd.DataFrame(ret['data'],
                               columns=['time', 'open', 'high', 'low', 'close', 'volume'],
                               dtype=float
                               )
            ret = ret.set_index('time')
        return ret

    @classmethod
    def to_symbol(cls, coin_type, currency):
        symbol = '{}_{}'.format(coin_type, currency)
        return symbol

    @classmethod
    def get_ticker(cls, coin_type, currency):
        symbol = cls.to_symbol(coin_type, currency)
        return ticker(symbol)

    @classmethod
    def get_depth(cls, coin_type, currency, size=None,
            dataframe=False, merge=None):
        symbol = cls.to_symbol(coin_type, currency)
        return depth(symbol, size=size, merge=merge)

    @classmethod
    def get_trades(cls, coin_type, currency, t_from=None):
        symbol = cls.to_symbol(coin_type, currency)
        return trades(symbol, since=t_from)

    def get_acct_info(self, access_key=None, secret_key=None):
        if not access_key:
            access_key = self._access_key
        if not secret_key:
            secret_key = self._secret_key
        return get_account_info(access_key, secret_key)

    def place_order(self, coin_type, currency, price, amount, trade_type, access_key=None, secret_key=None):
        if not access_key:
            access_key = self._access_key
        if not secret_key:
            secret_key = self._secret_key
        symbol = self.to_symbol(coin_type, currency)
        return order(access_key, secret_key, price=price, amount=amount, trade_type=trade_type, symbol=symbol)

    def buy_limit(self, coin_type, currency, price, amount, access_key=None, secret_key=None):
        trade_type = '1'
        return self.place_order(coin_type, currency, price, amount, trade_type, access_key=access_key, secret_key=secret_key)

    def sell_limit(self, coin_type, currency, price, amount, access_key=None, secret_key=None):
        trade_type = '0'
        return self.place_order(coin_type, currency, price, amount, trade_type, access_key=access_key, secret_key=secret_key)

    def get_order_info(self, coin_type, currency, order_id, access_key=None, secret_key=None):
        if not access_key:
            access_key = self._access_key
        if not secret_key:
            secret_key = self._secret_key
        symbol = self.to_symbol(coin_type, currency)
        return get_order_info(access_key, secret_key, order_id, symbol=symbol)

    def get_orders(self, coin_type, currency, page_index=None, page_size=None, access_key=None, secret_key=None):
        """
        获取最进的订单，包括0：待成交,1：取消,2：交易完成,3：待成交未交易部份
        """
        if not access_key:
            access_key = self._access_key
        if not secret_key:
            secret_key = self._secret_key
        symbol = self.to_symbol(coin_type, currency)
        return get_orders(access_key, secret_key, symbol=symbol, page_index=page_index, page_size=page_size)

    def get_actvie_orders(self, coin_type, currency, page_index=None, page_size=None, access_key=None, secret_key=None):
        if not access_key:
            access_key = self._access_key
        if not secret_key:
            secret_key = self._secret_key
        symbol = self.to_symbol(coin_type, currency)
        return get_active_orders(access_key, secret_key, symbol=symbol, page_index=page_index, page_size=page_size)

    def cancel_order(self, coin_type, currency, order_id, access_key=None, secret_key=None):
        if not access_key:
            access_key = self._access_key
        if not secret_key:
            secret_key = self._secret_key
        symbol = self.to_symbol(coin_type, currency)
        return cancel_order(access_key, secret_key, order_id=order_id, symbol=symbol)


def http_request(url, params, headers=None):
    time.sleep(0.2)
    if not headers:
        headers = {
            "Content-type": "application/x-www-form-urlencoded",
        }
    payload = urllib.parse.urlencode(params)
    response = requests.get(url, payload, headers=headers, timeout=10)
    if response.status_code == 200:
        return response.json()
    else:
        raise Exception("httpPost failed, detail is:%s" % response.text)

def ticker(symbol):
    """
    :param symbol: btc_cny, ltc_cny, eth_cny, etc_cny
    :return:
            {
                "ticker": {
                    "high": "0.033153",
                    "low": "0.030352",
                    "buy": "0.030728",
                    "sell": "0.030751",
                    "last": "0.030729",
                    "vol": "838.98"
                }
            }
    """
    params = dict()
    params['currency'] = symbol
    url = REST_MARKET_DATA_URL + '/ticker'
    return http_request(url, params)


def depth(symbol, size=None, merge=None):
    """
    :param symbol: btc_cny, ltc_cny, eth_cny, etc_cny
    :param size: 1 - 50
    :param merge: merge depth
        btc_cny : 可选1,0.1
        ltc_cny : 可选0.5,0.3,0.1
        eth_cny : 可选0.5,0.3,0.1
        etc_cny : 可选0.3,0.1
    :return:
        {
            "asks": [
                [
                    83.28, # price
                    11.8 # volume
                ]...
            ],
            "bids": [
                [
                    81.91,
                    3.65
                ]...
            ],
            "timestamp" :
        }
    """
    params = dict()
    params['currency'] = symbol
    if size:
        params['size'] = size
    if merge:
        params['merge'] = merge
    url = REST_MARKET_DATA_URL + '/depth'
    return http_request(url, params)


def trades(symbol, since=None):
    """
    :param symbol:
    :param since: time after this timestamp
    :return:
            [
                {
                    "amount": 0.541,
                    "date": 1472711925,
                    "price": 81.87,
                    "tid": 16497097,
                    "trade_type": "ask",
                    "type": "sell"
                }...
            ]
    """
    params = dict()
    params['currency'] = symbol
    if since:
        params['since'] = since
    url = REST_MARKET_DATA_URL + '/trades'
    return http_request(url, params)


def kline(symbol, freq=None, since=None, size=None):
    """
    :param symbol:
    :param freq:    1min : 1分钟
                    3min : 3分钟
                    5min : 5分钟
                    15min : 15分钟
                    30min : 30分钟
                    1day : 1日
                    3day : 3日
                    1week : 1周
                    1hour : 1小时
                    2hour : 2小时
                    4hour : 4小时
                    6hour : 6小时
                    12hour : 12小时
    :param since: timestamp. Get kline data after this timestamp
    :param size: max 1000
    :return:
                {
                    "data": [
                        [
                            1472107500000,
                            3840.46,
                            3843.56,
                            3839.58,
                            3843.3,
                            492.456
                        ]...
                    ],
                    "moneyType": "cny",
                    "symbol": "btc"
                }
    """
    params = dict()
    params['currency'] = symbol
    if freq:
        params['type'] = freq
    if since:
        params['since'] = since
    if size:
        params['size'] = size
    url = REST_MARKET_DATA_URL + '/kline'
    return http_request(url, params)


def get_account_info(access_key, secret_key):
    params = OrderedDict()
    params['method'] = 'getAccountInfo'
    params['accesskey'] = access_key
    url = REST_AUTH_URL + '/getAccountInfo'
    return secret_request(params, url, secret_key)


def order(access_key, secret_key, price, amount, trade_type, symbol):
    params = OrderedDict()
    params['method'] = 'order'
    params['accesskey'] = access_key
    params['price'] = price
    params['amount'] = amount
    params['tradeType'] = trade_type
    params['currency'] = symbol
    url = REST_AUTH_URL + '/order'
    return secret_request(params, url, secret_key)


def cancel_order(access_key, secret_key, order_id, symbol):
    params = OrderedDict()
    params['method'] = 'order'
    params['accesskey'] = access_key
    params['id'] = order_id
    params['currency'] = symbol
    url = REST_AUTH_URL + '/cancelOrder'
    return secret_request(params, url, secret_key)


def get_order_info(access_key, secret_key, order_id, symbol):
    params = OrderedDict()
    params['method'] = 'order'
    params['accesskey'] = access_key
    params['id'] = order_id
    params['currency'] = symbol
    url = REST_AUTH_URL + '/getOrder'
    return secret_request(params, url, secret_key)


def get_orders(access_key, secret_key, symbol, page_index, page_size):
    params = OrderedDict()
    params['method'] = 'getOrdersIgnoreTradeType'
    params['accesskey'] = access_key
    params['currency'] = symbol
    if not page_index:
        page_index = 1
    params['pageIndex'] = page_index
    if not page_size:
        page_size = 200
    params['pageSize'] = page_size
    url = REST_AUTH_URL + '/getOrdersIgnoreTradeType'
    return secret_request(params, url, secret_key)


def get_active_orders(access_key, secret_key, symbol, page_index, page_size):
    params = OrderedDict()
    params['method'] = 'getUnfinishedOrdersIgnoreTradeType'
    params['accesskey'] = access_key
    params['currency'] = symbol
    if not page_index:
        page_index = 1
    params['pageIndex'] = page_index
    if not page_size:
        page_size = 200
    params['pageSize'] = page_size
    url = REST_AUTH_URL + '/getUnfinishedOrdersIgnoreTradeType'
    return secret_request(params, url, secret_key)

def add_other_params(params, secret_key):
    if not params:
        params = OrderedDict()
    params['sign'] = create_sign(params, secret_key)
    params['reqTime'] = int(time.time()*1000)
    return params


def create_sign(params, secret_key):
    sha_secret = hashlib.sha1(secret_key.encode('utf-8')).hexdigest()
    message = urllib.parse.urlencode(params)
    sign = hmac.new(sha_secret.encode('utf-8'), message.encode('utf-8'), hashlib.md5).hexdigest()
    return sign


def secret_request(params, url, secret_key):
    if not params:
        params = OrderedDict()
    params = add_other_params(params, secret_key)
    return http_request(url, params)
