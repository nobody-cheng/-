#!/usr/bin/env python
# -*- coding: utf-8 -*-
# @Time    : 25/11/2017 3:54 PM
# @Author  : Lloyd Lee
# @File    : volatility.py

import pandas

from ex_api.exchange import Exchange


def get_vol(ex_name, base, quote, start_time, end_time, period):
    ex = Exchange(ex_name=ex_name)
    api = ex.get_api()
    a = 3
    while True:
        a -= 1
        try:
            data = api.get_kline(base, quote, period=period, start=start_time, end=end_time)
            close = data['close']
            ret = close.pct_change()
            vol = ret.std()
            print('{0}/{1}: vol = {2}. ex: {3}'.format(base, quote, format(vol, '.2%'), ex_name))
            return vol
        except Exception as e:
            if a > 0:
                continue
            else:
                print('error: {ex_name} - {base}/{quote} - {error}'.format(ex_name=ex_name, base=base, quote=quote, error=e))
                return

import time

start_time = int(time.time()*1000)-60000*60*24*90
end_time = int(time.time()*1000)
# period = '15min'
period = '1d'
# pairs = [
#     ['poloniex', 'btc', 'usdt'],
#     ['poloniex', 'ltc', 'usdt'],
#     ['poloniex', 'eth', 'usdt'],
#     ['poloniex', 'etc', 'usdt'],
#     ['poloniex', 'xrp', 'usdt'],
#     ['poloniex', 'dash', 'usdt'],
#     ['poloniex', 'bch', 'usdt'],
#     ['bitfinex', 'eos', 'usd'],
#     ['bitfinex', 'omg', 'usd'],
#     ['bitfinex', 'qtm', 'usd'],
#
#     ['poloniex', 'ltc', 'btc'],
#     ['poloniex', 'eth', 'btc'],
#     ['poloniex', 'etc', 'btc'],
#     ['poloniex', 'xrp', 'btc'],
#     ['poloniex', 'dash', 'btc'],
#     ['poloniex', 'bch', 'btc'],
#     ['bitfinex', 'eos', 'btc'],
#     ['binance', 'omg', 'btc'],
#     ['bitfinex', 'qtm', 'btc'],
#     ['binance', 'hsr', 'btc'],
#     ['binance', 'qsp', 'btc'],
# ]
#
# for ex, base, quote in pairs:
#     get_vol(ex, base, quote, start_time=start_time, end_time=end_time, period=period)

# BTC
get_vol('poloniex', 'btc', 'usdt', start_time=start_time, end_time=end_time, period=period)

# LTC
get_vol('poloniex', 'ltc', 'usdt', start_time=start_time , end_time=end_time, period=period)
get_vol('poloniex', 'ltc', 'btc', start_time=start_time , end_time=end_time, period=period)

# ETH
get_vol('poloniex', 'eth', 'usdt', start_time=start_time , end_time=end_time, period=period)
get_vol('poloniex', 'eth', 'btc', start_time=start_time , end_time=end_time, period=period)

# ETC
get_vol('poloniex', 'etc', 'usdt', start_time=start_time , end_time=end_time, period=period)
get_vol('poloniex', 'etc', 'btc', start_time=start_time , end_time=end_time, period=period)

# XRP
get_vol('poloniex', 'xrp', 'usdt', start_time=start_time , end_time=end_time, period=period)
get_vol('poloniex', 'xrp', 'btc', start_time=start_time , end_time=end_time, period=period)

# DASH
get_vol('poloniex', 'dash', 'usdt', start_time=start_time , end_time=end_time, period=period)
get_vol('poloniex', 'dash', 'btc', start_time=start_time , end_time=end_time, period=period)

# BCH
get_vol('poloniex', 'bch', 'usdt', start_time=start_time , end_time=end_time, period=period)
get_vol('poloniex', 'bch', 'btc', start_time=start_time , end_time=end_time, period=period)

# EOS
get_vol('bitfinex', 'eos', 'usd', start_time=start_time , end_time=end_time, period=period)
get_vol('bitfinex', 'eos', 'btc', start_time=start_time , end_time=end_time, period=period)

# OMG
get_vol('bitfinex', 'omg', 'usd', start_time=start_time , end_time=end_time, period=period)
get_vol('binance', 'omg', 'btc', start_time=start_time , end_time=end_time, period=period)

# QTM
get_vol('bitfinex', 'qtm', 'usd', start_time=start_time , end_time=end_time, period=period)
get_vol('bitfinex', 'qtm', 'btc', start_time=start_time , end_time=end_time, period=period)

# HSR
get_vol('binance', 'hsr', 'btc', start_time=start_time , end_time=end_time, period=period)

# QSP
get_vol('binance', 'qsp', 'btc', start_time=start_time , end_time=end_time, period=period)





# btc/usdt: vol = 0.57%. ex: poloniex
# ltc/usdt: vol = 0.81%. ex: poloniex
# ltc/btc: vol = 0.59%. ex: poloniex
# eth/usdt: vol = 0.62%. ex: poloniex
# eth/btc: vol = 0.50%. ex: poloniex
# etc/usdt: vol = 0.88%. ex: poloniex
# etc/btc: vol = 0.75%. ex: poloniex
# xrp/usdt: vol = 0.75%. ex: poloniex
# xrp/btc: vol = 0.71%. ex: poloniex
# dash/usdt: vol = 0.82%. ex: poloniex
# dash/btc: vol = 0.73%. ex: poloniex
# bch/usdt: vol = 1.27%. ex: poloniex
# bch/btc: vol = 1.34%. ex: poloniex
# eos/usd: vol = 0.65%. ex: bitfinex
# eos/btc: vol = 0.68%. ex: bitfinex
# omg/usd: vol = 1.41%. ex: bitfinex
# omg/btc: vol = 1.35%. ex: binance
# qtm/usd: vol = 1.97%. ex: bitfinex
# qtm/btc: vol = 2.57%. ex: bitfinex
# hsr/btc: vol = 2.09%. ex: binance
# qsp/btc: vol = 3.61%. ex: binance
