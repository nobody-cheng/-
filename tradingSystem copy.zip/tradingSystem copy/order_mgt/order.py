#!/usr/bin/env python
# -*- coding: utf-8 -*-
# @Time    : 28/11/2017 7:52 PM
# @Author  : Lloyd Lee
# @File    : order.py

from enum import Enum, unique


@unique
class OrderType(Enum):
    LIMIT_ORDER = 0
    MARKET_ORDER = 1


@unique
class OrderSide(Enum):
    BUY = 0
    SELL = 1


@unique
class OpenOrClose(Enum):
    Open = 0
    Close = 1


@unique
class OrderStatus(Enum):
    SUBMITTED = 0  # submitted
    PARTIAL_FILLED = 1  # partially filled, not cancelled
    PARTIAL_FILLED_CANCELLED = 2  # partially filled, cancelled, order completed
    FULLY_FILLED = 3  # fully filled, order completed
    CANCELLD = 4  # not filled and cancelled, order completed





class Order(object):
    def __init__(
            self,
            ex_name=None,
            side=None,
            order_id=None,
            order_type=None,
            create_time=None,
            update_time_server=None,
            update_time_client=None,
            order_price=None,
            order_quantity=None,  # quantity of underlying asset
            order_amount=None,  # money amount of underlying asset
            filled_avg_price=None,
            filled_quantity=None,
            filled_amount=None,
            remaining_qty=None,
            remaining_amount=None,
            order_status=None,
            **kwargs
    ):
        """
        order base type
        :param ex_name: name of exchange
        :type ex_name: str
        :param side: buy or sell
        :param kwargs:
        """
        self.order_id = order_id
        self.ex_name = ex_name
        self.side = side
        self.order_type = None
        self.kwargs = kwargs
        self.order_type = order_type
        self.create_time = create_time
        self.update_time_server = update_time_server
        self.update_time_client = update_time_client
        self.order_price = order_price
        self.order_quantity = order_quantity
        self.order_amount = order_amount
        self.filled_avg_price = filled_avg_price
        self.filled_quantity = filled_quantity
        self.filled_amount = filled_amount
        self.remaining_qty = remaining_qty
        self.remaining_amount = remaining_amount
        self.order_status = order_status


class SpotOrder(Order):
    def __init__(
            self,
            ex_name=None,
            side=None,
            order_id=None,
            order_type=None,
            create_time=None,
            update_time_server=None,
            update_time_client=None,
            order_price=None,
            order_quantity=None,  # quantity of underlying asset
            order_amount=None,  # money amount of underlying asset
            filled_avg_price=None,
            filled_quantity=None,
            filled_amount=None,
            remaining_qty=None,
            remaining_amount=None,
            order_status=None,
            **kwargs
    ):
        super(SpotOrder, self).__init__(
            ex_name=ex_name,
            side=side,
            order_id=order_id,
            order_type=order_type,
            create_time=create_time,
            update_time_server=update_time_server,
            update_time_client=update_time_client,
            order_price=order_price,
            order_quantity=order_quantity,
            order_amount=order_amount,
            filled_avg_price=filled_avg_price,
            filled_quantity=filled_quantity,
            filled_amount=filled_amount,
            remaining_qty=remaining_qty,
            remaining_amount=remaining_amount,
            order_status=order_status,
            kwargs=kwargs
        )


class ContractOrder(Order):
    def __init__(
            self,
            ex_name=None,
            side=None,
            open_or_close=None,
            order_id=None,
            order_type=None,
            create_time=None,
            update_time_server=None,
            update_time_client=None,
            order_price=None,
            order_quantity=None,  # quantity of underlying asset
            order_amount=None,  # money amount of underlying asset
            filled_avg_price=None,
            filled_quantity=None,
            filled_amount=None,
            remaining_qty=None,
            remaining_amount=None,
            order_status=None,
            lever=None,
            **kwargs
    ):
        super(ContractOrder, self).__init__(
            ex_name=ex_name,
            side=side,
            order_id=order_id,
            order_type=order_type,
            create_time=create_time,
            update_time_server=update_time_server,
            update_time_client=update_time_client,
            order_price=order_price,
            order_quantity=order_quantity,
            order_amount=order_amount,
            filled_avg_price=filled_avg_price,
            filled_quantity=filled_quantity,
            filled_amount=filled_amount,
            remaining_qty=remaining_qty,
            remaining_amount=remaining_amount,
            order_status=order_status,
            kwargs=kwargs
        )
        self.open_or_close = open_or_close
        self.lever = lever



# order = SpotOrder(side='buy',haha=1,hehe=2)

