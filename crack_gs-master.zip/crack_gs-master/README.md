# 全国工商企业信息查询 验证码破解
全国工商企业信息查询 验证码破解

## 项目演式
![image](https://github.com/ever391/crack_gs/blob/master/crack.gif)


## 使用说明：
- 调用crack_slide_captcha.py文件
- 实例化CrackSlide对象
- 执行exec_crack.run方法 参数：is_display 是否显示， 值为True/False
- 返回通过验证码以后的结果


## 工商企业信息查询网自带机器学习识别特征，大量访问会造成行为特征识别,无法通过。

## PS  。。。。。。：
    第一次开源好用的东东，以后要多多分享
    如果喜欢请Fork下我，  后期会再次针对进行优化，
    如果有好的方法，欢迎共同维护！
    Thank you!

## 特别感谢：
    iYgnohZ 影响了我，让我也走向开源！

## 本方法仅供学习